/*
    saa7146_core.c - core-functions + i2c driver for the saa7146 by
    Philips Semiconductors.
    
    Copyright (C) 1998,1999 Michael Hunold <michael@mihu.de>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/*
    Some modifications and improvements
    
    Copyright (C) 2001 Rolf Siebrecht <rolf.siebrecht@t-online.de>
*/

#include <linux/version.h>
#include <linux/module.h>	/* for module-version */
#include <linux/delay.h>	/* for delay-stuff */
#include <linux/slab.h>		/* for kmalloc/kfree */
#include <linux/pci.h>		/* for pci-config-stuff, vendor ids etc. */
#include <linux/wrapper.h>	/* for mem_map_reserve */
#include <linux/poll.h>
#include <linux/init.h>
#include <linux/time.h>
#include <linux/interrupt.h>
#include <asm/io.h>		/* for accessing the pci-device */

#include "saa7146.h"
#include "saa7146_core.h"

#ifdef MODULE
MODULE_PARM(debug,"i");
MODULE_PARM(idebug,"i");
MODULE_PARM(latency,"1-4i");
MODULE_PARM(threshold,"1-4i");
MODULE_PARM(burst,"1-4i");
MODULE_PARM(fieldnr,"i");
#endif

static int latency[SAA7146_MAX_DEVICES] = { -1, -1, -1, -1 };
static int threshold[SAA7146_MAX_DEVICES] = { -1, -1, -1, -1 };
static int burst[SAA7146_MAX_DEVICES] = { -1, -1, -1, -1 };
static int fieldnr = 0;

/* debug levels: 0 -- no debugging outputs
		 1 -- prints out entering (and exiting if useful) of functions
		 2 -- prints out very, very detailed informations of what is going on
		 3 -- both of the above */
static int debug = 0;	/* insmod parameter */
static int idebug = 0;	/* insmod parameter */
#define	fprintk		if ((debug == 1) || (debug >= 3)) printk
#define	gprintk		if (debug >= 2) printk
#define	hprintk		if (debug >= 3) printk
#define	iprintk		if (idebug > 0) printk
#define	iiprintk	if (idebug > 1) printk

#include "saa7146_memory.c"

#define SAA7146_RESCHED \
   	do { \
          if (current->need_resched) \
            schedule (); \
        } while (0)

static int	saa7146_num = 0;
static struct	saa7146 saa7146_adap[SAA7146_MAX_DEVICES];

static int	saa7146_extension_count = 0;
static struct	saa7146_extension *saa7146_ext[SAA7146_MAX_EXTENSIONS];

/* i2c-timeout-value in ms */
#define SAA7146_I2C_TIMEOUT 		100
/* how many times shall we retry an i2c-operation? */
#define SAA7146_I2C_RETRIES 		3

#ifdef DVB
static __u32 SAA7146_I2C_BBR = SAA7146_I2C_BUS_BIT_RATE_3200;
#else
static __u32 SAA7146_I2C_BBR = SAA7146_I2C_BUS_BIT_RATE_480;
#endif

#define __COMPILE_SAA7146_VBI__
#define	__COMPILE_SAA7146_I2C__
#include "saa7146.c"
#undef	__COMPILE_SAA7146_I2C__
#undef	__COMPILE_SAA7146_VBI__

/* ---------------------------------------------*/
/* memory functions designed for saa7146	*/
/* ---------------------------------------------*/

/* rvmalloc allocates the memory and builds up
   the page-tables for �quant�-number of buffers */
static void
*rvmalloc (int quant, __u32 *pt[])
{
	void *mem;
	unsigned long adr = 0;
	unsigned long count = 0;
	__u32 *ptp = 0;
	int i = 0, j = 0;

fprintk (KERN_INFO "saa7146_core: ==> rvmalloc (quant=%d)\n",quant);

	/* get grabbing memory */
	mem = vmalloc (quant * GRABBING_MEM_SIZE); 

	if (0 == mem) 
		return NULL;

	/* alloc one page for a page-table for �quant� buffers */
	for (i = 0; i < quant; i++) {
	
		pt[i] = (__u32 *) kmalloc (PAGE_SIZE, GFP_KERNEL);

		/* error: memory could not be allocated */
		if (0 == pt[i]) {
			for (j = (i-1); j >= 0; j--) {
				kfree (pt[j]);
			}
			kfree (mem);
			
			return NULL;
		}

		memset (pt[i], 0x00, PAGE_SIZE);
	}

	/* clear the ram out, no junk to the user
	   note: 0x7f gives a nice grey field
	   in RGB and YUV as well */
	memset (mem, 0x7f, quant * GRABBING_MEM_SIZE); 

	adr = (unsigned long) mem;
	/* walk through the grabbing-memory and build up the page-tables */
	for (i = 0; i < quant; i++) {
           	for (count = 0; count < GRABBING_MEM_SIZE; count += PAGE_SIZE)
                	mem_map_reserve (virt_to_page (__va (kvirt_to_phys (adr + count))));
                /* separate loop for SAA MMU, PAGE_SIZE can be != 4096 */
		ptp = pt[i];
                for (count = 0; count < GRABBING_MEM_SIZE; count += 4096, adr += 4096)
                   	*(ptp++) = kvirt_to_phys (adr);
	}

	return mem;
}

static void
rvfree (void *mem, int quant, __u32 *pt[])
{
        unsigned long adr, page;
	unsigned long size = 0;

	int i = 0;

fprintk (KERN_INFO "saa7146_core: ==> rvfree\n");

	/* walk through grabbing memory and unreserve every page */
	adr = (unsigned long) mem;
	size = quant * GRABBING_MEM_SIZE;

	while (size > 0) {
		page = kvirt_to_phys (adr);
                mem_map_unreserve (virt_to_page (__va (page)));
		adr	+= PAGE_SIZE;
		size	-= PAGE_SIZE;
	}

	/* release the grabbing memory */
	vfree (mem);
	
	/* free the page tables */
	for (i = 0; i < quant; i++) {
		kfree (pt[i]);
	}
}

/* ---------------------------------------------*/
/* i2c-functions				*/
/* ---------------------------------------------*/

int
master_xfer (struct i2c_adapter *adap, struct i2c_msg msgs[], int num)
{
	struct saa7146 *a = (struct saa7146*)(adap->data);

	int result, count;
	int retries = adap->retries;
	int i = 0;
	
iprintk (KERN_ERR "saa7146_core: %s: ==> master_xfer (num=%d)\n", a->name, num);

	/* prepare the message(s), get number of u32s to transfer */
	count = prepare(msgs, num, a->i2c_buf);
	if ( 0 > count ) {

iprintk (KERN_ERR "saa7146_core: %s: master_xfer: could not prepare i2c-message\n", a->name);

		return -1;
	}

	/* loop through number of retries ... */
	while ( 0 < retries ) {
	
		retries--;
	
		/* reset the i2c-device if necessary */
		result = i2c_reset( a );
		if ( 0 > result ) {

iprintk (KERN_ERR "saa7146_core: %s: master_xfer: could not reset i2c-bus\n", a->name);

			return -1;
		}	

		/* see how many u32 have to be transferred; if there is only 1,
		   we do not start the whole rps1-engine... */

		for(i = 0; i < count; i++) {
			result = i2c_write_out( a, &a->i2c_buf[i], adap->timeout );
			if ( 0 != result) {
				/* if address-error occured, don�t retry */
				if ( -2 == result ) {

iprintk (KERN_ERR "saa7146_core: %s: master_xfer: error in address phase\n", a->name);

					return -1;
				}

iprintk (KERN_ERR "saa7146_core: %s: master_xfer: error transferring, trying again\n", a->name);

				break;
			}
		}
		
		/* see if an error occured & the last retry failed */
		if( (0 != result) && (0 == retries) ) {

iprintk (KERN_ERR "saa7146_core: %s: master_xfer: could not transfer i2c-message\n", a->name);

			return -1;
		}
		
		if( 0 == result )
			break;
	}
	
	/* if any things had to be read, get the results */
	result = clean_up(msgs, num, a->i2c_buf);
	if ( 0 > result ) {

iprintk (KERN_ERR "saa7146_core: %s: master_xfer: could not cleanup\n", a->name);
		
		return -1;
	}

	/* return the number of delivered messages */
	return num;	
}

int
algo_control (struct i2c_adapter *adapter, unsigned int cmd, unsigned long arg)
{

iprintk ("saa7146_core: ==> algo_control\n");

	return -ENOIOCTLCMD;
}

__u32
functionality (struct i2c_adapter *adapter)
{
	/* fixme: there should be a serious return-value here */
	return 0xffffffff;
}

struct i2c_algorithm saa7146_algo = {
	"saa7146 i2c-algorithms",
	I2C_ALGO_SAA7146,
	master_xfer,
	NULL,			/* smbus_xfer */
	NULL,			/* slave_send */
	NULL,			/* slave_recv */
	algo_control,
	functionality,
};

/* registering functions to load algorithms at runtime */
int
i2c_saa7146_add_bus (struct saa7146 *adap)
{
	struct i2c_adapter *i2c_adap;

	i2c_adap = kmalloc(sizeof(struct i2c_adapter), GFP_KERNEL);

	if (i2c_adap == NULL)
		return -ENOMEM;

	adap->i2c_adap = i2c_adap;

	/* register new adapter to i2c module... */
	memset(i2c_adap,0,sizeof(struct i2c_adapter));
	strcpy(i2c_adap->name,adap->name);
	i2c_adap->id 	  = saa7146_algo.id;	/* unused */
	i2c_adap->algo	  = &saa7146_algo;
	i2c_adap->data	  = adap;
	i2c_adap->timeout = SAA7146_I2C_TIMEOUT;
	i2c_adap->retries = SAA7146_I2C_RETRIES;

	i2c_add_adapter(i2c_adap);

	/* enable i2c-port pins */
	saa7146_write(adap->mem,MC1, (MASK_08 | MASK_24));

iprintk ("saa7146_core: i2c-routines for %s registered.\n", adap->name);

	return 0;
}

int
i2c_saa7146_del_bus (struct saa7146 *adap)
{
	i2c_del_adapter(adap->i2c_adap);
	kfree(adap->i2c_adap);
	
iprintk ("saa7146_core: adapter unregistered: %s\n", adap->name);

	return 0;
}

/* ---------------------------------------------*/
/* debug-helper function: dump-registers	*/
/* ---------------------------------------------*/

void
dump_registers(unsigned char* mem)
{	
	u16 j = 0;
	
	for (j = 0x0; j < 0x1fe; j+=0x4) {
		printk ("0x%03x: 0x%08x\n", j, saa7146_read(mem,j));
	}

}

/* -----------------------------------------------------*/
/* dispatcher-function for handling external commands	*/
/* -----------------------------------------------------*/

static int
saa7146_core_command (struct i2c_adapter *adap, unsigned int cmd, void *arg)
{
	int i = 0, result = -ENOIOCTLCMD;
	struct saa7146 *saa = adap->data;

fprintk ("saa7146_core: ==> saa7146_core_command (cmd=0x%08x)\n", cmd);

	if (NULL == saa)
		return -EINVAL;

	/* first let the extensions handle the command */
	for (i = 0; i < SAA7146_MAX_EXTENSIONS; i++) {
		if (NULL != saa7146_ext[i]) {
			if (-ENOIOCTLCMD != (result = saa7146_ext[i]->command (saa, saa->data[i], cmd, arg))) {
				break;
			}
		}
	}

	if (result != -ENOIOCTLCMD)
		return result;

	/* if command has not been handled by an extension, handle it now */
	switch (cmd) {
                case SAA7146_OPEN:
                {
                   	int i;

gprintk (KERN_INFO "saa7146_core: ==> ioctl SAA7146_OPEN\n");

			saa->grab_buf = (__u32 *) rvmalloc (SAA7146_MAX_BUF, &saa->page_table[0]);
			if (!saa->grab_buf)
				return -ENOMEM;

                   	saa->grab_queue_inp = 0;
                        saa->grab_queue_outp = 0;
                        saa->grab_frame = -1;
                        for (i = 0; i < SAA7146_MAX_BUF; i++)
                           	saa->grab_stat[i] = GBUFFER_UNUSED;
                   	break;
                }
                
                case SAA7146_CLOSE:
                {
                   	unsigned long irq_flags;

gprintk (KERN_INFO "saa7146_core: ==> ioctl SAA7146_CLOSE\n");

                   	spin_lock_irqsave (&saa->s_lock, irq_flags);
			/* disable video dma1 + video dma2 */
			saa7146_write(saa->mem, MC1, (MASK_22 | MASK_21));
                        spin_unlock_irqrestore (&saa->s_lock, irq_flags);
                
                        /* wait until DMA processes over */
                        if (-1 != saa->grab_frame) {
                           	current->state=TASK_UNINTERRUPTIBLE;
                                schedule_timeout (HZ/10);
                        }

			if (saa->grab_buf)
				rvfree (saa->grab_buf, SAA7146_MAX_BUF, &saa->page_table[0]);
			saa->grab_buf = NULL;

                   	break;
                }

        case SAA7146_DUMP_REGISTERS:
		dump_registers (saa->mem);
		break;

	case SAA7146_SET_DD1:
	{
		__u32 *i = arg;

gprintk (KERN_INFO "saa7146_core: ==> ioctl SAA7146_SET_DD1 (val=0x%08x)\n", *i);

		/* set dd1 port register */
		saa7146_write(saa->mem, DD1_INIT, *i);

		/* write out init-values */
		saa7146_write(saa->mem, MC2, (MASK_09 | MASK_10 | MASK_25 | MASK_26));
		break;
	}

	case SAA7146_DO_MMAP:
	{
		struct saa7146_mmap_s *mms = arg;

		const char *adr = mms->adr;
		unsigned long size = mms->size;
		unsigned long start=(unsigned long) adr;
		unsigned long page, pos;

gprintk (KERN_INFO "saa7146_core: ==> ioctl SAA7146_DO_MMAP (adr=0x%p; siz=%ld)\n", mms->adr, mms->size);

		if (size > SAA7146_MAX_BUF * GRABBING_MEM_SIZE)
			return -EINVAL;

		if (NULL == saa->grab_buf)
			return -EINVAL;

		pos = (unsigned long) saa->grab_buf;
		while (size > 0) {
			page = kvirt_to_phys (pos);
			if (remap_page_range (start, page, PAGE_SIZE, PAGE_SHARED))
				return -EAGAIN;

			start	+= PAGE_SIZE;
			pos	+= PAGE_SIZE;
			size	-= PAGE_SIZE;    
		}
		break;
	}

	case SAA7146_FIELDNR:

		if (!fieldnr)
			return -EINVAL;
		
gprintk (KERN_INFO "saa7146_core: ==> ioctl SAA7146_FIELDNR (nr=%d)\n", saa->last_field);

		*(unsigned int *) arg = saa->last_field;
		
		break;
		
	case SAA7146_VBI_OPEN:

gprintk (KERN_INFO "saa7146_core: ==> ioctl SAA7146_VBI_OPEN\n");

		saa->vbi_p = VBI_MEM_SIZE;
		saa->vbi_running = 1;
		vbi_init (saa);
		break;

	case SAA7146_VBI_CLOSE:

gprintk (KERN_INFO "saa7146_core: ==> ioctl SAA7146_VBI_CLOSE\n");

		vbi_exit (saa);
		saa->vbi_running = 0;
		break;

	case SAA7146_VBI_BUFSIZE:
	{
		int vbibufsize = VBI_MEM_SIZE;

gprintk (KERN_INFO "saa7146_core: ==> ioctl saa7146_vbi_bufsize (size=%d)\n", vbibufsize);

		return vbibufsize;
	}

	case SAA7146_VBI_READ:
	{
		struct saa7146_vbi_read_s *vbi_read_data = arg;
		int q, todo;
		DECLARE_WAITQUEUE (wait, current);

gprintk (KERN_INFO "saa7146_core: ==> ioctl SAA7146_VBI_READ\n");

		todo = vbi_read_data->count;
		while (todo && (todo > (q = VBI_MEM_SIZE - saa->vbi_p))) {
			if (copy_to_user ((void *) vbi_read_data->buf, (void *) saa->vbi_buf + saa->vbi_p, q))
				return -EFAULT;
			todo -= q;
			vbi_read_data->buf += q;

			add_wait_queue (&saa->vbi_wq, &wait);
			current->state = TASK_INTERRUPTIBLE;
			if (todo && (q == VBI_MEM_SIZE - saa->vbi_p)) {
				if (vbi_read_data->nonblock) {
					remove_wait_queue (&saa->vbi_wq, &wait);
					current->state = TASK_RUNNING;
					if (vbi_read_data->count == todo)
						return -EWOULDBLOCK;

					return vbi_read_data->count - todo;
				}
				schedule ();
				if (signal_pending (current)) {
					remove_wait_queue (&saa->vbi_wq, &wait);
					current->state = TASK_RUNNING;
					if (todo == vbi_read_data->count)
						return -EINTR;
					else
						return vbi_read_data->count - todo;
				}
			}
			remove_wait_queue (&saa->vbi_wq, &wait);
			current->state = TASK_RUNNING;
		}
		if (todo) {
			if (copy_to_user ((void *) vbi_read_data->buf, (void *) saa->vbi_buf + saa->vbi_p, todo))
				return -EFAULT;
			saa->vbi_p += todo;
		}
		return vbi_read_data->count;
	}

	case SAA7146_VBI_POLL:
	{
		struct saa7146_vbi_poll_s *vbi_poll_data = arg;
		unsigned int mask = 0;

gprintk (KERN_INFO "saa7146_core: ==> ioctl SAA7146_VBI_POLL\n");

		poll_wait (vbi_poll_data->file, &saa->vbi_wq, vbi_poll_data->wait);

		if (saa->vbi_p < VBI_MEM_SIZE)
			mask |= (POLLIN | POLLRDNORM);
	
		return mask;
	}

	default:
		return -ENOIOCTLCMD;

	} /* switch(cmd) */

	return 0;
}

/* -----------------------------------------------------*/
/* dispatcher-function for handling irq-events		*/
/* -----------------------------------------------------*/

/* irq-handler function */
static void
saa7146_irq_bh (void *data)
{
	struct saa7146 *saa = (struct saa7146 *) data;
	struct timeval tv;
        int i;
	__u32 isr = saa->appeared_irq;

        saa->appeared_irq = 0;
        
        if (debug >= 3) {
	       do_gettimeofday (&tv);
               printk (KERN_INFO "%s: ==> saa7146_irq_bh enter (tod=%ld.%03ld; ISR=0x%08x)\n", saa->name, tv.tv_sec, tv.tv_usec / 1000, isr);
   	}

	/* process all interrupts */
        
   	/* first let the extensions handle the interrupt */
        for (i = 0; i < SAA7146_MAX_EXTENSIONS; i++)
                if ((NULL != saa7146_ext[i]) && (0 != (isr & saa7146_ext[i]->handles_irqs))) {

hprintk (KERN_INFO "%s: IRQ handled by saa7146 extension (%d)\n", saa->name, i);

                        saa7146_ext[i]->irq_handler (saa, isr, saa->data[i]);
                        isr &= ~saa7146_ext[i]->handles_irqs;
        }
        
	/* video protection error interrupt ? */
	if (0 != (isr & SPCI_V_PE)) {
		__u32 ssr;

		/* captured VBI frame? --> check video channel 3 ! */
		/* get secondary status register */
		ssr = saa7146_read(saa->mem, SSR);
		if (ssr & MASK_16) {
			saa->vbi_p = 0;
			(*(__u32 *) &(saa->vbi_buf[VBI_MEM_SIZE - 4]))++;

hprintk (KERN_INFO "%s: IRQ caused by captured VBI frame\n", saa->name);

			/* clear the interrupt */
			saa7146_write(saa->mem, ISR, SPCI_V_PE);

			/* notify any pending process */
			wake_up_interruptible (&saa->vbi_wq);
 		} else {
			/* V_PE IRQ didn�t originate from video		*/
			/* channel 3, but we have to clear it anyway	*/
			saa7146_write(saa->mem, ISR, SPCI_V_PE);
		}
		isr &= ~SPCI_V_PE;
	}

	/* port A field ID interrupt ? */
	if (0 != (isr & SPCI_FIDA)) {
		saa->field++;

hprintk (KERN_INFO "%s: IRQ caused by port A field ID\n", saa->name);

		/* clear the interrupt */
		saa7146_write(saa->mem, ISR, SPCI_FIDA);
		isr &= ~SPCI_FIDA;
	}
	
	if (0 != isr)
           	printk (KERN_WARNING "%s: Unhandled IRQ (ISR=0x%08x).\n", saa->name, isr);

        if (debug >= 3) {
           	do_gettimeofday (&tv);
                printk (KERN_INFO "%s: ==> saa7146_irq_bh exit (tod=%ld.%03ld)\n", saa->name, tv.tv_sec, tv.tv_usec / 1000);
        }

}

static void
saa7146_irq (int irq, void *dev_id, struct pt_regs *regs)
{
   	struct saa7146 *saa = (struct saa7146 *) dev_id;
        __u32 isr = 0;
        
        /* read out the interrupt status register */
        isr =saa7146_read(saa->mem, ISR);
        
        /* is this our interrupt? */
        if (0 == isr) {
           	/* nope, some other device */
                return;
        }
        saa->appeared_irq = isr;
        
        /* schedule our bottom-half */
        saa->bh_handler.routine = saa7146_irq_bh;
        saa->bh_handler.data = saa;
        queue_task (&saa->bh_handler, &tq_immediate);
        mark_bh (IMMEDIATE_BH);
        
        /* clear interrupts */
        saa7146_write(saa->mem, ISR, isr);
}


struct saa7146
*saa7146_get_handle (int i)
{

fprintk ("saa7146_core: ==> saa7146_get_handle (n=%d)\n", i);
	
	if (i >= saa7146_num)
		return NULL;
		
	return &saa7146_adap[i];
}


int
saa7146_add_extension (struct saa7146_extension *ext)
{
	int i = 0, j = 0;

fprintk ("saa7146_core: ==> saa7146_attach_extension\n");

	for (i = 0; i < SAA7146_MAX_EXTENSIONS; i++) {
		if (NULL == saa7146_ext[i])
			break;
		if (SAA7146_MAX_EXTENSIONS == i) {
			printk (KERN_WARNING "saa7146_core: attach_extension(%s): enlarge SAA7146_MAX_EXTENSIONS!\n", ext->name);
			return -ENOMEM;
		}
	}
	saa7146_ext[i] = ext;
	saa7146_extension_count++;

	/* call back extension handler, so extension-specific stuff can be initialized */
	for (j = 0; j < saa7146_num; j++) {
		if (NULL != ext->attach) {
			if (0 != ext->attach (&saa7146_adap[j], &saa7146_adap[j].data[i])) {
				printk (KERN_WARNING "saa7146_core: attach_extension(%s): could not increment use-count.\n",ext->name);
			}
		}
	}
	
	return 0;
} /* saa7146_add_extension() */


int
saa7146_del_extension (struct saa7146_extension *ext)
{
	int i = 0, j = 0;

fprintk ("saa7146_core: ==> saa7146_detach_extension\n");

	for (i = 0; i < SAA7146_MAX_EXTENSIONS; i++)
		if (ext == saa7146_ext[i])
			break;
	if (SAA7146_MAX_EXTENSIONS == i) {
		printk ("saa7146_core: detach_extension extension [%s] not found.\n", ext->name);
		return -ENODEV;
	}		

	/* all done, now unregister */
	saa7146_ext[i] = NULL;
	saa7146_extension_count--;		

	for (j = 0; j < saa7146_num; j++) {

		if (NULL != ext->detach) {
			if( 0 != ext->detach (&saa7146_adap[j], &saa7146_adap[j].data[i])) {
				printk (KERN_WARNING "saa7146_core: detach_extension(%s): could not decrement use-count.\n",ext->name);
			}
		}
	}
	
	return 0;
} /* saa7146_del_extension() */

EXPORT_SYMBOL(saa7146_get_handle);
EXPORT_SYMBOL(saa7146_add_extension);
EXPORT_SYMBOL(saa7146_del_extension);

/* -----------------------------------------------------
   functions for finding any saa7146s in the system,
   inserting/removing module for kernel, etc.
   ----------------------------------------------------- */

static int __devinit
saa7146_probe (struct pci_dev *dev, const struct pci_device_id *pci_id)
{
	struct saa7146 *saa = &saa7146_adap[saa7146_num];
	__u32 physmem, rev, lat, subid, burst_threshold, bur, thr;
	int result = 0, j = 0;

fprintk ("saa7146_core: ==> saa7146_probe\n");

	/* check for maximum number of saa7146-devices */
	if (saa7146_num >= SAA7146_MAX_DEVICES) {
		printk (KERN_ERR "saa7146_core: maximum number of SAA7146 devices reached!\n");
		return -1;
	}

	if (pci_enable_device (dev))
		return -EIO;
	if (!request_mem_region (pci_resource_start (dev, 0),
				pci_resource_len (dev, 0),
				"saa7146_core"))
		return -EBUSY;

	/* get chip-revision; this is needed to enable bug-fixes */
	if (0 > pci_read_config_dword (dev, PCI_CLASS_REVISION, &rev)) {
		printk (KERN_ERR "saa7146_core: cannot read from pci-device!\n");
		return -1;
	}
	saa->revision = rev & 0xf;

        /* get subsystem ids */
        pci_read_config_dword (dev, PCI_SUBSYSTEM_VENDOR_ID, &subid);
        
	sprintf (saa->name, "saa7146(%d)", saa7146_num);	
	saa->device = dev;
 
	/* remap the memory from virtual to physical adress */
        physmem = pci_resource_start (dev, 0);
	saa->mem = ioremap (physmem & PCI_BASE_ADDRESS_MEM_MASK, 0x1000);
	if (0 == saa->mem) {
	    	printk (KERN_ERR "saa7146_core: cannot map pci-address!\n");
		return -1;
	}

	/* get clipping memory */	
	saa->clip_buf = (__u32 *) kmalloc (CLIPPING_MEM_SIZE * sizeof (__u32), GFP_KERNEL);
	if (0 == saa->clip_buf) {
	    	printk (KERN_ERR "saa7146_core: not enough kernel-memory for clipping buffer.\n");
		return -1;
	}
	memset (saa->clip_buf, 0x0, CLIPPING_MEM_SIZE * sizeof (__u32));

	/* get i2c memory */	
	saa->i2c_buf = (__u32 *) kmalloc (I2C_MEM_SIZE * sizeof (__u32), GFP_KERNEL); /*64*/
	if (0 == saa->i2c_buf) {
	    	printk (KERN_ERR "saa7146_core: not enough kernel-memory for i2c buffer.\n");
		kfree (saa->clip_buf);
		return -1;
	}
	memset (saa->i2c_buf, 0x0, I2C_MEM_SIZE * sizeof(__u32));

	/* get rps0 memory */
	saa->rps0_buf = (__u32 *) kmalloc (RPS_MEM_SIZE * sizeof (__u32), GFP_KERNEL);
	if (0 == saa->rps0_buf) {
	    	printk (KERN_ERR "saa7146_core: not enough kernel-memory for rps0 buffer.\n");
		kfree (saa->i2c_buf);
		kfree (saa->clip_buf);
		return -1;
	}
	memset (saa->rps0_buf, 0x0, RPS_MEM_SIZE * sizeof(__u32));

	/* get rps1 memory */
	saa->rps1_buf = (__u32 *) kmalloc (RPS_MEM_SIZE * sizeof (__u32), GFP_KERNEL);
	if (0 == saa->rps1_buf) {
	    	printk (KERN_ERR "saa7146_core: not enough kernel-memory for rps1 buffer.\n");
		kfree (saa->rps0_buf);
		kfree (saa->i2c_buf);
		kfree (saa->clip_buf);
		return -1;
	}
	memset (saa->rps1_buf, 0x0, RPS_MEM_SIZE * sizeof (__u32));

	/* get VBI memory */
	saa->vbi_buf = (char *) kmalloc (VBI_MEM_SIZE * sizeof (char), GFP_KERNEL);
	if (0 == saa->vbi_buf) {
		printk (KERN_ERR "saa7146_core: not enough kernel-memory for vbi buffer.\n");
		kfree (saa->rps1_buf);
		kfree (saa->rps0_buf);
		kfree (saa->i2c_buf);
		kfree (saa->clip_buf);
		return -1;
	}
	memset (saa->vbi_buf, 0, VBI_MEM_SIZE * sizeof (char));
	saa->vbi_p = VBI_MEM_SIZE;
	
	/* clear out memory for grabbing information */
	memset (&saa->grab_width[0], 0x0, sizeof (int) * SAA7146_MAX_BUF);
	memset (&saa->grab_height[0], 0x0, sizeof (int) * SAA7146_MAX_BUF);
	memset (&saa->grab_format[0], 0x0, sizeof (int) * SAA7146_MAX_BUF);
	memset (&saa->grab_port[0], 0x0, sizeof (int) * SAA7146_MAX_BUF);

	/* init grabbing request queue */
	saa->grab_queue_inp = 0;
	saa->grab_queue_outp = 0;
        saa->grab_frame = -1;
        
	/* init the frame-status array */
	memset (&saa->grab_stat[0], GBUFFER_UNUSED, sizeof (int) * SAA7146_MAX_BUF);
	
	/* clear out all wait queues */
	init_waitqueue_head (&saa->rps0_wq);
	init_waitqueue_head (&saa->rps1_wq);
	init_waitqueue_head (&saa->vbi_wq);
	
        saa->s_lock = SPIN_LOCK_UNLOCKED;
        
    	/* request an interrupt for the saa7146 */
	result = request_irq (dev->irq, saa7146_irq, SA_SHIRQ | SA_INTERRUPT,
			saa->name, (void *) saa);
	switch (result) {
		case -EINVAL:
			printk (KERN_ERR "saa7146_core: Bad irq number or handler\n");
			return -EINVAL;
		case -EBUSY:
			printk (KERN_ERR "saa7146_core: IRQ %d busy, change your PnP config in BIOS\n", dev->irq);
			return -EBUSY;
		case 0:
			break;
		default:
			return result;
	}
	
	saa->command = &saa7146_core_command;
	saa->client_register = NULL; /* &client_register; */
	saa->client_unregister = NULL; /* &client_unregister; */
	saa->norm = 0;	/* PAL */
	saa->interlace = 1;
	saa->brightness = 0x80;
	saa->contrast = 0x40;
	saa->saturation = 0x40;
	saa->field = saa->last_field = 0;
	
	/* add new bus (adapter gets added automagically) */
	i2c_saa7146_add_bus (saa);

	/* print status message */
    	printk (KERN_INFO "saa7146_core: %s @ pci %02x:%02x.%x; rev=%d; mem=0x%08x; irq=%d; subsys=0x%04x,0x%04x.\n", saa->name, dev->bus->number, PCI_SLOT(dev->devfn), PCI_FUNC(dev->devfn), saa->revision, physmem, dev->irq, subid & 0xffff, subid >> 16);

	/* enable bus-mastering */
 	pci_set_master (dev);
	pci_set_drvdata (dev, saa);

	/* disable everything on the saa7146, perform a software-reset */
	saa7146_write(saa->mem, MC1, 0xbfff0000);

	/* clear all registers */
	for (j = 0x0; j < 0xfc; j+=0x4) {
		saa7146_write(saa->mem, j, 0x0000000);
	}
	for (j = 0x104; j < 0x1fc; j+=0x4) {
		saa7146_write(saa->mem, j, 0x0000000); 
	}

	/* clear out any rps-signals pending */
	saa7146_write(saa->mem, MC2, 0xf8000000);

	/* enable video-port-pins*/
	saa7146_write(saa->mem, MC1, (MASK_10 | MASK_26));

	/* disable all interrupt-conditions, only enable RPS interrupts */
	/* and, by request, Port A Field ID interrupt */
	saa7146_write(saa->mem, ISR, 0xffffffff);
#if 1
	saa7146_write(saa->mem, IER, (MASK_27 | MASK_28 | (fieldnr ? MASK_08 : 0)));
#else
	saa7146_write(saa->mem, IER, (MASK_27 | MASK_28));
#endif
        
	/* set PCI latency if requested */
        if ((latency[saa7146_num] < -1) || (latency[saa7146_num] > 255)) {
           	printk (KERN_WARNING "saa7146_core: %s: invalid module option latency[%d] ignored.\n", saa->name, saa7146_num);
   	} else if (latency[saa7146_num] != -1) {
           	pci_read_config_dword (dev, PCI_CACHE_LINE_SIZE, &lat);
                lat &= 0xffff00ff;
                lat |= (latency[saa7146_num] << 8) & 0x0000ff00;
                pci_write_config_dword (dev, PCI_CACHE_LINE_SIZE, lat);
        }

        if ((threshold[saa7146_num] < -1) || (threshold[saa7146_num] > 3)) {
           	printk (KERN_WARNING "saa7146_core: %s: invalid module option threshold[%d] ignored.\n", saa->name, saa7146_num);
   		threshold[saa7146_num] = 3;	/* default: threshold = 32 DWords */
        }
        if ((burst[saa7146_num] < -1) || (burst[saa7146_num] > 7)) {
           	printk (KERN_WARNING "saa7146_core: %s: invalid module option burst[%d] ignored.\n", saa->name, saa7146_num);
   		burst[saa7146_num] = 7;		/* default: burst = 128 DWords */
        }

        /* set burst/threshold */
        if (threshold[saa7146_num] == -1)	/* insmod option not given */
           	threshold[saa7146_num] = 3;	/* default: threshold = 32 DWords */
        if (burst[saa7146_num] == -1)		/* insmod option not given */
           	burst[saa7146_num] = 7;		/* default: burst = 128 DWords */
        burst_threshold = 0;
        for (j = 0; j < 4; j++) {
		burst_threshold <<= 8;
           	burst_threshold |= ((burst[saa7146_num] << 2) & 0x1c) | (threshold[saa7146_num] & 0x03);
        }
        /* all video and audio DMA channels get	*/
        /*  the same burst/threshold settings	*/
	saa7146_write(saa->mem, PCI_BT_V1, burst_threshold);
        saa7146_write(saa->mem, PCI_BT_A, burst_threshold);
        
        pci_read_config_dword (dev, PCI_CACHE_LINE_SIZE, &lat);
        lat = (lat >> 8) & 0xff;
        thr = saa7146_read(saa->mem, PCI_BT_V1);
        bur = 1 << ((thr >> 2) & 0x07);
        thr = 4 << (thr & 0x03);
        printk (KERN_INFO "saa7146_core: %s: latency=%d clks; threshold=%d dwrds; burst=%d dwrds.\n", saa->name, lat, thr, bur);
       
	saa7146_write(saa->mem, BCS_CTRL, (saa->brightness << 24) || (saa->contrast << 16) || saa->saturation);

	/* set dd1 stream a & b */
      	saa7146_write(saa->mem, DD1_STREAM, 0x00000000);
	saa7146_write(saa->mem, DD1_INIT, 0x07000000 | (fieldnr ? (MASK_23 | MASK_22) : 0));
	saa7146_write(saa->mem, MC2, (MASK_09 | MASK_25 | MASK_10 | MASK_26));

	saa7146_write(saa->mem, MC2, 0x077c077c);

#ifdef DVB
        saa7146_write(saa->mem, GPIO_CTRL, 0x500000);
#endif        
	saa7146_num++;

	return 0;
}


static void __devexit
saa7146_remove (struct pci_dev *dev)
{
	struct saa7146 *saa = pci_get_drvdata (dev);

fprintk (KERN_INFO "saa7146_core: ==> saa7146_remove\n");

	/* shut down all dma transfers */
	saa7146_write(saa->mem, MC1, 0xbfff0000);
		
	/* disable all irqs, release irq-routine */
	saa7146_write(saa->mem, IER, 0x00);
	saa7146_write(saa->mem, ISR, 0xffffffff);
	free_irq (saa->device->irq, (void *) saa);

	/* unmap the memory, if necessary */
	if (0 != saa->mem)
		iounmap (saa->mem);
        /* DVB driver says, it should be */
        /*	iounmap ((unsigned char *) (((unsigned int) saa->mem) & 0xfffff000)); */
        /* Mhm,.... */
        
	/* release kernel memory buffers */
	kfree (saa->vbi_buf);
	kfree (saa->rps1_buf);
	kfree (saa->rps0_buf);
	if (saa->grab_buf)
		rvfree (saa->grab_buf, SAA7146_MAX_BUF, &saa->page_table[0]);
	kfree (saa->clip_buf);
	kfree (saa->i2c_buf);

	/* nothing else to do here */
	i2c_saa7146_del_bus (saa);

	release_mem_region (pci_resource_start (dev, 0), pci_resource_len (dev, 0));
	pci_set_drvdata (dev, NULL);
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,6)
static int saa7146_suspend (struct pci_dev *pdev, __u32 state)
#else
static void saa7146_suspend (struct pci_dev *pdev)
#endif
{
	struct saa7146 *saa = pci_get_drvdata (pdev);

fprintk (KERN_INFO "saa7146_core: ==> saa7146_suspend\n");

	saa7146_core_command (saa->i2c_adap, SAA7146_SUSPEND, 0);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,6)
	return 0;
#endif
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,6)
static int
#else
static void
#endif
saa7146_resume (struct pci_dev *pdev)
{
	struct saa7146 *saa = pci_get_drvdata (pdev);

fprintk (KERN_INFO "saa7146_core: ==> saa7146_resume\n");

	saa7146_core_command (saa->i2c_adap, SAA7146_RESUME, 0);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,6)
	return 0;
#endif
}


static struct pci_device_id saa7146_pci_tbl[] __devinitdata = {
	{ PCI_VENDOR_ID_PHILIPS, PCI_DEVICE_ID_PHILIPS_SAA7146,
	  PCI_ANY_ID, PCI_ANY_ID, 0, 0, 0 },
	{ 0, 0, 0, 0 },
};

MODULE_DEVICE_TABLE(pci, saa7146_pci_tbl);

static struct pci_driver saa7146_pci_driver = {
	name:		"saa7146",
	id_table:	saa7146_pci_tbl,
	probe:		saa7146_probe,
	remove:		saa7146_remove,
        suspend:	saa7146_suspend,
        resume:		saa7146_resume,
};

/* ------------------------------------------------------------------------- */

MODULE_AUTHOR("Michael Hunold <michael@mihu.de>, Rolf Siebrecht <rolf.siebrecht@t-online.de>");
MODULE_DESCRIPTION("Philips SAA7146 core driver");
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,10)
MODULE_LICENSE("GPL");
#endif

int __devinit
saa7146_core_init (void) 
{
	int ret = 0;
	
fprintk (KERN_INFO "saa7146_core: ==> saa7146_core_init\n");

	/* first check for a pci bios */
	if (0 == pci_present ()) {
		printk (KERN_ERR "saa7146_core: PCI-BIOS not present or not accessable!\n");
		return -1;
	}

	ret = pci_module_init(&saa7146_pci_driver);

	if (0 != saa7146_num) {
		printk (KERN_INFO "saa7146_core: %d SAA7146 chipset(s) found.\n", saa7146_num);
	}
	return ret;

} /* saa7146_core_init() */

void __devexit
saa7146_core_cleanup (void) 
{

fprintk (KERN_INFO "saa7146_core: ==> saa7146_core_cleanup\n");

	pci_unregister_driver(&saa7146_pci_driver);

} /* saa7146_core_cleanup() */

module_init(saa7146_core_init);
module_exit(saa7146_core_cleanup);

