/*
    drp3510II.c		A driver for Micronas Intermetall DRP3510A 
			Digital Radio Processor

    Copyright (C) 2000,2001 Rolf Siebrecht <rolf.siebrecht@t-online.de>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/*
 *  Derived from
 *
 *  drp3510.c  MICRONAS INTERMETALL DRP3510 digital radio processor driver
 *
 *  (c) 1999-2000 Peter Schlaf <peter.schlaf@org.chemie.uni-giessen.de>
 */

#include <linux/version.h>
#include <linux/kernel.h>
#include <linux/module.h>

#if CONFIG_MODVERSIONS==1
#define MODVERSIONS
#include <linux/modversions.h>
#endif

#include <linux/init.h>
#include <linux/malloc.h>
#include <linux/i2c.h>

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,3,0)
# include "kcompat24.h"
#endif

#include "drp3510II.h"

#ifdef MODULE
MODULE_PARM(debug, "i");
MODULE_PARM(adapter, "s");
#endif

static int debug = 0;	/* module load parameter */
static char *adapter = NULL;

#define dprintk	if (debug) printk

/* I2C addresses to scan */
static unsigned short int normal_i2c[] = { I2C_DRP3510, I2C_CLIENT_END };
static unsigned short int normal_i2c_range[] = { I2C_CLIENT_END };

/* magic definition of all other variables and things */
I2C_CLIENT_INSMOD;

/* unique ID allocation */
static int drp3510_id = 0;

static struct i2c_driver drp_driver;

/*****************************************************************************/

/* write to a DRP3510 data register */
static int
drp3510_write_data (struct i2c_client *drp_client, unsigned int reg, unsigned long data)
{
        unsigned char buf[5] = {
		0x68,					/* b[0] r/w cmd = "write" */
           	0x90 | ((reg >> 4) & 0x0f),		/* b[1] 0x9 r1	*/
                ((reg << 4) & 0xf0) | (data & 0x0f),	/* b[2] r0  d0	*/
                (data >> 12) & 0xff,			/* b[3] d4  d3	*/
                (data >> 4) & 0xff			/* b[4] d2  d1	*/
	};
        int count = sizeof (buf);

#if 0	/* Too much output */        
dprintk (KERN_INFO "drp3510II(%d): ==> %s (reg=0x%x, data=0x%lx)\n", drp_client->id, __FUNCTION__, reg, data);
#endif

        if (i2c_master_send (drp_client, buf, count) != count) {
		printk (KERN_ERR "drp3510II(%d): I2C error, %s failed.\n", drp_client->id, __FUNCTION__);
		return -EIO;
	}
        
	return 0;
}


/* read from a DRP3510 data register */
static int
drp3510_read_data (struct i2c_client *drp_client, __u16 reg)
{
        int ret = 0;
        __u32 val = 0;
   	__u8 addr_buf[3] = {
           	0x68,				/* b[0] r/w cmd = "write" */
                0xd0 | ((reg >> 4) & 0x0f),	/* b[1] 0xd r1	*/
                (reg << 4) & 0xf0		/* b[2] r0  0	*/
        };
        int addr_count = sizeof (addr_buf);
        __u8 send_buf[1] = {
           	0x69				/* b[0] r/w cmd = "read" */
        };
        __u8 recv_buf[4];
        struct i2c_msg transfer_msgs[] = {
        {	
                drp_client->addr,
                drp_client->flags,
                sizeof (send_buf),
                send_buf
        },
        {
           	drp_client->addr,
                drp_client->flags | I2C_M_RD,
                sizeof (recv_buf),
                recv_buf
        } };
        int num_of_msgs = sizeof (transfer_msgs) / sizeof (transfer_msgs[0]);
        
	ret |= (addr_count != i2c_master_send (drp_client, addr_buf, addr_count));	/* send register address */
        ret |= (num_of_msgs != i2c_transfer (drp_client->adapter, transfer_msgs, num_of_msgs));

        val = (((__u32) recv_buf[3] << 16) & 0xf0000) | (((__u32) recv_buf[0] << 8) & 0xff00) | recv_buf[1];
        
	if (ret) {
		printk (KERN_ERR "drp3510II(%d): I2C error, %s failed.\n", drp_client->id, __FUNCTION__);
                return -EIO;
        }

	return val;
}


/* write to DRP3510 control register */
static int
drp3510_write_control (struct i2c_client *drp_client, __u16 data)
{
   	int ret;
        
dprintk (KERN_INFO "drp3510II(%d): ==> %s (data=0x%x).\n", drp_client->id, __FUNCTION__, data);

   	ret = i2c_smbus_write_word_data (drp_client, 0x6a, data);

	if (ret != 0) {
		printk (KERN_ERR "drp3510II(%d): I2C error, %s failed.\n", drp_client->id, __FUNCTION__);
		return -EIO;
	}
        
	return 0;
}


/* read DRP3510 status + index */
static int
drp3510_read_statusindex (struct i2c_client *drp_client)
{
	int ret;
        
        ret = i2c_smbus_read_word_data (drp_client, 0x69);
        
        if (ret < 0) {
		printk(KERN_ERR "drp3510II(%d): I2C error, %s failed.\n", drp_client->id, __FUNCTION__);
                return -EIO;
        }
        
dprintk (KERN_INFO "drp3510II(%d): ==> %s (data=0x%04x)\n", drp_client->id, __FUNCTION__, ret);

	return ret;
}

/* read DRP3510 ADR data field */
static __u8 *
drp3510_read_adrdata (struct i2c_client *drp_client, __u8 offset, __u8 count)
{
	struct drp3510 *drp = (struct drp3510 *) drp_client->data;
   	int ret = 0;
   	__u8 addr_buf[3] = {
           	0x68,	/* b[0] r/w cmd = "write"	*/
                0x60,	/* b[1] 0x60	*/
                0	/* b[2] later: offset count	*/
        };
        int addr_count = sizeof (addr_buf);
        __u8 send_buf[1] = {
           	0x69	/* b[0] r/w cmd = "read"	*/
        };
        struct i2c_msg transfer_msgs[] = {
        {	drp_client->addr,
                drp_client->flags,
                sizeof (send_buf),
                send_buf
        },
        {
           	drp_client->addr,
                drp_client->flags | I2C_M_RD,
                sizeof (drp->adrdata),		/* preliminary */
                drp->adrdata
        } };
        int num_of_msgs = sizeof (transfer_msgs) / sizeof (transfer_msgs[0]);
        
        if (offset > 9) offset = 9;
        if (count > 10) count = 10;
        if (count == 0) count = 1;

dprintk (KERN_INFO "drp3510II(%d): ==> %s (ofs=%d; cnt=%d)\n", drp_client->id, __FUNCTION__, offset, count);

        addr_buf[2] = (offset << 4) | (count & 0x0f);
        transfer_msgs[1].len = count << 1;
        
        ret |= (addr_count != i2c_master_send (drp_client, addr_buf, addr_count));

dprintk (KERN_INFO "drp3510II(%d): %s: i2c_master_send %s!\n", drp_client->id, __FUNCTION__, ret? "error" : "ok");

        ret |= (num_of_msgs != i2c_transfer (drp_client->adapter, transfer_msgs, num_of_msgs));

dprintk (KERN_INFO "drp3510II(%d): %s: i2c_transfer %s!\n", drp_client->id, __FUNCTION__, ret ? "error" : "ok");

        if (ret) {
           	printk (KERN_ERR "drp3510II(%d): I2C error, %s failed.\n", drp_client->id, __FUNCTION__);
                /* return -EIO;		can't return an error code here */
        }
        
        return drp->adrdata;
}


static int
drp3510_chip_init (struct i2c_client *drp_client)
{
   	struct drp3510 *drp = (struct drp3510 *) drp_client->data;
        int ret = 0;
        
dprintk (KERN_INFO "drp3510II(%d): ==> %s\n", drp_client->id, __FUNCTION__);

        /* FIXME!! Initialize DRP3510 chip here as far as needed */

        memset (drp, 0, sizeof (struct drp3510));
        
        drp->adapter = drp_client->adapter;
        /* FIXME!! set more variables of struct drp to initial values */
        
        if (ret != 0) {
           	printk (KERN_ERR "drp3510II(%d): %s failed.\n", drp_client->id, __FUNCTION__);
                return ret;
        }
        
   	return 0;
}

/*****************************************************************************/

/* this function is called by i2c_probe */
static int
drp3510_detect (struct i2c_adapter *adap, int addr, unsigned short int flags, int kind)
{
   	struct i2c_client *drp_client;
        struct drp3510 *drp;
        int ret;

dprintk (KERN_INFO "drp3510II: ==> %s (adap=%s; addr=0x%02x)\n", __FUNCTION__, adap->name, addr);

        /* let's see whether this adapter can support what we need */
        if (i2c_check_functionality (adap, I2C_FUNC_I2C | I2C_FUNC_SMBUS_WORD_DATA) == 0) {
           	return 0;
        }

        /* allocate memory for client structure */
        drp_client = kmalloc (sizeof (struct i2c_client), GFP_KERNEL);
        if (drp_client == NULL) {
           	return -ENOMEM;
        }

        /* fill client structure */
        drp_client->id = drp3510_id++;
	sprintf (drp_client->name, "Micronas DRP3510(%d)", drp_client->id);
        drp_client->flags = 0;
        drp_client->addr = addr;
        drp_client->adapter = adap;
        drp_client->driver = &drp_driver;
        drp_client->data = NULL;

        printk (KERN_INFO "drp3510II: %s detected at i2c address 0x%02x.\n", drp_client->name, drp_client->addr);

        /* allocate memory for drp structure */
        drp_client->data = drp = kmalloc (sizeof (struct drp3510), GFP_KERNEL);
        if (drp == NULL) {
           	kfree (drp_client);
                return -ENOMEM;
        }

        /* tell the i2c layer a new client has arrived */
        ret = i2c_attach_client (drp_client);

        if (ret != 0) {
           	printk (KERN_WARNING "drp3510II: Client registration failed, %s @ 0x%02x not attached.\n", drp_client->name, drp_client->addr);
                kfree (drp_client->data);
           	kfree (drp_client);
                return ret;
        }

        printk (KERN_INFO "drp3510II: %s @ 0x%02x attached to adapter %s.\n", drp_client->name, drp_client->addr, drp_client->adapter->name);

        /* DRP3510 chip init */
        ret = drp3510_chip_init (drp_client);

        if (ret != 0) {
           	printk (KERN_WARNING "drp3510II: Init of %s @ 0x%02x failed, continuing anyway.\n", drp_client->name, drp_client->addr);
                return ret;
        }

   	return 0;
}


static int
drp3510_attach (struct i2c_adapter *adap)
{

dprintk (KERN_INFO "drp3510II: ==> drp3510_attach (adap=%s)\n", adap->name);

	if (adapter != NULL)
		if (strcmp (adap->name, adapter))
			return 0;
   	return i2c_probe (adap, &addr_data, &drp3510_detect);
}


static int
drp3510_detach (struct i2c_client *drp_client)
{
   	int ret;

dprintk (KERN_INFO "drp3510II: ==> drp3510_detach (client=%s; addr=0x%02x; adap=%s)\n", drp_client->name, drp_client->addr, drp_client->adapter->name);

        /* FIXME!! disable ADR, mute ADR output, disable PIO DMA mode,... */

        ret = i2c_detach_client (drp_client);

        if (ret != 0) {
           	printk (KERN_WARNING "drp3510II: Client deregistration failed, %s @ 0x%02x not detached.\n", drp_client->name, drp_client->addr);
                return ret;
        }

        printk (KERN_INFO "drp3510II: Client %s @ 0x%02x detached from adapter %s.\n", drp_client->name, drp_client->addr, drp_client->adapter->name);

        kfree (drp_client->data);
        kfree (drp_client);

        return 0;
}


static int 
drp3510_command (struct i2c_client *drp_client, unsigned int cmd, void *arg)
{
	/* struct drp3510 *drp = (struct drp3510 *) drp_client->data; */
        
        __u16 *sarg = arg;	/* status pointer */
        __u8  **darg = arg;	/* data field pointer */
	int ret = 0;
	
	switch (cmd) {
		case DRP_ADR:
			ret |= drp3510_write_control (drp_client, 0x0100);	/* reset drp */
			ret |= drp3510_write_control (drp_client, 0x0000);	/* release drp reset */
	
			ret |= drp3510_write_data (drp_client, 0xA8, 0x00000200);
			ret |= drp3510_write_data (drp_client, 0x67, 0x00008000);
			ret |= drp3510_write_data (drp_client, 0x60, 0x00070000);
			ret |= drp3510_write_data (drp_client, 0xF4, 0x00000000);
                        
dprintk (KERN_INFO "drp3510II(%d): ==> ioctl DRP_ADR\n", drp_client->id);

   			if (ret != 0) {
                           	return -EIO;
                        }
			
                        return 0;
                        
		case DRP_PIO_DMA:
                        
dprintk (KERN_INFO "drp3510II(%d): ==> ioctl DRP_PIO_DMA\n", drp_client->id);

			return drp3510_write_data (drp_client, 0x60, 0x00010800);


		case DRP_STATUS:
			*sarg = drp3510_read_statusindex (drp_client);
                        
dprintk (KERN_INFO "drp3510II(%d): ==> ioctl DRP_STATUS\n", drp_client->id);

			return ret;


		case DRP_ADR_DATA:
			*darg = drp3510_read_adrdata (drp_client, 0, 10);	/* no offset, 10 words -> 20 bytes */
                        
dprintk (KERN_INFO "drp3510II(%d): ==> ioctl DRP_ADR_DATA (address: 0x%p)\n", drp_client->id, darg);

			return ret;


		default:
                
dprintk (KERN_INFO "drp3510II(%d): Unknown ioctl cmd (0x%x)\n", drp_client->id, cmd); 

			return -ENOIOCTLCMD;
	}
}


void
drp3510_inc_use (struct i2c_client *drp_client)
{
#ifdef MODULE
   	MOD_INC_USE_COUNT;
#endif
}


void
drp3510_dec_use (struct i2c_client *drp_client)
{
#ifdef MODULE
   	MOD_DEC_USE_COUNT;
#endif
}


static struct i2c_driver drp_driver = {
	"drp3510II.o",
	I2C_DRIVERID_DRP3510,
	I2C_DF_NOTIFY,
	drp3510_attach,
	drp3510_detach,
	drp3510_command,
        drp3510_inc_use,
        drp3510_dec_use
};

/*****************************************************************************/

EXPORT_NO_SYMBOLS;

int __devinit
drp3510_init (void)
{
   	int ret;

        printk (KERN_INFO "drp3510II.o i2c driver\n");

        ret = i2c_add_driver (&drp_driver);

        if (ret != 0) {
           	printk (KERN_WARNING "drp3510II: Driver registration failed, module not inserted.\n");
                return ret;
        }

        if (drp3510_id == 0)
           	printk (KERN_WARNING "drp3510II: No hardware detected.\n");

        return 0;
}


void __devexit
drp3510_cleanup (void)
{
   	int ret;
        
        ret = i2c_del_driver (&drp_driver);
        
        if (ret != 0) {
           	printk (KERN_WARNING "drp3510II: Driver deregistration failed, module not removed.\n");
        }
}

/*****************************************************************************/

MODULE_AUTHOR ("Rolf Siebrecht <rolf.siebrecht@t-online.de>");
MODULE_DESCRIPTION ("Micronas Intermetall DRP3510A I2C driver");
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,10)
MODULE_LICENSE("GPL");
#endif

module_init(drp3510_init);
module_exit(drp3510_cleanup);

