#ifndef __SAA7146_CORE_H__
#define __SAA7146_CORE_H__

#include <asm/io.h>		/* definitions of u32 etc. */
#include <linux/i2c.h>

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,3,0)
# include "kcompat24.h"
# define virt_to_page	MAP_NR
#endif

/* maximum number of capture frames we support */
#define SAA7146_MAX_BUF		4
/* maximum number of saa7146s we support */
#define SAA7146_MAX_DEVICES	4
/* maximum number of extensions we support */
#define SAA7146_MAX_EXTENSIONS	4

/* stuff for writing to saa7146 */
#define saa7146_write(mem,adr,dat)    writel((dat),(mem+(adr)))
#define saa7146_read(mem,adr)         readl(mem+(adr))

#define min(x,y)	( ((x) < (y)) ? (x) : (y) )
#define max(x,y)	( ((x) > (y)) ? (x) : (y) )

struct saa7146 {
        char	name[32];	/* give it a nice name */
	int	nr;
	
	struct i2c_adapter	*i2c_adap;	
	struct pci_dev		*device;

	void	*data[SAA7146_MAX_EXTENSIONS];	/* data hooks for extensions */

	int (*command)(struct i2c_adapter *i, unsigned int cmd, void *arg);

	unsigned char *mem;	/* pointer to mapped IO memory */
	int	revision;	/* chip revision; needed for bug-workarounds*/

	int	interlace;
	int	norm;
	int	format;
	__u16	brightness;
	__u16	contrast;
	__u16	saturation;
	int	vbi_running;
	int	vbi_p;
	__u32	*i2c_buf;			/* i2c memory */
	__u32	*grab_buf;			/* grabbing memory */
	__u32	*clip_buf;			/* clipping memory for mask or rectangle clipping*/
	__u32	*rps0_buf;			/* memory for rps0-program */
	__u32	*rps1_buf;			/* memory for rps1-program */
	__u8	*vbi_buf;			/* buffer for VBI data */

	unsigned int field;			/* current field count */
	unsigned int last_field;		/* last grabbed field */
		
	__u32	*page_table[SAA7146_MAX_BUF];	/* page_tables for buffers*/
	int	grab_stat[SAA7146_MAX_BUF];	/* status of grabbing buffers */

	int	grab_width[SAA7146_MAX_BUF];	/* pixel width of grabs */
	int	grab_height[SAA7146_MAX_BUF];	/* pixel height of grabs */
	int	grab_format[SAA7146_MAX_BUF];	/* video format of grabs */
	int	grab_port[SAA7146_MAX_BUF];	/* video port for grab */
	int	grab_queue[SAA7146_MAX_BUF];	/* wait queue for requested grabs */
	int	grab_queue_inp;			/* input pointer of grab queue */
	int	grab_queue_outp;		/* output pointer of grab queue */
	int	grab_frame;			/* currently grabbed frame */

        wait_queue_head_t	rps0_wq;	/* rps0 interrupt queue (=> capture) */
        wait_queue_head_t	rps1_wq;	/* rps1 interrupt queue (=> i2c, ...) */
	wait_queue_head_t	vbi_wq;
        spinlock_t		s_lock;
        struct	tq_struct	bh_handler;
        __u32	appeared_irq;
        
        /* --- administration stuff. */
	int (*client_register)(struct i2c_client *);
	int (*client_unregister)(struct i2c_client *);
};

#define	SAA7146_IRQ_RPS0  
#define	SAA7146_IRQ_RPS1 

struct saa7146_extension {
	char	name[32];
        __u32	handles_irqs;

        void (*irq_handler)(struct saa7146 *, u32, void *);
	
	int	(*command)(struct saa7146*, void*, unsigned int cmd, void *arg);

	int	(*attach)(struct saa7146*, void**);
	int	(*detach)(struct saa7146*, void**);

	void	(*inc_use)(struct saa7146*);
	void	(*dec_use)(struct saa7146*);
};

int	saa7146_add_extension (struct saa7146_extension* ext);
int	saa7146_del_extension (struct saa7146_extension* ext);

struct	saa7146* saa7146_get_handle (int i);

struct	saa7146_vbi_read_s {
	char		*buf;
	unsigned long	count;
	int		nonblock;
};

struct	saa7146_vbi_poll_s {
	struct file	*file;
	poll_table	*wait;
};

/* external grabbing states */
#define GBUFFER_UNUSED		0
#define GBUFFER_QUEUED		1
#define GBUFFER_GRABBING	2
#define GBUFFER_DONE		3

#define SAA7146_CORE_BASE	200

#define SAA7146_OPEN		_IO('d', (SAA7146_CORE_BASE+11))
#define SAA7146_CLOSE		_IO('d', (SAA7146_CORE_BASE+12))
#define	SAA7146_DO_MMAP		_IOW('d', (SAA7146_CORE_BASE+13), struct saa7146_mmap_s)
#define SAA7146_SET_DD1		_IOW('d', (SAA7146_CORE_BASE+14), u32)
#define SAA7146_DUMP_REGISTERS	_IOW('d', (SAA7146_CORE_BASE+15), u32)
/* SAA7146_CORE_BASE+16 is used by DVB driver, so we skip it */
#define SAA7146_FIELDNR		_IOR('d', (SAA7146_CORE_BASE+17), unsigned int)

/* this is for DVB driver */
#define SAA7146_SUSPEND		_IOW('d', (SAA7146_CORE_BASE+32), u32)
#define SAA7146_RESUME		_IOW('d', (SAA7146_CORE_BASE+33), u32)

#define SAA7146_VBI_OPEN	_IO('d', (SAA7146_CORE_BASE+50))
#define SAA7146_VBI_CLOSE	_IO('d', (SAA7146_CORE_BASE+51))
#define SAA7146_VBI_BUFSIZE	_IO('d', (SAA7146_CORE_BASE+52))
#define SAA7146_VBI_READ	_IOW('d', (SAA7146_CORE_BASE+53), struct saa7146_vbi_read_s)
#define SAA7146_VBI_POLL	_IOW('d', (SAA7146_CORE_BASE+54), struct saa7146_vbi_poll_s)

#endif

