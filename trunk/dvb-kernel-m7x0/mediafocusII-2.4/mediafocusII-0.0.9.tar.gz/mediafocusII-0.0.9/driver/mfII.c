/* 
    mfII - Video4Linux Kernel driver for TechniSat MediaFocus II.

    Copyright (C) 2000,2001 Rolf Siebrecht <rolf.siebrecht@t-online.de>
   
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

*/    

/*
 *  Derived from
 *
 *  mxb - frame grabber driver for the 'Multimedia eXtension Board'
 *        by Siemens - Nixdorf.
 *
 *  Copyright (C) 1998,1999 Michael Hunold <michael@mihu.de>
 */

#include <linux/version.h>
#include <linux/kernel.h>
#include <linux/module.h>

#if CONFIG_MODVERSIONS==1
#define MODVERSIONS
#include <linux/modversions.h>
#endif

#include <linux/init.h>
#include <linux/delay.h>
#include <linux/ioctl.h>
#if 1
#include <linux/kmod.h>
#endif
#include <linux/i2c.h>
#include <linux/videodev.h>
#include <linux/video_decoder.h>

#include "../linux/tuner.h"
#include "../linux/videodev_priv.h"
#include "../linux/video_decoder_priv.h"

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,3,0)
# include "kcompat24.h"
#endif

#include "stv0056af.h"
#include "msp3400satII.h"
#include "drp3510II.h"
#include "saa7113h.h"
#include "ee24lc16.h"

#include "saa7146.h"
#include "saa7146_v4l.h"
#include "saa7146_core.h"

#include "mfII.h"

#ifdef MODULE
MODULE_PARM(debug,"i");
MODULE_PARM(vidmem,"l");
MODULE_PARM(vidlow,"l");
MODULE_PARM(saa7146,"1-4i");
MODULE_PARM(diseqc,"i");
#endif

static u32 vidmem	= 0;
static u32 vidlow	= 0;
static int diseqc	= 0;
static int debug	= 0;	/* module load parameter */
#define fprintk	if (debug > 0) printk
#define dprintk	if (debug > 1) printk

static int num_mfII = 0;
#define MAX_NUM_MFII	4

static struct mfII_struct mfII[MAX_NUM_MFII];

static int saa7146[MAX_NUM_MFII] = { -1, -1, -1, -1 };

/* Some initial settings of helper ICs */
#define INITIAL_ORBIT_POSITION		0		/* 1st pos. = 19,2�E */
#define INITIAL_TUNER_FREQUENCY		1464000000UL	/* RTL2 */
#define INITIAL_LNB_POLARITY		MSP_DIGCTR1_ON	/* H-pol */
#define INITIAL_22KHZ_STATE		STV_22KHZ_OFF	/* no 22kHz signal */

#if 0
#define INITIAL_SAA7113_GAIN		0
#endif
#define INITIAL_SAA7113_BRIGHTNESS	32768
#define INITIAL_SAA7113_CONTRAST	32768
#define INITIAL_SAA7113_SATURATION	32768
#define INITIAL_SAA7113_HUE		32768

#define INITIAL_SAA7146_BRIGHTNESS	32768
#define INITIAL_SAA7146_CONTRAST	32768
#define INITIAL_SAA7146_SATURATION	32768
#define INITIAL_SAA7146_DEPTH		16
#define INITIAL_SAA7146_PALETTE		VIDEO_PALETTE_RGB565;

/* ------------------------*/
/*       DiSEqC stuff      */
/* ------------------------*/

static int
diseqc_sendbit (struct mfII_struct *mfII, int databit)
{
	int i, ret = 0;

	/* STV0056AF: 22 kHz tone on */
	i = STV_22KHZ_ON;
	ret |= mfII->stv0056af->driver->command (mfII->stv0056af, STV_SET_22KHZ, &i);
	if (ret != 0) goto diseqc_sendbit_error;
	/* tone width according to data bit */
	udelay (databit ? 500 : 1000);

	/* STV0056AF: 22 kHz tone off */
	i = STV_22KHZ_OFF;
	ret |= mfII->stv0056af->driver->command (mfII->stv0056af, STV_SET_22KHZ, &i);
	if (ret != 0) goto diseqc_sendbit_error;
	/* pause width according to data bit */
	udelay (databit ? 1000 : 500);

diseqc_sendbit_error:
	if (ret != 0) {
		return -1;
	}

	return 0;
}

static int
diseqc_sendbyte (struct mfII_struct *mfII, __u8 databyte)
{
	int i, b, p = 1, ret = 0;

	for (i = 7; i >= 0; i--) {
		b = (databyte >> i) & 0x01;
		p ^= b;				/* compute parity bit */
		ret |= diseqc_sendbit (mfII, b);
		if (ret != 0) goto diseqc_sendbyte_error;
	}
	ret |= diseqc_sendbit (mfII, p);	/* send parity bit */

diseqc_sendbyte_error:
	if (ret != 0) {
		return -1;
	}

	return 0;
}

static int
diseqc_sendmsg (struct mfII_struct *mfII, __u8 frame, __u8 address, __u8 command, __u8 *data)
{
	int i, ret = 0;

dprintk (KERN_INFO "mfII: ==> diseqc_sendmsg (fr=0x%02x; addr=0x%02x; cmd=0x%02x; cont22kHz=%s)\n", frame, address, command, mfII->current_22khz_state ? "on" : "off");

	/* turn continous 22 kHz signal off, if it is on yet */
	if (mfII->current_22khz_state) {
		i = STV_22KHZ_OFF;
		ret |= mfII->stv0056af->driver->command (mfII->stv0056af, STV_SET_22KHZ, &i);
		mdelay (15);
	}

	ret |= diseqc_sendbyte (mfII, frame);
	if (ret != 0) goto diseqc_sendmsg_error;
	ret |= diseqc_sendbyte (mfII, address);
	if (ret != 0) goto diseqc_sendmsg_error;
	ret |= diseqc_sendbyte (mfII, command);
	if (ret != 0) goto diseqc_sendmsg_error;
	if (data != NULL) ret |= diseqc_sendbyte (mfII, *data);	/* FIXME: caution, if number of data bytes is different from 1 ! */
	if (ret != 0) goto diseqc_sendmsg_error;

	mdelay (20);
	/* turn continous 22 kHz signal on, if necessary */
	if (mfII->current_22khz_state) {
		i = STV_22KHZ_ON;
		ret |= mfII->stv0056af->driver->command (mfII->stv0056af, STV_SET_22KHZ, &i);
	}

diseqc_sendmsg_error:
	if (ret != 0) {
		printk (KERN_ERR "mfII: diseqc_sendmsg: Can't send DiSEqC message.\n");
		return -1;
	}

	return 0;
}

static int
diseqc_reset (struct mfII_struct *mfII)
{
dprintk (KERN_INFO "mfII: ==> diseqc_reset\n");

	if (diseqc) {
		diseqc_sendmsg (mfII, 0xe0, 0x00, 0x00, NULL);
		diseqc_sendmsg (mfII, 0xe0, 0x00, 0x00, NULL);
	}
	return 0;
}

/* ==DiSEqC controlled action==			*/
/* Set orbit position, i.e. select a certain LNB*/
/* through DiSEqC Option switches plus DisEqC	*/
/* Position switches.				*/
/*						*/
/* 1st orbit position -> Option A/Position A	*/
/* 2nd   "      "     -> Option A/Position B	*/
/* 3rd   "      "     -> Option B/Position A	*/
/* 4th   "      "     -> Option B/Position B	*/
/*						*/
/* <orbitpos> is a bitmask:			*/
/* no bit set -> 1st orbit position		*/
/* bit 0 set  -> 2nd orbit position		*/
/* ...						*/
/* Only one bit of <orbitpos> at a time may be	*/
/* asserted.					*/
static int
set_orbit_position (struct mfII_struct *mfII, int orbitpos)
{
dprintk (KERN_INFO "mfII: ==> set_orbit_position (mask=0x%02x)\n", orbitpos);

	if (diseqc) {
		switch (orbitpos & 0x07) {
		case 0:	/* first orbit position */
			diseqc_sendmsg (mfII, 0xe0, 0x10, 0x23, NULL);	/* select Option A */
			diseqc_sendmsg (mfII, 0xe0, 0x10, 0x22, NULL);	/* select Position A */
			break;
		case 1:	/* second orbit position */
			diseqc_sendmsg (mfII, 0xe0, 0x10, 0x23, NULL);	/* select Option A */
			diseqc_sendmsg (mfII, 0xe0, 0x10, 0x26, NULL);	/* select Position B */
			break;
		case 2:	/* third orbit position */
			diseqc_sendmsg (mfII, 0xe0, 0x10, 0x27, NULL);	/* select Option B */
			diseqc_sendmsg (mfII, 0xe0, 0x10, 0x22, NULL);	/* select Position A */
			break;
		case 4:	/* fourth orbit position */
			diseqc_sendmsg (mfII, 0xe0, 0x10, 0x27, NULL);	/* select Option B */
			diseqc_sendmsg (mfII, 0xe0, 0x10, 0x26, NULL);	/* select Position B */
			break;
		default:
		} /* switch (orbitpos) */
	} /* if (diseqc) */
	return 0;
}

/* ------------------------*/
/* mfII - ioctl - routines */
/* and supporting funtions */
/* ------------------------*/

static int
mfII_ioctl (struct video_device *dev, unsigned int cmd, void *arg)
{
	struct mfII_struct *mfII = (struct mfII_struct *) dev;
	int ret = 0;


fprintk (KERN_INFO "mfII: ==> mfII_ioctl (cmd=0x%x)\n", cmd);

	switch (cmd)
	{
		/* Get capabilities */
		case VIDIOCGCAP:
		{
			struct video_capability v_cap;

dprintk (KERN_INFO "mfII: ==> VIDIOCGCAP\n");

			strcpy (v_cap.name, &dev->name[0]);
			
			v_cap.type 	= mfII->video.type;	/* take over values from driver registration */
			v_cap.channels	= MFII_CHANNELS;	
			v_cap.audios	= MFII_AUDIOS;
			v_cap.maxwidth	= MFII_MAXWIDTH;
			v_cap.maxheight	= MFII_MAXHEIGHT;
			v_cap.minwidth	= MFII_MINWIDTH;
			v_cap.minheight	= MFII_MINHEIGHT;
			
			if (copy_to_user ((struct video_capability *) arg, &v_cap, sizeof (v_cap)))
				return -EFAULT;
                                
			return 0;
		}
		
                
		/* Get channel info (video sources) */
		case VIDIOCGCHAN:
		{
			struct video_channel v_chan;

			if (copy_from_user (&v_chan, (struct video_channel *) arg, sizeof (v_chan)))
				return -EFAULT;

dprintk (KERN_INFO "mfII: ==> VIDIOCGCHAN (ch=%d)\n", v_chan.channel);

			if ((v_chan.channel < 0) || (v_chan.channel > MFII_CHANNELS-1))
				return -EINVAL;

			memcpy (&v_chan, &mfII_channels[v_chan.channel], sizeof (v_chan));

			/* return current norm here */
			v_chan.norm = mfII->current_video_norm;
			
			if (copy_to_user ((struct video_channel *) arg, &v_chan, sizeof (v_chan)))
				return -EFAULT;
                                
			return 0;
		}
		
		
                /* Set channel (video source) */
		case VIDIOCSCHAN:
		{
			struct video_channel v_chan;
			int stv_arg, decoder_arg, msp_lsp_arg, msp_scart_arg;
                        
			if (copy_from_user (&v_chan, (struct video_channel *) arg, sizeof (v_chan)))
				return -EFAULT;

dprintk (KERN_INFO "mfII: ==> VIDIOCSCHAN (ch=%d; norm=0x%x)\n", v_chan.channel, v_chan.norm);

			/* check if channel number is valid */
			if ((v_chan.channel < 0) || (v_chan.channel > MFII_CHANNELS-1))
				return -EINVAL;
				
			/* check if requested norm is supported */
			if (v_chan.norm != VIDEO_MODE_PAL 
			    && v_chan.norm != VIDEO_MODE_NTSC
 			    && v_chan.norm != VIDEO_MODE_SECAM)
				return -EINVAL;
                                   			/* defaults: */
                        stv_arg = STV_NORMAL_VIDEO;	/* stv0056af sends clamped video from tuner to saa7113h */
                        decoder_arg = DECODER_INPUT_MODE0;	/* saa7113h receives CVBS video from stv0056af */
                        msp_lsp_arg = MSP_DEM_SRC;	/* FM demodulator is source of MSP3400 "loudspeaker" output */
                        msp_scart_arg = MSP_DEM_SRC;	/* FM demodulator is source of MSP3400 internal "SCART" output */
                        
			switch (v_chan.channel) {

                           	/* Sat tuner */
				case VCHAN_TUNER:
				{
					break;				
				}
                                
                                /* Sat tuner with external crypt decoder */
				case VCHAN_TUNER_DECODER:
				{
                                   	stv_arg = STV_DECODER_RET;	/* stv0056af sends video from Mini-DIN to saa7113h */
					break;
				}
                                
                                /* Composite Video from Mini-DIN plug */
				case VCHAN_C_VIDEO:
				{
                                   	stv_arg = STV_NOTHING;		/* stv0056af sends nothing to saa7113h */
                                        decoder_arg = DECODER_INPUT_MODE2;	/* saa7113h receives CVBS video from Mini-DIN */
                                        msp_lsp_arg = MSP_SCART_SRC;	/* loudspeaker source is SCART (MSP internal input) */
                                        msp_scart_arg = MSP_NONE_SRC;	/* SCART (MSP internal output) disabled */
					break;
				}
                                
                                /* S-VHS Video from Mini-DIN plug */
				case VCHAN_S_VIDEO:
				{
                                   	stv_arg = STV_NOTHING;		/* stv0056af sends nothing to saa7113h */
                                        decoder_arg = DECODER_INPUT_MODE9;	/* saa7113h receives SVHS video from Mini-DIN */
                                        msp_lsp_arg = MSP_SCART_SRC;	/* loudspeaker source is (MSP-internal) SCART */
                                        msp_scart_arg = MSP_NONE_SRC;	/* SCART (MSP internal output) disabled */
					break;
				}
			}

                        /* select input for STV0056AF S1 output */
			ret = mfII->stv0056af->driver->command (mfII->stv0056af, STV_SET_SCART1, &stv_arg);
                        if (ret != 0) {
				printk (KERN_ERR "mfII: VIDIOCSCHAN: Can't address STV0056AF to select S1 video source.\n");
                                return ret;
                        }

			/* select input mode for SAA7113H */
			ret = mfII->saa7113h->driver->command (mfII->saa7113h, DECODER_SET_INPUT, &decoder_arg);
                        if (ret != 0) {
                           	printk (KERN_ERR "mfII: VIDIOCSCHAN: Can't address SAA7113H to select input mode.\n");
                                return ret;
			}			

			/* select source for MSP3400C loudspeaker output */
                        ret = mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SLCT_LSP_SRC, &msp_lsp_arg);
   			if (ret != 0) {
                           	printk (KERN_ERR "mfII: VIDIOCSCHAN: Can't address MSP3400C to select loudspeaker source.\n");
                           	return ret;
                        }
                        /* mediafocusII doesn't use headphone output */
                        
                        /* select source for (internal) MSP3400C SCART output */
                        ret = mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SLCT_SCART_SRC, &msp_scart_arg);
                        if (ret != 0) {
                           	printk (KERN_ERR "mfII: VIDIOCSCHAN: Can't address MSP3400C to select SCART source.\n");
                                return ret;
                        }
                        
			/* keep current channel in mind */
			mfII->current_channel = v_chan.channel;
                        
                       	/* FIXME!! switch norm in STV0056AF */
                        
                       	/* switch norm in SAA7113H */
			ret = mfII->saa7113h->driver->command (mfII->saa7113h, DECODER_SET_NORM, &v_chan.norm);
			if (ret != 0) {
				printk (KERN_ERR "mfII: VIDIOCSCHAN: Can't address SAA7113H to select video norm.\n");
				return ret;
			}

			/* switch norm in SAA7146AH */
			ret = mfII->spci->command (mfII->saa7146, SAA7146_V4L_SNORM, &v_chan.norm);
			if (ret != 0) {
				printk (KERN_ERR "mfII: VIDIOCSCHAN: SAA7146 driver rejects selection of video norm.\n");
				return ret;
			}

			/* keep current norm in mind */
			mfII->current_video_norm = v_chan.norm;
                        
			return 0;
		}
		
                
		/* Get tuner abilities */
		case VIDIOCGTUNER:
		{
			struct video_tuner vt;

			if (copy_from_user (&vt, (struct video_tuner *) arg, sizeof (vt)))
				return -EFAULT;
			
			if ((vt.tuner < 0) || (vt.tuner > MFII_TUNERS-1))
				return -EINVAL;

			/* fill the structure */
                        memcpy (&vt, &mfII_tuners[vt.tuner], sizeof (vt));
			vt.mode = mfII->current_video_norm;
		
			/* fill in signal strength */
			ret = mfII->sp5055->driver->command (mfII->sp5055, TUNER_GET_SIGNAL, &vt.signal);
                        if (ret != 0) {
                           	printk (KERN_ERR "mfII: VIDIOCGTUNER: Can't address tuner chip to get signal strength.\n");
                                return ret;
                        }

dprintk (KERN_INFO "mfII: ==> VIDIOCGTUNER (tuner=%d; lo=%ld; hi=%ld; flags=0x%08x; norm=%d; sig=%d)\n", vt.tuner, vt.rangelow, vt.rangehigh, vt.flags, vt.mode, vt.signal);

			if (copy_to_user ((struct video_tuner *) arg, &vt, sizeof (vt)))
				return -EFAULT;

			return 0;
		}
		
                
		/* Set tuner for the current channel */
		case VIDIOCSTUNER:
		{
			struct video_tuner vt;

			if (copy_from_user (&vt, (struct video_tuner *) arg, sizeof (vt)))
				return -EFAULT;

dprintk (KERN_INFO "mfII: ==> VIDIOCSTUNER (tuner=%d; norm=0x%x)\n", vt.tuner, vt.mode);

                        if ((vt.tuner < 0) || (vt.tuner > MFII_TUNERS-1))
 				return -EINVAL;
 				
			/* check if norm is supported */
			if (vt.mode != VIDEO_MODE_PAL 
			    && vt.mode != VIDEO_MODE_NTSC
 			    && vt.mode != VIDEO_MODE_SECAM)
				return -EINVAL;

                        /* FIXME!! switch norm in STV0056AF */
                        
			/* switch norm in SAA7113H */
			ret = mfII->saa7113h->driver->command (mfII->saa7113h, DECODER_SET_NORM, &vt.mode);
                        if (ret != 0) {
                           	printk (KERN_ERR "mfII: VIDIOCSTUNER: Can't address SAA7113H to select video norm.\n");
                                return ret;
			}

			/* switch norm in SAA7146AH */
			ret = mfII->spci->command (mfII->saa7146, SAA7146_V4L_SNORM, &vt.mode);
			if (ret != 0) {
				printk (KERN_ERR "mfII: VIDIOCSTUNER: SAA7146 driver rejects selection of video norm.\n");
				return ret;
			}

			/* keep current norm in mind */
			mfII->current_video_norm = vt.mode;
			/* keep current tuner in mind */
                        mfII->current_tuner = vt.tuner;

			return 0;
		}
		
                
		/* Get tuner frequency */
		/* mediafocusII: returned value may contain control flags in bits >= 16 */
		case VIDIOCGFREQ:
		{
			unsigned long int v = mfII->current_freq;

dprintk (KERN_INFO "mfII: ==> VIDIOCGFREQ (freq=%ld)\n", v);

			if (copy_to_user ((unsigned long int *) arg, &v, sizeof (v)))
				return -EFAULT;
				
			return 0;
		}


		/* Set tuner frequency */
		/* mediafocusII: bits >= 16 may contain additional control flags */
		case VIDIOCSFREQ:
		{
                   	unsigned long int freq, tuner_freq;
			int volume, iarg, orbitpos;

			if (copy_from_user (&freq, (unsigned long int *) arg, sizeof (freq)))
				return -EFAULT;

dprintk (KERN_INFO "mfII: ==> VIDIOCSFREQ (freq=%ld; current audio=%smuted)\n", freq, (mfII->current_audio_state) ? "not " : "");

   			if (((freq & 0xffff) < mfII_tuners[mfII->current_tuner].rangelow) || ((freq & 0xffff) > mfII_tuners[mfII->current_tuner].rangehigh))
                           	return -EINVAL;

			/* mute audio to avoid strange tuning noises */	
			if (1 == mfII->current_audio_state) {
                           	mfII->msp3400c->driver->command (mfII->msp3400c, MSP_GET_VOLUME, &volume);
				mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SWITCH_MUTE, NULL);
			}

			mdelay (TUNER_NOISE_DELAY);

			/* make "orbit" bits right-aligned */
			orbitpos = freq;
			iarg = POS2ND;
			while (!(iarg & 1)) {
				orbitpos >>= 1;
				iarg >>=1;
			}
			orbitpos &= 0x0f;
			/* select orbit position if necessary */
			if (mfII->current_orbit_position != orbitpos) {
				set_orbit_position (mfII, orbitpos);
				mfII->current_orbit_position = orbitpos;
			}

			/* tune in desired frequency */
			tuner_freq = ((freq & 0x0000ffff) >> 4) * 1000000;	/* mask off control flags and convert to Hz */
			ret = mfII->sp5055->driver->command (mfII->sp5055, TUNER_SET_TVFREQ, &tuner_freq);
                        if (ret != 0) {
                           	printk (KERN_ERR "mfII: VIDIOCSFREQ: Can't address tuner chip to set frequency.\n");
                                return ret;
                        }

                        /* switch MSP3400C pin "DCTR1" according to LNB polarity */
                        if (freq & VPOL) {
                           	iarg = MSP_DIGCTR1_OFF;	/* polarity = V -> LNB voltage = 14 V */
                        } else {
                           	iarg = MSP_DIGCTR1_ON;	/* polarity = H -> LNB voltage = 18 V */
                        }
                        ret = mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SET_DIGCTR1, &iarg);
                        if (ret != 0) {
                           	printk (KERN_ERR "mfII: VIDIOCSFREQ: Can't address MSP3400C to select LNB polarity.\n");
   				return ret;
                        }

                        /* switch STV0056AF pin "IO" according to 22 kHz signal state */
                        if (freq & HIBAND) {
                           	iarg = STV_22KHZ_ON;	/* 22 kHz tone enabled */
                        } else {
                           	iarg = STV_22KHZ_OFF;	/* 22 kHz tone disabled */
                        }
                        ret = mfII->stv0056af->driver->command (mfII->stv0056af, STV_SET_22KHZ, &iarg);
                        if (ret != 0) {
                           	printk (KERN_ERR "mfII: VIDIOCSFREQ: Can't address STV0056AF to select 22 kHz state.\n");
   				return ret;
                        }
			if (freq & HIBAND)
				mfII->current_22khz_state = 1;
			else
				mfII->current_22khz_state = 0;

			mdelay (TUNER_NOISE_DELAY);

			/* restore audio if it should not be muted */
			if (1 == mfII->current_audio_state) {
				mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SET_VOLUME, &volume);
			}

			/* keep current tuner frequency in mind */
			mfII->current_freq = freq;
                        
			return 0;
		}


		/* Get frame buffer */
		case VIDIOCGFBUF:
		{
			struct video_buffer vb;

			if (0 != (ret = mfII->spci->command (mfII->saa7146, SAA7146_V4L_GFBUF, &vb))) {
				printk (KERN_WARNING "mfII: VIDIOCGFBUF: Error during SAA7146_V4L_GFBUF ioctl call.\n");
				return ret;
			}

dprintk (KERN_INFO "mfII: ==> VIDIOCGFBUF (base=%p; w=%d; h=%d; d=%d; bpl=%d)\n", vb.base, vb.width, vb.height, vb.depth, vb.bytesperline);

			if (copy_to_user ((struct video_buffer *) arg, &vb, sizeof (vb)))
				return -EFAULT;

			return 0;
		}
		
                
		/* Set frame buffer - root only */
		case VIDIOCSFBUF:
		{
			struct video_buffer vb;
			u32 vid = (vidmem << 16) | vidlow;
			
			if (!capable (CAP_SYS_ADMIN) && !capable (CAP_SYS_RAWIO))
				return -EPERM;

			if (copy_from_user (&vb, (struct video_buffer *) arg, sizeof (vb)))
				return -EFAULT;
	
dprintk (KERN_INFO "mfII: ==> VIDIOCSFBUF (base=%p; w=%d; h=%d; d=%d; bpl=%d)\n", vb.base, vb.width, vb.height, vb.depth, vb.bytesperline);

			/* see if �vidmem�-override is requested */
			if (0 != vidmem) {
				printk (KERN_INFO "mfII: VIDIOCSFBUF: video memory base 0x%p overridden by insmod option 0x%p.\n", vb.base, (void *) vid);
				vb.base = (void *) vid;
			}

			if (0 != (ret = mfII->spci->command (mfII->saa7146, SAA7146_V4L_SFBUF, &vb))) {
				printk (KERN_WARNING "mfII: VIDIOCSFBUF: Error during SAA7146_V4L_SFBUF ioctl call.\n");
				return ret;
			}

			return 0;
		}
		
                
		/* Get video overlay window */
		case VIDIOCGWIN:
		{
			struct video_window vw;

			memcpy (&vw, &(mfII->current_overlay_win), sizeof (vw));

dprintk (KERN_INFO "mfII: ==> VIDIOCGWIN (x=%d; y=%d; w=%d; h=%d; key=0x%08x; flags=0x%08x\n", vw.x, vw.y, vw.width, vw.height, vw.chromakey, vw.flags);

			if (copy_to_user ((struct video_window *) arg, &vw, sizeof (vw)))
				return -EFAULT;
                
			return 0;
		}


		/* Set video overlay window */
		case VIDIOCSWIN:
		{
			struct video_window vw;
			
			if (copy_from_user (&vw, (struct video_window *) arg, sizeof (vw)))
				return -EFAULT;

dprintk (KERN_INFO "mfII: ==> VIDIOCSWIN (x=%d; y=%d; w=%d; h=%d; key=0x%08x; flags=0x%08x; clipcnt=%d)\n", vw.x, vw.y, vw.width, vw.height, vw.chromakey, vw.flags, vw.clipcount);

			if ((vw.width < MFII_MINWIDTH) || (vw.width > MFII_MAXWIDTH) || (vw.height < MFII_MINHEIGHT) || (vw.height > MFII_MAXHEIGHT))
				return -EINVAL;
				
			/* neither flags nor chroma key allowed */
			if (vw.flags || vw.chromakey)
				return -EINVAL;

			if (0 != (ret = mfII->spci->command (mfII->saa7146, SAA7146_V4L_SWIN, &vw))) {
				printk (KERN_WARNING "mfII: VIDIOCSWIN: Error during SAA7146_V4L_SWIN ioctl call.\n");
				return ret;
			}

			/* FIXME: only those values are saved in mfII struct which are really accepted by saa7146 */
#if 0
			mfII->spci->command (mfII->saa7146, SAA7146_V4L_GWIN, &vw);
#endif
			memcpy (&(mfII->current_overlay_win), &vw, sizeof (vw));

			return 0;
		}


		/* Get image properties */
		case VIDIOCGPICT:
		{
			struct video_picture vp;
			
			memcpy (&vp, &(mfII->current_overlay_pict), sizeof (vp));

dprintk (KERN_INFO "mfII: ==> VIDIOCGPICT (bri=%d; con=%d; sat=%d; hue=%d; dep=%d; pal=%d)\n", vp.brightness, vp.contrast, vp.colour, vp.hue, vp.depth, vp.palette);

			if (copy_to_user ((struct video_picture *) arg, &vp, sizeof (vp)))
				return -EFAULT;

			return 0;
		}


		/* Set image properties */
		case VIDIOCSPICT:
		{
			struct video_picture vp;
			__u16 hue;

			if (copy_from_user (&vp, (struct video_picture *) arg, sizeof (vp)))
				return -EFAULT;

dprintk (KERN_INFO "mfII: ==> VIDIOCSPICT (bri=%d; con=%d; sat=%d; hue=%d; dep=%d; pal=%d)\n", vp.brightness, vp.contrast, vp.colour, vp.hue, vp.depth, vp.palette);

			hue = vp.hue;
			/* set "brightness", "contrast" + "saturation" only in SAA7146AH */
			if (0 != (ret = mfII->spci->command (mfII->saa7146, SAA7146_V4L_SPICT, &vp))) {
				printk (KERN_WARNING "mfII: VIDIOCSPICT: Error during SAA7146_V4L_SPICT ioctl call.\n");
				return ret;
			}
			/* get those values back which are really accepted by SAA7146AH... */
			mfII->spci->command (mfII->saa7146, SAA7146_V4L_GPICT, &vp);
			/* ...and keep them in mind */
			memcpy (&(mfII->current_overlay_pict), &vp, sizeof (struct video_picture));
                        
                        /* set "hue" only in SAA7113H */
                        ret |= mfII->saa7113h->driver->command (mfII->saa7113h, DECODER_GET_PICTURE, &vp);	/* get existing values */
                        vp.hue = hue;	/* update "hue" */
                        ret |= mfII->saa7113h->driver->command (mfII->saa7113h, DECODER_SET_PICTURE, &vp);	/* set values */
			ret |= mfII->saa7113h->driver->command (mfII->saa7113h, DECODER_GET_PICTURE, &vp);	/* get _actual_ "hue" value */
                        if (ret != 0) {
                           	printk (KERN_ERR "mfII: VIDIOCSPICT: Can't address SAA7113H to set picture properties.\n");
   				return ret;
                        }
			/* keep _actual_ "hue" value in mind */
			mfII->current_overlay_pict.hue = vp.hue;
			
			return 0;
		}


		/* Start, end capture */
		case VIDIOCCAPTURE:
		{
			int v;

			if (copy_from_user (&v, (int *) arg, sizeof (v)))
				return -EFAULT;

dprintk (KERN_INFO "mfII: ==> VIDIOCCAPTURE (mode=%d)\n", v);

			if ((v != 0) && (v != 1))
				return -EINVAL;

			if (0 != (ret = mfII->spci->command (mfII->saa7146, SAA7146_V4L_CAPTURE, &v))) {
                        
dprintk (KERN_WARNING "mfII: VIDIOCCAPTURE: Error during SAA7146_V4L_CAPTURE ioctl call (ret=%d).\n", ret);

				return ret;
			}

			/* keep current overlay state in mind */
			mfII->current_overlay_state = v;

			return 0;
		}


		/* Memory map buffer info */
		case VIDIOCGMBUF:
		{
			struct video_mbuf v_mbuf;

dprintk (KERN_INFO "mfII: ==> VIDIOCGMBUF enter\n");

			if (0 != (ret = mfII->spci->command (mfII->saa7146, SAA7146_V4L_GMBUF, &v_mbuf))) {
                        
dprintk (KERN_WARNING "mfII: VIDIOCGMBUF: Error during SAA7146_V4L_GMBUF ioctl call (ret=%d).\n", ret);

				return ret;
			}

dprintk (KERN_INFO "mfII: ==> VIDIOCGMBUF exit (size=%d; frames=%d)\n", v_mbuf.size, v_mbuf.frames);

			if (copy_to_user ((struct video_mbuf *) arg, &v_mbuf, sizeof (v_mbuf)))
				return -EFAULT;

			return 0;
		}


		/* Grab frames */
	        case VIDIOCMCAPTURE:
		{
                        struct video_mmap v_map;

			if (copy_from_user (&v_map, (struct video_mmap *) arg, sizeof (v_map)))
				return -EFAULT;

dprintk (KERN_INFO "mfII: ==> VIDIOCMCAPTURE enter (fr=%d; fmt=%d; w=%d; h=%d)\n", v_map.frame, v_map.format, v_map.width, v_map.height);

			/* simply pass the structure for the requested frame-number to the corresponding saa7146-function ... */
			if (0 != (ret = mfII->spci->command (mfII->saa7146, SAA7146_V4L_MCAPTURE, &v_map))) {
                        
dprintk (KERN_WARNING "mfII: VIDIOCMCAPTURE: Error during SAA7146_V4L_MCAPTURE ioctl call (ret=%d).\n", ret);

				return ret;
			}

dprintk (KERN_INFO "mfII: ==> VIDIOCMCAPTURE exit\n");

			return 0;
		}


		 /* Sync with mmap grabbing */
	        case VIDIOCSYNC:
		{
                        int frame;
			int cap_arg = 1;        /* turn on capture */
			struct video_window vw;
			struct video_picture vp;
			
                        if (copy_from_user (&frame, (int *) arg, sizeof (frame)))
                                return -EFAULT;

dprintk (KERN_INFO "mfII: ==> VIDIOCSYNC enter (fr=%d)\n", frame);

			/* simply pass the requested frame-number to the corresponding saa7146-function ... */
			ret = mfII->spci->command (mfII->saa7146, SAA7146_V4L_SYNC, &frame);
			/* report any error, but don't report EINTR */
			if ((ret != 0) && (ret != -EINTR))
				printk (KERN_WARNING "mfII: VIDIOCSYNC: Error during SAA7146_V4L_SYNC ioctl call.\n");

dprintk (KERN_INFO "mfII: ==> VIDIOCSYNC exit (ret=%d)\n", ret);

			if (ret == -EINTR)
				return ret;
			  
			/* if overlay capture was running before, revive it now */
			if (0 != mfII->current_overlay_state) {
				memcpy (&vw, &(mfII->current_overlay_win), sizeof (struct video_window));
				mfII->spci->command (mfII->saa7146, SAA7146_V4L_SWIN, &vw);
				memcpy (&vp, &(mfII->current_overlay_pict), sizeof (struct video_picture));
				mfII->spci->command (mfII->saa7146, SAA7146_V4L_SPICT, &vp);
				mfII->spci->command (mfII->saa7146, SAA7146_V4L_CAPTURE, &cap_arg);
			}

			return ret;
		}
		
                
		/* Get audio info */	
		case VIDIOCGAUDIO:
		{
			struct video_audio va;
			
			if (copy_from_user (&va, (struct video_audio *) arg, sizeof (va)))
				return -EFAULT;

			if ((va.audio < 0) || (va.audio > MFII_AUDIOS-1))
				return -EINVAL;

			/* copy the desired structure to v_chan */
			memcpy (&va, &mfII_audios[va.audio], sizeof (va));

			/* is the sound muted ? */
			if (0 == mfII->current_audio_state) {
				va.flags |= VIDEO_AUDIO_MUTE;
			}

                        va.volume = mfII->current_volume;
                        va.bass = mfII->current_bass;
                        va.treble = mfII->current_treble;
                        va.balance = mfII->current_balance;
			/* va.mode = mfII->current_audio_mode; */
                        
dprintk (KERN_INFO "mfII: ==> VIDIOCGAUDIO (ch=%d; vol=%d; bass=%d; treble=%d; flags=0x%02x; mode=0x%02x)\n", va.audio, va.volume, va.bass, va.treble, va.flags, va.mode);

			if (copy_to_user ((struct video_audio *) arg, &va, sizeof (va)))
				return -EFAULT;

			return 0;
		}


		/* Audio source, mute etc */
		case VIDIOCSAUDIO:
		{
			struct video_audio va;
                        int iarg, ret = 0;

			if (copy_from_user (&va, (struct video_audio *) arg, sizeof (va)))
				return -EFAULT;

dprintk (KERN_INFO "mfII: ==> VIDIOCSAUDIO (ch=%d; vol=%d; bass=%d; treble=%d; flags=0x%02x; mode=0x%02x)\n", va.audio, va.volume, va.bass, va.treble, va.flags, va.mode);

   			if ((va.audio < 0) || (va.audio > MFII_AUDIOS-1))
                           	return -EINVAL;

                        mfII->current_audio_channel = va.audio;
                        
			/* shall we mute ? */
			if (0 != (va.flags & VIDEO_AUDIO_MUTE)) {
				mfII->current_audio_state = 0;
				if (0 != (ret = mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SWITCH_MUTE, NULL))) {
					printk (KERN_ERR "mfII: VIDIOCSAUDIO: Can't address sound decoder chip to mute audio.\n");
                                        return ret;
				}
				return 0;
			}
			/* mfII->current_audio_state = 1; */

			/* set the desired sound mode */
			if ((va.mode == VIDEO_SOUND_MONO) || (va.mode == VIDEO_SOUND_STEREO) || (va.mode == VIDEO_SOUND_LANG1) || (va.mode == VIDEO_SOUND_LANG2)) {
				if (0 != (ret = mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SET_STEREO, &va.mode))) {
                           		printk (KERN_ERR "mfII: VIDIOCSAUDIO: Can't address sound decoder chip to set sound mode.\n");
   					return ret;
   				}
                        	mfII->current_audio_mode = va.mode;
				switch (mfII->current_audio_mode) {
					case VIDEO_SOUND_MONO:
						mfII->current_left_carrier = 6500;
						mfII->current_right_carrier = 6500;
						break;
					case VIDEO_SOUND_STEREO:
						mfII->current_left_carrier = 7020;
						mfII->current_right_carrier = 7200;
						break;
					case VIDEO_SOUND_LANG1:
						mfII->current_left_carrier = 7380;
						mfII->current_right_carrier = 7560;
						break;
					case VIDEO_SOUND_LANG2:
						mfII->current_left_carrier = 7380;
						mfII->current_right_carrier = 7560;
				}

                                /* special treatment of irregular audio carrier frequencies */
                                if ((va.mode == VIDEO_SOUND_MONO) && ((mfII->current_freq & (MONO580 | MONO660 | MONO665)) != 0)) {
   					if (mfII->current_freq & MONO580) iarg = 5800;
                                        if (mfII->current_freq & MONO660) iarg = 6600;
                                        if (mfII->current_freq & MONO665) iarg = 6650;
                                        if (0 != (ret = mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SET_LEFT_FREQ, &iarg))) {
   						printk (KERN_ERR "mfII: VIDIOCSAUDIO: Can't address sound decoder chip to set special audio carrier frequency.\n");
                                                return ret;
                                        }
					mfII->current_left_carrier = iarg;
					mfII->current_right_carrier = mfII->current_left_carrier + 180;
                                }
			}

                        /* set volume */
                        if (0 != (va.flags & VIDEO_AUDIO_VOLUME)) {
                           	if (0 != (ret = mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SET_VOLUME, &va.volume))) {
                           		printk (KERN_ERR "mfII: VIDIOCSAUDIO: Can't address sound decoder chip to set volume level.\n");
   					return ret;
                                }
				mfII->current_volume = va.volume;
				if (mfII->current_volume == 0)
					mfII->current_audio_state = 0;
				else
					mfII->current_audio_state = 1;
                        }

                        /* set bass */
                        if (0 != (va.flags & VIDEO_AUDIO_BASS)) {
                           	if (0 != (ret = mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SET_BASS, &va.bass))) {
   					printk (KERN_ERR "mfII: VIDIOCSAUDIO: Can't address sound decoder chip to set bass level.\n");
                                        return ret;
                                }
                                mfII->current_bass = va.bass;
                        }

                        /* set treble */
                        if (0 != (va.flags & VIDEO_AUDIO_TREBLE)) {
                           	if (0 != (ret = mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SET_TREBLE, &va.treble))) {
   					printk (KERN_ERR "mfII: VIDIOCSAUDIO: Can't address sound decoder chip to set treble level.\n");
                                        return ret;
                                }
                                mfII->current_treble = va.treble;
                        }

/* dprintk (KERN_INFO "mfII: VIDIOCSAUDIO exit. mode:%d, flags:%d\n", va.mode, va.flags); */

			return 0;
		}


		/* Get attached units */
		case VIDIOCGUNIT:
		{
			struct video_unit vu;

   			memset (&vu, 0, sizeof (vu));
			vu.video = mfII->video.minor;
			vu.radio = mfII->radio.minor;
			vu.vbi = mfII->vbi.minor;
			vu.audio = VIDEO_NO_UNIT;
			vu.teletext = VIDEO_NO_UNIT;

dprintk (KERN_INFO "mfII: ==> VIDIOCGUNIT (vid=%d; vbi=%d; rad=%d; aud=%d; ttx=%d)\n", vu.video, vu.vbi, vu.radio, vu.audio, vu.teletext);

			if (copy_to_user ((struct video_unit *) arg, &vu, sizeof (vu)))
				return -EFAULT;
				
			return 0;
		}
		
#if 0                
		/* Video key event - to dev 255 is to all - cuts capture on all DMA windows with this key (0xFFFFFFFF == all) */
		case VIDIOCKEY:
		{
                
dprintk (KERN_INFO "mfII: ==> VIDIOCKEY\n");

			return 0;
		}


		case VIDIOCGCAPTURE:
		{
                
dprintk (KERN_INFO "mfII: ==> VIDIOCGCAPTURE\n");

			return 0;
		}
                
                
		case VIDIOCSCAPTURE:
		{
                
dprintk (KERN_INFO "mfII: ==> VIDIOCSCAPTURE\n");

			return 0;
		}
#endif

		case BTTV_FIELDNR:
		{
			unsigned int fieldnr;

			/* simply inquire the corresponding saa7146-function ... */
			if (0 != (ret = mfII->spci->command (mfII->saa7146, SAA7146_FIELDNR, &fieldnr))) {
                        
dprintk (KERN_WARNING "mfII: BTTV_FIELDNR: Error during SAA7146_FIELDNR ioctl call (ret=%d).\n", ret);

				return ret;
			}

dprintk (KERN_INFO "mfII: ==> BTTV_FIELDNR (nr=%d)\n", fieldnr);

			if (copy_to_user ((unsigned int *) arg, &fieldnr, sizeof (fieldnr)))
				    return -EFAULT;
				    
			return 0;
		}	

		case VIDIOCGEEPROM:
		{
			struct eeprom_s ee;

			if (!mfII->has_eeprom)
				return -ENODEV;
			if (copy_from_user (&ee, (struct eeprom_s *) arg, sizeof (ee)))
				return -EFAULT;
			if ((ee.addr >= 256) || (ee.count != 0))
				return -EINVAL;
			if (0 != (ret = mfII->eeprom->driver->command (mfII->eeprom, GET_EEPROM_DATA, &ee))) {
				printk (KERN_ERR "mfII: VIDIOCGEEPROM: Can't address EEPROM chip to read data.\n");
				return ret;
			}

dprintk (KERN_INFO "mfII: ==> VIDIOCGEEPROM\n");

			if (copy_to_user ((struct eeprom_s *) arg, &ee, sizeof (ee)))
				return -EFAULT;

			return 0;
		}


		case VIDIOCSEEPROM:
		{
			struct eeprom_s ee;

			if (!mfII->has_eeprom)
				return -ENODEV;
			if (copy_from_user (&ee, (struct eeprom_s *) arg, sizeof (ee)))
				return -EFAULT;

dprintk (KERN_INFO "mfII: ==> VIDIOCSEEPROM\n");

			if ((ee.addr >= 256) || (ee.count != 0))
				return -EINVAL;
			if (0 != (ret = mfII->eeprom->driver->command (mfII->eeprom, SET_EEPROM_DATA, & ee))) {
				printk (KERN_ERR "mfII: VIDIOCSEEPROM: Can't address EEPROM chip to write data.\n");
				return ret;
			}
			if (copy_to_user ((struct eeprom_s *) arg, &ee, sizeof (ee)))
				return -EFAULT;

			return 0;
		}


                default:
                
dprintk (KERN_INFO "mfII: Unknown ioctl command (cmd=0x%x)\n", cmd);

			return -ENOIOCTLCMD;
	}
        
	return 0;
}


static int
mfII_open (struct video_device *dev, int flags)
{
	struct mfII_struct *mfII = (struct mfII_struct *) dev;
        int arg, ret;

fprintk (KERN_INFO "mfII: ==> mfII_open\n");
	
	if (mfII->in_use != 0)
		return -EBUSY;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,3)
	MOD_INC_USE_COUNT;
#endif
	mfII->in_use++;

        if (0 != (ret = mfII->spci->command (mfII->saa7146, SAA7146_OPEN, NULL)))
		return ret;
        
        /* fixed: can't hear TV sound after closing radio app @ other than 7.02/7.20 carrier */
        ret = 0;
	arg = VIDEO_SOUND_STEREO;
        ret |= mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SET_STEREO, &arg);
        
#if 0	/* don't mute audio at this place any longer */
        
   	/* mute audio */
	ret |= mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SWITCH_MUTE, NULL);
        if (ret != 0)
           	printk (KERN_ERR "mfII: mfII_open: Can't address sound decoder chip to mute audio. Continuing anyway.\n");
#endif

	return 0;
}


static void
mfII_close (struct video_device *dev)
{
	struct mfII_struct *mfII = (struct mfII_struct *) dev;
	
fprintk (KERN_INFO "mfII: ==> mfII_close\n");

	/* turn off video */
	mfII->spci->command (mfII->saa7146, SAA7146_CLOSE, NULL);
	mfII->current_overlay_state = 0;
        
	/* don't mute audio here */
        
	mfII->in_use--;	
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,3)
        MOD_DEC_USE_COUNT;
#endif
}


static long int
mfII_read (struct video_device *v, char *buf, unsigned long int count, int nonblock)
{

fprintk (KERN_INFO "mfII: ==> mfII_read\n");

	return -EOPNOTSUPP;
}


static long int
mfII_write (struct video_device *v, const char *buf, unsigned long int count, int nonblock)
{

fprintk (KERN_INFO "mfII: ==> mfII_write\n");

	return -EOPNOTSUPP;
}


static int
mfII_mmap (struct video_device *dev, const char *addr, unsigned long size)
{
	struct mfII_struct *mfII = (struct mfII_struct *) dev;
	struct saa7146_mmap_s m;
	
fprintk (KERN_INFO "mfII: ==> mfII_mmap (addr=%p; size=0x%08x)\n", addr, (u32) size);

	m.adr = addr;
	m.size = size;

	if (0 != mfII->spci->command (mfII->saa7146, SAA7146_DO_MMAP, &m)) {
		printk (KERN_ERR "mfII: mfII_mmap failed!\n");
		return -1;
	}

	return 0;
}


static int
mfII_init_done (struct video_device *dev)
{

fprintk (KERN_INFO "mfII: ==> mfII_init_done\n");

	return 0;
}


/* template for video_device-structure */
static struct video_device
mfII_video_template =
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,3)
	owner:		THIS_MODULE,
#endif
	name:		"TechniSat MediaFocusII Video",
	type:		VID_TYPE_CAPTURE	|
			VID_TYPE_TUNER		|
			VID_TYPE_OVERLAY	|
			VID_TYPE_CLIPPING	|
			VID_TYPE_FRAMERAM	|
			VID_TYPE_SCALES,
	hardware:	VID_HARDWARE_SAA7146,
	open:		mfII_open,
	close:		mfII_close,
	read:		mfII_read,
	write:		mfII_write,		
	ioctl:		mfII_ioctl,
	mmap:		mfII_mmap,
	initialize:	mfII_init_done,
	minor:		-1
};
	
/******************************************************************************/

static int
mfII_radio_ioctl (struct video_device *dev, unsigned int cmd, void *arg)
{
	struct mfII_struct *mfII = (struct mfII_struct *) (dev - 1);
        int ret = 0;

fprintk (KERN_INFO "mfII: ==> mfII_radio_ioctl (cmd=0x%08x)\n", cmd);

	switch (cmd)
	{
		case VIDIOCGCAP:
		{
			struct video_capability vc;

dprintk (KERN_INFO "mfII: ==> ioctl VIDIOCGCAP (radio)\n");

			strcpy (vc.name, &dev->name[0]);
			vc.type = mfII->radio.type;
			vc.channels = 0;
			vc.audios = MFII_AUDIOS;
			vc.maxwidth = 0;
			vc.maxheight = 0;
			vc.minwidth = 0;
			vc.minheight = 0;

			if (copy_to_user ((struct video_capability *) arg, &vc, sizeof (vc)))
				return -EFAULT;

			return 0;
		}


		case VIDIOCGTUNER:
		case VIDIOCSTUNER:
		case VIDIOCGFREQ:
		case VIDIOCSFREQ:
		case VIDIOCGAUDIO:
		case VIDIOCSAUDIO:
                
	   		return mfII_ioctl ((struct video_device *) mfII, cmd, arg);

		/* private ioctl: get audio configs somewhat different from VIDIOCGAUDIO */
		case VIDIOCGAUDIO_SAT:
		{
			struct video_audio_sat vas;

			if (copy_from_user (&vas, (struct video_audio_sat *) arg, sizeof (vas)))
				return -EFAULT;
			if ((vas.audio < 0) || (vas.audio > MFII_AUDIOS-1))
				return -EINVAL;

			vas.volume = mfII->current_volume;
			vas.bass = mfII->current_bass;
			vas.treble = mfII->current_treble;
			vas.flags = VIDEO_AUDIO_MUTABLE | VIDEO_AUDIO_VOLUME
				| VIDEO_AUDIO_BASS | VIDEO_AUDIO_TREBLE;
			if (0 == mfII->current_audio_state)
				vas.flags |= VIDEO_AUDIO_MUTE;
			vas.mode = mfII->current_audio_mode;
			vas.l_carrier = mfII->current_left_carrier;
			vas.r_carrier = mfII->current_right_carrier;
			vas.mp2bufsize = MP2BUF_SIZE;

dprintk (KERN_INFO "mfII: ==> ioctl VIDIOCGAUDIO_SAT (audio=%d; flags=0x%x; vol=%d; bas=%d; tre=%d; mode=0x%x; left=%d; right=%d; mp2buf=%ld)\n", vas.audio, vas.flags, vas.volume, vas.bass, vas.treble, vas.mode, vas.l_carrier, vas.r_carrier, vas.mp2bufsize);

			if (copy_to_user ((struct video_audio_sat *) arg, &vas, sizeof (vas)))
				return -EFAULT;

			return 0;
		}

		/* private ioctl: set audio configs specially suited for satellite applications */
		case VIDIOCSAUDIO_SAT:
		{
			struct video_audio_sat vas;
                        int mute_unmute = 0;
                        
			if (copy_from_user (&vas, (struct video_audio_sat *) arg, sizeof (vas)))
				return -EFAULT;

dprintk (KERN_INFO "mfII: ==> ioctl VIDIOCSAUDIO_SAT (audio=%d; flags=0x%x; vol=%d; bas=%d; tre=%d; mode=0x%x; left=%d; right=%d)\n", vas.audio, vas.flags, vas.volume, vas.bass, vas.treble, vas.mode, vas.l_carrier, vas.r_carrier);

   			if ((vas.audio < 0) || (vas.audio > MFII_AUDIOS-1))
                           	return -EINVAL;

                        if ((vas.flags & VIDEO_AUDIO_MUTE) && (vas.flags & VIDEO_AUDIO_UNMUTE))
                           	return -EINVAL;

                        if ((vas.flags & VIDEO_AUDIO_MUTE) && (vas.flags & VIDEO_AUDIO_VOLUME))
                           	return -EINVAL;

                        if ((vas.flags & VIDEO_AUDIO_UNMUTE) && (vas.flags & VIDEO_AUDIO_VOLUME))
                           	return -EINVAL;

                        /* if "set mode!" and "set carrier!" are requested at the same time	*/
                        /* execute a mute-modify-delay-unmute sequence. But only if "mute!"	*/
                        /* or "unmute!" are not requested, too.					*/
                        if ((vas.flags & VIDEO_AUDIO_MODE) && (vas.flags & VIDEO_AUDIO_CARRIER)
                           && !(vas.flags & VIDEO_AUDIO_MUTE) && !(vas.flags & VIDEO_AUDIO_UNMUTE))
                              	mute_unmute = 1;
                                
                        mfII->current_audio_channel = vas.audio;
                        
			/* shall we mute? */
			if ((vas.flags & VIDEO_AUDIO_MUTE) || (mute_unmute)) {
				if (0 != (ret = mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SWITCH_MUTE, NULL))) {
					printk (KERN_ERR "mfII: VIDIOCSAUDIO_SAT: Can't address sound decoder chip to mute audio.\n");
                                        return ret;
				}
				mfII->current_audio_state = 0;
			}
                        
                        /* shall we set set volume level? */
                        if (vas.flags & VIDEO_AUDIO_VOLUME) {
                           	if (0 != (ret = mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SET_VOLUME, &vas.volume))) {
                           		printk (KERN_ERR "mfII: VIDIOCSAUDIO_SAT: Can't address sound decoder chip to set volume level.\n");
   					return ret;
                                }
                                mfII->current_volume = vas.volume;
                                if (mfII->current_volume != 0)
                                   	mfII->current_audio_state = 1;
                        }
			
                        /* shall we set bass level? */
                        if (vas.flags & VIDEO_AUDIO_BASS) {
                           	if (0 != (ret = mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SET_BASS, &vas.bass))) {
   					printk (KERN_ERR "mfII: VIDIOCSAUDIO_SAT: Can't address sound decoder chip to set bass level.\n");
                                        return ret;
                                }
                                mfII->current_bass = vas.bass;
                        }
                        
                        /* shall we set treble level? */
                        if (vas.flags & VIDEO_AUDIO_TREBLE) {
                           	if (0 != (ret = mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SET_TREBLE, &vas.treble))) {
   					printk (KERN_ERR "mfII: VIDIOCSAUDIO_SAT: Can't address sound decoder chip to set treble level.\n");
                                        return ret;
                                }
                                mfII->current_treble = vas.treble;
                        }

			/* shall we set the desired sound mode? */
			if (vas.flags & VIDEO_AUDIO_MODE) {
				if (0 != (ret = mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SET_STEREO, &vas.mode))) {
                           		printk (KERN_ERR "mfII: VIDIOCSAUDIO_SAT: Can't address sound decoder chip to set sound mode.\n");
   					return ret;
   				}
                        	mfII->current_audio_mode = vas.mode;
                                
				switch (mfII->current_audio_mode) {
					case VIDEO_SOUND_MONO:
						mfII->current_left_carrier = 6500;
						mfII->current_right_carrier = 6500;
						break;
					case VIDEO_SOUND_STEREO:
						mfII->current_left_carrier = 7020;
						mfII->current_right_carrier = 7200;
						break;
					case VIDEO_SOUND_LANG1:
						mfII->current_left_carrier = 7380;
						mfII->current_right_carrier = 7560;
						break;
					case VIDEO_SOUND_LANG2:
						mfII->current_left_carrier = 7380;
						mfII->current_right_carrier = 7560;
				}
                        }
                        
                        /* shall we set the audio carrier freqs? */
                        if (vas.flags & VIDEO_AUDIO_CARRIER) {
                           	if (0 != (ret = mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SET_LEFT_FREQ, &vas.l_carrier))) {
   					printk (KERN_ERR "mfII: VIDIOCSAUDIO_SAT: Can't address sound decoder chip to set left audio carrier.\n");
                                        return ret;
                                }
                                mfII->current_left_carrier = vas.l_carrier;
                                if (0 != (ret = mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SET_RIGHT_FREQ, &vas.r_carrier))) {
   					printk (KERN_ERR "mfII: VIDIOCSAUDIO_SAT: Can't address sound decoder chip to set right audio carrier.\n");
                                        return ret;
                                }
				mfII->current_right_carrier = vas.r_carrier;
                        }

                        if (mute_unmute)
                           	mdelay (AUDIO_NOISE_DELAY);
                                
                        /* shall we unmute? */
                        if ((vas.flags & VIDEO_AUDIO_UNMUTE) || (mute_unmute)) {
                                if (0 != (ret = mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SET_VOLUME, &mfII->current_volume))) {
   					printk (KERN_ERR "mfII: VIDIOCSAUDIO_SAT: Can't address sound decoder chip to unmute audio.\n");
                                        return ret;
                                }
                           	if (mfII->current_volume != 0)
                                   	mfII->current_audio_state = 1;
                        }

			return 0;
		}

		/* get 20 bytes of ADR data */
                case VIDIOCGADRDATA:
                {
			__u8 *src;

dprintk (KERN_INFO "mfII: ==> ioctl VIDIOCGADRDATA\n");

   			mfII->drp3510a->driver->command (mfII->drp3510a, DRP_ADR_DATA, &src);
#if 0
dprintk (KERN_INFO "mfII: VIDIOCGADRDATA: (src=0x%p; dest=0x%p)\n", src, arg);
#endif
			if (copy_to_user (arg, src, 20))
				return -EFAULT;

   			return 0;
                }

		default:
                
dprintk (KERN_INFO "mfII: ==> Unknown ioctl command (radio) (cmd=0x%08x)\n", cmd);

			return -ENOIOCTLCMD;
        }

	return 0;
}


static int
mfII_radio_open (struct video_device *dev, int flags)
{
	struct mfII_struct *mfII = (struct mfII_struct *) (dev - 1);

fprintk (KERN_INFO "mfII: ==> mfII_radio_open\n");

	if (mfII->in_use != 0)
		return -EBUSY;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,3)
	MOD_INC_USE_COUNT;
#endif
	mfII->in_use++;

	/* V4L says, tuners are only available for video devices. So select */
	/* a tuner here (at *radio*-open) */
	mfII->current_tuner = 0;
	
	return 0;
}


static void
mfII_radio_close (struct video_device *dev)
{
	struct mfII_struct *mfII = (struct mfII_struct *) (dev - 1);

fprintk (KERN_INFO "mfII: ==> mfII_radio_close\n");

	mfII->in_use--;	
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,3)
        MOD_DEC_USE_COUNT;  
#endif
	return;
}


static long int
mfII_radio_read (struct video_device *dev, char *buf, unsigned long int count, int nonblock)
{

fprintk (KERN_INFO "mfII: ==> mfII_radio_read\n");

	return -EINVAL;
}


static long int
mfII_radio_write (struct video_device *dev, const char *buf, unsigned long int count, int nonblock)
{

fprintk (KERN_INFO "mfII: ==> mfII_radio_write\n");

	return -EINVAL;
}


static int
mfII_radio_init_done (struct video_device *dev)
{

fprintk (KERN_INFO "mfII: ==> mfII_radio_init_done\n");

	return 0;
}


static struct video_device
mfII_radio_template =
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,3)
	owner:		THIS_MODULE,
#endif
	name:		"TechniSat MediaFocusII Radio",
	type:		VID_TYPE_TUNER,
	hardware:	VID_HARDWARE_SAA7146,
	open:		mfII_radio_open,
	close:		mfII_radio_close,
	read:		mfII_radio_read,
	write:		mfII_radio_write,
	ioctl:		mfII_radio_ioctl,
	initialize:	mfII_radio_init_done,
	minor:		-1
};

/******************************************************************************/

static int
mfII_vbi_ioctl (struct video_device *dev, unsigned int cmd, void *arg)
{
	struct mfII_struct *mfII = (struct mfII_struct *) (dev - 2);
        
fprintk (KERN_INFO "mfII: ==> mfII_vbi_ioctl (cmd=0x%08x)\n", cmd);

        switch (cmd)
        {
           	case VIDIOCGCAP:
                {
                   	struct video_capability vc;
                        
dprintk (KERN_INFO "mfII: ==> ioctl VIDIOCGCAP (vbi)\n");

   			strcpy (vc.name, &dev->name[0]);
                        vc.type = mfII->vbi.type;
                        vc.channels = 0;
                        vc.audios = 0;
                        vc.maxwidth = 0;
                        vc.maxheight = 0;
                        vc.minwidth = 0;
                        vc.minheight = 0;
                        
                        if (copy_to_user ((struct video_capability *) arg, &vc, sizeof (vc)))
                           	return -EFAULT;
                                
                        return 0;
                }
                
                case VIDIOCGTUNER:
                case VIDIOCSTUNER:
                case VIDIOCGFREQ:
                case VIDIOCSFREQ:
                
                   	return mfII_ioctl ((struct video_device *) mfII, cmd, arg);

		case BTTV_VBISIZE:
		{
			int vsize;

			vsize = mfII->spci->command (mfII->saa7146, SAA7146_VBI_BUFSIZE, NULL);

dprintk (KERN_INFO "mfII: ==> ioctl BTTV_VBISIZE (size=%d)\n", vsize);

#if 0
			if (copy_to_user ((int *) arg, &vsize, sizeof (vsize)))
				return -EFAULT;
			
			return 0;
#else
			/* bttv dictates the rules ;-( */
			return vsize;
#endif
		}
                default:
                
dprintk (KERN_INFO "mfII: ==> Unknown ioctl command (vbi) (cmd=0x%08x)\n", cmd);
                
                   	return -ENOIOCTLCMD;
        }
        
	return 0;
}


static int
mfII_vbi_open (struct video_device *dev, int flags)
{
	struct mfII_struct *mfII = (struct mfII_struct *) (dev - 2);

fprintk (KERN_INFO "mfII: ==> mfII_vbi_open\n");

	if (mfII->in_use != 0)
		return -EBUSY;

	mfII->in_use++;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,3)
	MOD_INC_USE_COUNT;
#endif
	mfII->spci->command (mfII->saa7146, SAA7146_VBI_OPEN, NULL);
	
	return 0;   
}


static void
mfII_vbi_close (struct video_device *dev)
{
	struct mfII_struct *mfII = (struct mfII_struct *) (dev - 2);

fprintk (KERN_INFO "mfII: ==> mfII_vbi_close\n");

	mfII->spci->command (mfII->saa7146, SAA7146_VBI_CLOSE, NULL);
	
	mfII->in_use--;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,3)
	MOD_DEC_USE_COUNT;
#endif
	return;
}


static long
mfII_vbi_read (struct video_device *dev, char *buf, unsigned long count, int nonblock)
{
	struct mfII_struct *mfII = (struct mfII_struct *) (dev - 2);
	struct saa7146_vbi_read_s vbi_r;
	int ret = 0;
	
fprintk (KERN_INFO "mfII: ==> mfII_vbi_read\n");

	vbi_r.buf = buf;
	vbi_r.count = count;
	vbi_r.nonblock = nonblock;
	
	ret = mfII->spci->command (mfII->saa7146, SAA7146_VBI_READ, &vbi_r);

	return ret;
}


static unsigned int
mfII_vbi_poll (struct video_device *dev, struct file *file, poll_table *wait)
{
	struct mfII_struct *mfII = (struct mfII_struct *) (dev - 2);
	struct saa7146_vbi_poll_s vbi_p;
	int ret = 0;
		
fprintk (KERN_INFO "mfII: ==> mfII_vbi_poll\n");

	vbi_p.file = file;
	vbi_p.wait = wait;
	
	ret = mfII->spci->command (mfII->saa7146, SAA7146_VBI_POLL, &vbi_p);
	
	return ret;
}


static struct video_device
mfII_vbi_template=
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,3)
	owner:		THIS_MODULE,
#endif
	name:		"TechniSat MediaFocusII VBI",
	type:		VID_TYPE_TUNER		|
        		VID_TYPE_TELETEXT,
	hardware:	VID_HARDWARE_SAA7146,
	open:		mfII_vbi_open,
	close:		mfII_vbi_close,
	read:		mfII_vbi_read,
	poll:		mfII_vbi_poll,
	ioctl:		mfII_vbi_ioctl,
	minor:		-1
};

/******************************************************************************/

/* ------------------------------*/
/* basic module / init functions */
/* ------------------------------*/

/* initialize the helper ics to useful values */
int __devinit
init_helper_ics (struct mfII_struct *mfII) {

	int arg, ret = 0;
	unsigned long int larg;
	struct video_picture vp;

fprintk (KERN_INFO "mfII: ==> init_helper_ics\n");

	/* enable LNB voltage */
        arg = MSP_DIGCTR0_ON;
        ret = mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SET_DIGCTR0, &arg);
	if (ret != 0) {
           	return ret;
        }

	/* initialize DiSEqC settings */
	diseqc_reset (mfII);
	set_orbit_position (mfII, INITIAL_ORBIT_POSITION);
	mfII->current_orbit_position = INITIAL_ORBIT_POSITION;

	/* initialize LNB polarity */
        arg = INITIAL_LNB_POLARITY;
        ret = mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SET_DIGCTR1, &arg);
	if (ret != 0) {
           	return ret;
        }

	/* initialize tuner frequency */
	larg = INITIAL_TUNER_FREQUENCY;
	ret = mfII->sp5055->driver->command (mfII->sp5055, TUNER_SET_TVFREQ, &larg); 
	if (ret != 0) {
		return ret;
	}
	mfII->current_freq = larg / 1000000 * 16;

        /* initialize 22 kHz signal state */
        arg = INITIAL_22KHZ_STATE;
        ret = mfII->stv0056af->driver->command (mfII->stv0056af, STV_SET_22KHZ, &arg);
	if (ret != 0) {
           	return ret;
        }
	if (arg == STV_22KHZ_ON)
		mfII->current_22khz_state = 1;
	else
		mfII->current_22khz_state = 0;

#if 0	/* this setting now initialized by stv0056af module parameter */
   	/* was: set video gain = 0 dB in STV0056AF */
        arg = 0;
        ret = mfII->stv0056af->driver->command (mfII->stv0056af, STV_SET_GAIN, &arg);
	if (ret != 0) {
           	return ret;
        }
#endif

        /* enable video for SAA7113H, coming from STV0056AF */
        arg = STV_NORMAL_VIDEO;
        ret = mfII->stv0056af->driver->command (mfII->stv0056af, STV_SET_SCART1, &arg);
	if (ret != 0) {
           	return ret;
        }

#if 1	/* this setting now initialized by stv0056af module parameter */        
        /* was: enable video for Mini DIN jack, coming from STV0056AF */
        arg = STV_BASEBAND;
        ret = mfII->stv0056af->driver->command (mfII->stv0056af, STV_SET_DECODER, &arg);
	if (ret != 0) {
           	return ret;
        }
#endif

        /* select video input in SAA7113H */
	arg = DECODER_INPUT_MODE0;
	ret = mfII->saa7113h->driver->command (mfII->saa7113h, DECODER_SET_INPUT, &arg);
	if (ret != 0) {
		return ret;
	}
	mfII->current_channel = 0;
	
        /* select video processing in SAA7113H */
	arg = 0;
   	arg |= DECODER_USE_ANTIALIAS;
	arg |= DECODER_USE_AMPLIFIER; 
	ret = mfII->saa7113h->driver->command (mfII->saa7113h, DECODER_SET_FUSE, &arg);
	if (ret != 0) {
		return ret;
	}

#if 0        
        /* set video gain in SAA7113H */
	arg = INITIAL_SAA7113_GAIN;
	ret = mfII->saa7113h->driver->command (mfII->saa7113h, DECODER_SET_GAIN, &arg);
	if (ret != 0) {
		return ret;
	}
#endif
	
        /* select video norm in SAA7113H */
	arg = VIDEO_MODE_PAL;
	ret = mfII->saa7113h->driver->command (mfII->saa7113h, DECODER_SET_NORM, &arg);
	if (ret != 0) {
		return ret;
	}
	mfII->current_video_norm = VIDEO_MODE_PAL;

	/* initialize picture properties in SAA7113H */
	memset (&vp, 0, sizeof (vp));
	vp.brightness = INITIAL_SAA7113_BRIGHTNESS;
	vp.contrast = INITIAL_SAA7113_CONTRAST;
	vp.colour = INITIAL_SAA7113_SATURATION;
	vp.hue = INITIAL_SAA7113_HUE;
	ret = mfII->saa7113h->driver->command (mfII->saa7113h, DECODER_SET_PICTURE, &vp);
	mfII->current_overlay_pict.hue = vp.hue;

	/* initialize picture properties in SAA7146AH */
	memset (&vp, 0, sizeof (vp));
	vp.brightness = INITIAL_SAA7146_BRIGHTNESS;
	vp.contrast = INITIAL_SAA7146_CONTRAST;
	vp.colour = INITIAL_SAA7146_SATURATION;
	vp.depth = INITIAL_SAA7146_DEPTH;
	vp.palette = INITIAL_SAA7146_PALETTE;
	mfII->spci->command (mfII->saa7146, SAA7146_V4L_SPICT, &vp);
	mfII->current_overlay_pict.brightness = vp.brightness;
	mfII->current_overlay_pict.contrast = vp.contrast;
	mfII->current_overlay_pict.colour = vp.colour;
	mfII->current_overlay_pict.depth = vp.depth;
	mfII->current_overlay_pict.palette = vp.palette;
       
#if 0        
        /* enable audio FM demodulation input on sound processor chip */
        arg = MSP_ANA1_TO_DEM;
        ret = mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SLCT_DEM_SRC, &arg);
	if (ret != 0) {
           	return ret;
        }
#endif
        /* enable audio going to Mini DIN jack */
        arg = MSP_DFP_TO_SC1;
        ret = mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SLCT_SC1_SRC, &arg);
	if (ret != 0) {
           	return ret;
        }
        
        /* enable audio coming from Mini DIN jack */
        arg = MSP_SC1_TO_DFP;
        ret = mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SLCT_DFPANALOG_SRC, &arg);
	if (ret != 0) {
           	return ret;
        }
        
        /* enable audio going to (Internal+External) Audio-Out */
        arg = MSP_DEM_SRC;
        ret = mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SLCT_LSP_SRC, &arg);
	if (ret != 0) {
           	return ret;
        }
        
        /* set audio volume level to 50 % */
        arg = 32768;
        ret = mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SET_VOLUME, &arg);
	if (ret != 0) {
           	return ret;
        }
        mfII->current_volume = arg;
        
        /* set audio bass level to +-0 */
        arg = 32768;
        ret = mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SET_BASS, &arg);
	if (ret != 0) {
           	return ret;
        }
        mfII->current_bass = arg;
        
        /* set audio treble level to +-0 */
        arg = 32768;
        ret = mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SET_TREBLE, &arg);
	if (ret != 0) {
           	return ret;
        }
        mfII->current_treble = arg;
        
        /* FIXME??!!?? */
        mfII->current_balance = 32768;

        /* set audio mode */
        arg = VIDEO_SOUND_STEREO;
        ret = mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SET_STEREO, &arg);
	if (ret != 0) {
           	return ret;
        }
        mfII->current_audio_mode = arg;
	mfII->current_left_carrier = 7020;
	mfII->current_right_carrier = 7200;

	/* mute audio */
	ret = mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SWITCH_MUTE, NULL);
	if (ret != 0) {
		return ret;
	}
	mfII->current_audio_state = 0;
		       
	/* enable ADR mode in ADR chip */
	ret = mfII->drp3510a->driver->command (mfII->drp3510a, DRP_ADR, NULL);
	if (ret != 0) {
		return ret;
	}

        return 0;
} /* init_helper_ics() */

int __devexit
cleanup_helper_ics (struct mfII_struct *mfII) {

	int arg, ret = 0;

fprintk (KERN_INFO "mfII: ==> cleanup_helper_ics\n");

   	/* enable pass thru of Internal Audio-In to (Internal + External) Audio-Out */
        arg = MSP_SC2_TO_DFP;
        ret |= mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SLCT_DFPANALOG_SRC, &arg);
        arg = MSP_SCART_SRC;
        ret |= mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SLCT_LSP_SRC, &arg);
        arg = 52428;	/* 80% volume */
        ret |= mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SET_VOLUME, &arg);
        arg = 32768;	/* +-0% bass */
        ret |= mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SET_BASS, &arg);
        arg = 32768;	/* +-0% treble */
        ret |= mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SET_TREBLE, &arg);
        if (ret != 0) {
           	printk (KERN_ERR "mfII: cleanup_module: Can't address sound decoder chip to enable pass thru of internal audio input. Continuing anyway.\n");
        }
        
        /* turn off LNB voltage */
        arg = MSP_DIGCTR0_OFF;
        ret = mfII->msp3400c->driver->command (mfII->msp3400c, MSP_SET_DIGCTR0, &arg);
        if (ret != 0) {
           	printk (KERN_ERR "mfII: cleanup_module: Can't address sound decoder chip to turn off LNB voltage. Continuing anyway.\n");
   	}
        
	return 0;
} /* cleanup_helper_ics() */

#ifdef MODULE
int __devinit
mfII_init (void)
#else
int __init
mfII_setup (void)
#endif
{
	int adap, client, i, avail = 0;
	struct i2c_client* i2c = NULL;

#ifdef MODULE	
fprintk (KERN_INFO "mfII: ==> mfII_init\n");
#else
fprintk (KERN_INFO "mfII: ==> mfII_setup\n");
#endif

	printk (KERN_INFO "mfII.o driver version %s\n", VERS);

#if 0
	if (0 > request_module ("saa7146_core")) {
		return -1;
	}
#endif
	if (0 > request_module ("saa7146_v4l")) {
		printk (KERN_WARNING "mfII: Error while trying to load module saa7146_v4l.\n");
		return -1;
	}
	if (0 > request_module ("sp5055II")) { 
		printk (KERN_WARNING "mfII: Error while trying to load module sp5055II.\n");
		return -1;
	}
	if (0 > request_module ("stv0056af")) {
		printk (KERN_WARNING "mfII: Error while trying to load module stv0056af.\n");
		return -1;
	}
	if (0 > request_module ("saa7113h")) {
		printk (KERN_WARNING "mfII: Error while trying to load module saa7113h.\n");
		return -1;
	}
	if (0 > request_module ("msp3400satII")) {
		printk (KERN_WARNING "mfII: Error while trying to load module msp3400satII.\n");
		return -1;
	}
	if (0 > request_module ("drp3510II")) {
		printk (KERN_WARNING "mfII: Error while trying to load module drp3510II.\n");
		return -1;
	}
	if (0 > request_module ("ee24lc16")) {
		printk (KERN_WARNING "mfII: Error while trying to load module ee24lc16.\n");
		return -1;
	}
	memset (mfII, 0, sizeof (mfII));

	/* try to find MAX_NUM_MFII MediafocusIIs ... */
	for (adap = 0; adap < MAX_NUM_MFII; adap++) {
		/* get handle for the "adap"-th saa7146 in the system */
		if (NULL == (mfII[num_mfII].spci = saa7146_get_handle (adap))) {
			break;
		} else {
			if (saa7146[0] != -1) {	
			/* user has specified a list of wanted SAA7146s */
				i = 0;
				while (i < MAX_NUM_MFII) {
				/* is actual SAA7146 a member of the list? */
					if (adap == saa7146[i])
						break;
					i++;
				}
				if (i == MAX_NUM_MFII) {
				/* not a member of the list */
					printk (KERN_INFO "mfII: Ignoring saa7146(%d).\n", adap);
					continue;
				}
			}
		}

		printk (KERN_INFO "mfII: Claiming saa7146(%d) for MediaFocusII(%d).\n", adap, num_mfII);

		mfII[num_mfII].saa7146 = mfII[num_mfII].spci->i2c_adap;

		/* loop through all available i2c-clients on the i2c-bus; check for
		   necessary i2c-slaves, remember the "position" on the i2c-bus */
		for (client = 0; client < mfII[num_mfII].saa7146->client_count; client++) {
		
			i2c = mfII[num_mfII].saa7146->clients[client];
			
			if (I2C_DRIVERID_TUNER == i2c->driver->id) {
				mfII[num_mfII].sp5055 = i2c;
				avail += 0x1;
			}
			if (I2C_DRIVERID_STV0056 == i2c->driver->id) {
				mfII[num_mfII].stv0056af = i2c;
				avail += 0x2;
			}
			if (I2C_DRIVERID_SAA7113 == i2c->driver->id) {
				mfII[num_mfII].saa7113h = i2c;
				avail += 0x4;
			}
			if (I2C_DRIVERID_MSP3400 == i2c->driver->id) {
				mfII[num_mfII].msp3400c = i2c;
				avail += 0x8;
			}
			if (I2C_DRIVERID_DRP3510 == i2c->driver->id) {
                           	mfII[num_mfII].drp3510a = i2c;
				avail += 0x10;
			}
			if (I2C_DRIVERID_AT24Cxx == i2c->driver->id) {
				mfII[num_mfII].eeprom = i2c;
				mfII[num_mfII].has_eeprom += 1;
			}
		}

		/* all i2c-slaves found? */
		if (0x1f != avail) {
			printk (KERN_ERR "mfII: MediaFocusII(%d) lacks the following helper ic(s):\n", num_mfII);
			if (0 == (avail & 0x1))
				printk (KERN_ERR "- SP5055\n");
			if (0 == (avail & 0x2))
				printk (KERN_ERR "- STV0056AF\n");
			if (0 == (avail & 0x4))
				printk (KERN_ERR "- SAA7113H\n");
			if (0 == (avail & 0x8))
				printk (KERN_ERR "- MSP3400C\n");
			if (0 == (avail & 0x10))
				printk (KERN_ERR "- DRP3510A\n");
			/* eeprom is not really needed */
			break;
		}

		/* initialize helper-ics */
		if (0 > init_helper_ics (&mfII[num_mfII])) {
			printk (KERN_WARNING "mfII: failed to initalize helper ics of MediaFocusII(%d).\n", num_mfII);
			break;
		}

		/* Copy structures */
		memcpy (&mfII[num_mfII].video, &mfII_video_template, sizeof (struct video_device));
		memcpy (&mfII[num_mfII].radio, &mfII_radio_template, sizeof (struct video_device));
		memcpy (&mfII[num_mfII].vbi, &mfII_vbi_template, sizeof (struct video_device));

		/* try to register video4linux-devices */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,5)
		if (0 > video_register_device (&mfII[num_mfII].video, VFL_TYPE_GRABBER, -1)) {
#else	
		if (0 > video_register_device (&mfII[num_mfII].video, VFL_TYPE_GRABBER)) {
#endif
		    	printk (KERN_WARNING "mfII: can't register video device for MediaFocusII(%d).\n", num_mfII);
			break;
		}
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,5)
		if (0 > video_register_device (&mfII[num_mfII].radio, VFL_TYPE_RADIO, -1)) {
#else
		if (0 > video_register_device (&mfII[num_mfII].radio, VFL_TYPE_RADIO)) {
#endif
			printk (KERN_WARNING "mfII: can't register radio device for MediaFocusII(%d).\n", num_mfII);
			video_unregister_device (&mfII[num_mfII].video);
			break;
		}
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,5)
		if (0 > video_register_device (&mfII[num_mfII].vbi, VFL_TYPE_VBI, -1)) {
#else
		if (0 > video_register_device (&mfII[num_mfII].vbi, VFL_TYPE_VBI)) {
#endif
		    	printk (KERN_WARNING "mfII: can't register vbi device for MediaFocusII(%d).\n", num_mfII);
			video_unregister_device (&mfII[num_mfII].radio);
			video_unregister_device (&mfII[num_mfII].video);
			break;
		}
		
		if (mfII[num_mfII].sp5055 != NULL)
			i2c_inc_use_client (mfII[num_mfII].sp5055);
		if (mfII[num_mfII].stv0056af != NULL)
			i2c_inc_use_client (mfII[num_mfII].stv0056af);
		if (mfII[num_mfII].saa7113h != NULL)
			i2c_inc_use_client (mfII[num_mfII].saa7113h);
		if (mfII[num_mfII].msp3400c != NULL)
			i2c_inc_use_client (mfII[num_mfII].msp3400c);
		if (mfII[num_mfII].drp3510a != NULL)
			i2c_inc_use_client (mfII[num_mfII].drp3510a);
		if (mfII[num_mfII].has_eeprom)
			i2c_inc_use_client (mfII[num_mfII].eeprom);

		num_mfII++;

	} /* for (adap=0;...) */

	if (num_mfII == 0) {	/* either no MFIIs found or error(s) beforehand */
		printk (KERN_INFO "mfII: no MediafocusII cards found!\n");
		return -ENODEV;
	}

	printk (KERN_INFO "mfII: %d MediaFocusII card(s) found!\n", num_mfII);
			
	return 0;
} /* mfII_init() */

void __devexit
mfII_cleanup (void)
{
	int card;

fprintk (KERN_INFO "mfII: ==> mfII_cleanup\n");

	/* release the MFIIs properly */
	for (card = 0; card < num_mfII; card++) {
		/* cleanup helper ics */
		if (0 > cleanup_helper_ics (&mfII[card])) {
			printk (KERN_WARNING "mfII: failed to clean-up helper ics of MediaFocusII(%d); continuing anyway.\n", card);
		}

		if (mfII[card].vbi.minor != -1)
			video_unregister_device (&mfII[card].vbi);
		if (mfII[card].radio.minor != -1)
			video_unregister_device (&mfII[card].radio);
		if (mfII[card].video.minor != -1)
			video_unregister_device (&mfII[card].video);

		if (mfII[card].has_eeprom && (mfII[card].eeprom != NULL))
			i2c_dec_use_client (mfII[card].eeprom);
		if (mfII[card].drp3510a != NULL)
			i2c_dec_use_client (mfII[card].drp3510a);
		if (mfII[card].msp3400c != NULL)
			i2c_dec_use_client (mfII[card].msp3400c);
		if (mfII[card].saa7113h != NULL)
			i2c_dec_use_client (mfII[card].saa7113h);
		if (mfII[card].stv0056af != NULL)
			i2c_dec_use_client (mfII[card].stv0056af);
		if (mfII[card].sp5055 != NULL)
			i2c_dec_use_client (mfII[card].sp5055);

		mfII[card].eeprom = NULL;
		mfII[card].drp3510a = NULL;
		mfII[card].msp3400c = NULL;
		mfII[card].saa7113h = NULL;
		mfII[card].stv0056af = NULL;
		mfII[card].sp5055 = NULL;

		printk (KERN_INFO "mfII: MediaFocusII(%d) using %s released.\n", card, mfII[card].spci->name);
	}
    	
	num_mfII = 0;
} /* mfII_cleanup() */

MODULE_AUTHOR("Rolf Siebrecht <rolf.siebrecht@t-online.de>");
MODULE_DESCRIPTION("TechniSat MediaFocusII Video4Linux Driver");
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,10)
MODULE_LICENSE("GPL");
#endif

module_init(mfII_init);
module_exit(mfII_cleanup);

