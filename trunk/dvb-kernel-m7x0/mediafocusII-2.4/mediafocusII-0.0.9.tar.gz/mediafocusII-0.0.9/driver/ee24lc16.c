/*
    ee24lc16.c	A driver for 24LC16 Serial EEPROMs

    Copyright (C) 2000,2001 Rolf Siebrecht <rolf.siebrecht@t-online.de>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/* For the time being only the first 256 from 2048 bytes of a	*/
/* 24LC16 Serial EEPROM can be read/written by this driver.	*/
/* (= No page switching possible.)				*/

#include <linux/version.h>
#include <linux/kernel.h>
#include <linux/module.h>

#if CONFIG_MODVERSIONS==1
#define MODVERSIONS
#include <linux/modversions.h>
#endif

#include <linux/malloc.h>
#include <linux/init.h>
#include <linux/delay.h>
#include <linux/i2c.h>

#include "../linux/videodev_priv.h"

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,3,0)
# include "kcompat24.h"
#endif

#include "ee24lc16.h"

#ifdef MODULE
MODULE_PARM(debug,"i");
MODULE_PARM(address,"i");
MODULE_PARM(adapter,"s");
#endif

static int debug = 0;	/* module load parameter */
static int address = -1;
static char *adapter = NULL;

#define dprintk	if (debug) printk

/* I2C addresses to scan */
static unsigned short int normal_i2c[] = { I2C_CLIENT_END };
static unsigned short int normal_i2c_range[] = { I2C_EEPROM_LOW, I2C_EEPROM_HIGH, I2C_CLIENT_END };

/* magic definition of all other variables and things */
I2C_CLIENT_INSMOD;

/* unique ID allocation */
static int eeprom_id = 0;

static struct i2c_driver eeprom_driver;

/*****************************************************************************/

static int
eeprom_getbyte (struct i2c_client *eeprom_client, __u16 addr)
{
	int val;

	val = i2c_smbus_read_byte_data (eeprom_client, addr);

dprintk (KERN_INFO "ee24lc16(%d): ==> %s (addr=0x%x; byte=0x%02x)\n", eeprom_client->id, __FUNCTION__, addr, val);

	if (val < 0) {
		printk (KERN_ERR "ee24lc16(%d): I2C error, %s failed.\n", eeprom_client->id, __FUNCTION__);
	}

	return val;
}

static int
eeprom_setbyte (struct i2c_client *eeprom_client, __u16 addr, __u8 byt)
{
	int ret = 0;

dprintk (KERN_INFO "ee24lc16(%d): ==> %s (addr=0x%x; byte=0x%02x)\n", eeprom_client->id, __FUNCTION__, addr, byt);

	ret |= i2c_smbus_write_byte_data (eeprom_client, addr, byt);
	mdelay (10);

	if (ret != 0) {
		printk (KERN_ERR "ee24lc16(%d): I2C error, %s failed.\n", eeprom_client->id, __FUNCTION__);
		return -EIO;
	}

	return 0;
}

/*****************************************************************************/

/* this function is called by i2c_probe */
static int 
eeprom_detect (struct i2c_adapter *adap, int addr, unsigned short int flags, int kind)
{
   	struct i2c_client *eeprom_client;
        int ret;

dprintk (KERN_INFO "ee24lc16: ==> %s (adap=%s; addr=0x%02x)\n", __FUNCTION__, adap->name, addr);

        /* let's see whether this adapter can support what we need */
        if (i2c_check_functionality (adap, I2C_FUNC_I2C | I2C_FUNC_SMBUS_READ_BYTE | I2C_FUNC_SMBUS_WRITE_BYTE) == 0) {
           	return 0;
        }

        /* allocate memory for client structure */
        eeprom_client = kmalloc (sizeof (struct i2c_client), GFP_KERNEL);
        if (eeprom_client == NULL) {
                return -ENOMEM;
        }

        /* fill client structure */
	eeprom_client->id = eeprom_id++;
        sprintf (eeprom_client->name, "Serial EEPROM(%d)", eeprom_client->id);
        eeprom_client->flags = 0;
        eeprom_client->addr = addr;
        eeprom_client->adapter = adap;
        eeprom_client->driver = &eeprom_driver;
        eeprom_client->data = NULL;

	printk (KERN_INFO "ee24lc16: %s detected at i2c address 0x%02x.\n", eeprom_client->name, eeprom_client->addr);

        /* tell the i2c layer a new client has arrived */
        ret = i2c_attach_client (eeprom_client);

        if (ret != 0) {
           	printk (KERN_WARNING "ee24lc16: Client registration failed, %s @ 0x%02x not attached.\n", eeprom_client->name, eeprom_client->addr);
		/* kfree (eeprom_client->data); */
                kfree (eeprom_client);
                return ret;
        }

	printk (KERN_INFO "ee24lc16: %s @ 0x%02x attached to adapter %s.\n", eeprom_client->name, eeprom_client->addr, eeprom_client->adapter->name);

	return 0;
}


static int
eeprom_attach (struct i2c_adapter *adap)
{

dprintk (KERN_INFO "ee24lc16: ==> %s (adap=%s)\n", __FUNCTION__, adap->name);

	if (address != -1) {
		normal_i2c_range[0] = address;
		normal_i2c_range[1] = address;
	}
	if (adapter != NULL)
		if (strcmp (adap->name, adapter))
			return 0;
   	return i2c_probe (adap, &addr_data, &eeprom_detect);
}


static int 
eeprom_detach (struct i2c_client *eeprom_client)
{
        int ret = 0;

dprintk (KERN_INFO "ee24lc16: ==> %s (client=%s; addr=0x%02x; adap=%s)\n", __FUNCTION__, eeprom_client->name, eeprom_client->addr, eeprom_client->adapter->name);

        ret = i2c_detach_client (eeprom_client);

        if (ret != 0) {
           	printk (KERN_WARNING "ee24lc16: Client deregistration failed, %s @ 0x%02x not detached.\n", eeprom_client->name, eeprom_client->addr);
                return ret;
        }

        printk (KERN_INFO "ee24lc16: Client %s @ 0x%02x detached from adapter %s.\n", eeprom_client->name, eeprom_client->addr, eeprom_client->adapter->name);

	/* kfree (eeprom_client->data); */
        kfree (eeprom_client);

	return 0;
}


static int 
eeprom_command (struct i2c_client *eeprom_client, unsigned int cmd, void *arg)
{
	int ret = 0;

	switch (cmd) {
		case GET_EEPROM_DATA:
		{
			struct eeprom_s ee;
			int val;

			memcpy (&ee, arg, sizeof (ee));

dprintk (KERN_INFO "ee24lc16(%d): ==> ioctl GET_EEPROM_DATA (addr=0x%x; cnt=%d; *data=0x%p)\n", eeprom_client->id, ee.addr, ee.count, ee.data);

			if ((ee.addr >= 256) || (ee.count > 256) || ((ee.addr + ee.count) > 256))
				return -EINVAL;

			if (ee.count == 0) {
				val = eeprom_getbyte (eeprom_client, ee.addr);
				if (val < 0)
					return val;
				*ee.data = (__u8) val;
			} else
				do {
					val = eeprom_getbyte (eeprom_client, ee.addr++);
					if (val < 0)
						return val;
					*ee.data++ = (__u8) val;
				} while (--ee.count);

			return 0;
		}

		case SET_EEPROM_DATA:
		{
			struct eeprom_s ee;

			memcpy (&ee, arg, sizeof (ee));

dprintk (KERN_INFO "ee24lc16(%d): ==> ioctl SET_EEPROM_DATA (addr=0x%x; cnt=%d; *data=0x%p)\n", eeprom_client->id, ee.addr, ee.count, ee.data);

			if ((ee.addr >= 256) || (ee.count > 256) || ((ee.addr + ee.count) > 256))
				return -EINVAL;

			if (ee.count == 0) {
				ret = eeprom_setbyte (eeprom_client, ee.addr, *ee.data);
			} else {
				do {
					ret = eeprom_setbyte (eeprom_client, ee.addr++, *ee.data++);
					if (ret < 0)
						return ret;
				} while (--ee.count);
				ret = 0;
			}
			return ret;
		}

		default:

dprintk (KERN_INFO "ee24lc16(%d): Unknown ioctl cmd (0x%x)\n", eeprom_client->id, cmd);

			return -ENOIOCTLCMD;
	}
}


void
eeprom_inc_use (struct i2c_client *eeprom_client)
{
#ifdef MODULE
   	MOD_INC_USE_COUNT;
#endif
}


void
eeprom_dec_use (struct i2c_client *eeprom_client)
{
#ifdef MODULE
   	MOD_DEC_USE_COUNT;
#endif
}


static struct i2c_driver eeprom_driver = {
	"ee24lc16.o",
	I2C_DRIVERID_AT24Cxx,
	I2C_DF_NOTIFY,
	eeprom_attach,
	eeprom_detach,
	eeprom_command,
        eeprom_inc_use,
        eeprom_dec_use
};

/*****************************************************************************/

EXPORT_NO_SYMBOLS;

int __devinit
eeprom_init (void)
{
   	int ret;

        printk (KERN_INFO "ee24lc16.o i2c driver\n");

        ret = i2c_add_driver (&eeprom_driver);

        if (ret != 0) {
           	printk (KERN_WARNING "ee24lc16: Driver registration failed, module not inserted.\n");
                return ret;
        }

	if (eeprom_id == 0)
		printk (KERN_WARNING "ee24lc16: No hardware detected.\n");

        return 0;
}


void __devexit
eeprom_cleanup (void)
{
   	int ret;
        
        ret = i2c_del_driver (&eeprom_driver);
        
        if (ret != 0) {
           	printk (KERN_WARNING "ee24lc16: Driver deregistration failed, module not removed.\n");
        }
}

/*****************************************************************************/

MODULE_AUTHOR ("Rolf Siebrecht <rolf.siebrecht@t-online.de>");
MODULE_DESCRIPTION ("24LC16 Serial EEPROM I2C driver");
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,10)
MODULE_LICENSE("GPL");
#endif

module_init(eeprom_init);
module_exit(eeprom_cleanup);

