#ifndef __SAA7146_V4L_H__
#define __SAA7146_V4L_H__

#if LINUX_VERSION < KERNEL_VERSION(2,3,0)
# include "kcompat24.h"
#endif

/************************************************************************/
/* ADDRESSING 								*/
/************************************************************************/

#define SAA7146_V4L_BASE	100

#define	SAA7146_V4L_GPICT	_IOR('d', (SAA7146_V4L_BASE+ 1), struct video_picture)
#define	SAA7146_V4L_SPICT	_IOW('d', (SAA7146_V4L_BASE+ 2), struct video_picture)

#define	SAA7146_V4L_GFBUF	_IOR('d', (SAA7146_V4L_BASE+ 3), struct video_buffer)
#define	SAA7146_V4L_SFBUF	_IOW('d', (SAA7146_V4L_BASE+ 4), struct video_buffer)

#define	SAA7146_V4L_GMBUF	_IOR('d', (SAA7146_V4L_BASE+ 5), struct video_mbuf)

#define	SAA7146_V4L_SWIN	_IOW('d', (SAA7146_V4L_BASE+ 6), struct video_window)

#define	SAA7146_V4L_CAPTURE    	_IOW('d', (SAA7146_V4L_BASE+ 7), int)

#define	SAA7146_V4L_MCAPTURE	_IOW('d', (SAA7146_V4L_BASE+ 8), struct video_mmap)
#define	SAA7146_V4L_SYNC	_IOW('d', (SAA7146_V4L_BASE+ 9), int)

#define	SAA7146_V4L_GNORM	_IOR('d', (SAA7146_V4L_BASE+10), __u16)
#define SAA7146_V4L_SNORM	_IOW('d', (SAA7146_V4L_BASE+11), __u16)

#ifdef DVB
#define SAA7146_V4L_CCAPTURE	SAA7146_V4L_CAPTURE
#define SAA7146_V4L_CMCAPTURE	SAA7146_V4L_MCAPTURE
#define SAA7146_V4L_CSYNC	SAA7146_V4L_SYNC
/* #define SAA7146_V4L_TSCAPTURE	_IOW('d', (SAA7146_V4L_BASE+14), int) */
#endif

#endif

