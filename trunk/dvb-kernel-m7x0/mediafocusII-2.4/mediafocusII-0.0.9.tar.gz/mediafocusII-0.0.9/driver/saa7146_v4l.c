/*
    video4linux-parts of the saa7146 device driver
    
    Copyright (C) 1998,1999 Michael Hunold <michael@mihu.de>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
    Some modifications and improvements
    
    Copyright (C) 2001 Rolf Siebrecht <rolf.siebrecht@t-online.de>
*/

#include <linux/version.h>
#include <linux/module.h>	/* for module-version */
#include <linux/string.h>
#include <linux/slab.h>		/* for kmalloc/kfree */
#include <linux/delay.h>	/* for delay-stuff */
#include <asm/uaccess.h>	/* for copy_to/from_user */
#include <linux/wrapper.h>	/* for mem_map_reserve */
#include <linux/init.h>
#include <linux/videodev.h>
#include <linux/i2c.h>

#include "saa7146.h"
#include "saa7146_core.h"
#include "saa7146_v4l.h"

#ifdef MODULE
MODULE_PARM(debug,"i");
#endif

/* insmod parameter: ... should be quite clear */
static int debug = 0;
#define fprintk	if ((debug == 1) || (debug >= 3)) printk
#define gprintk	if (debug >= 2) printk
#define hprintk	if (debug >= 3) printk

#define __COMPILE_SAA7146__
#include "saa7146.c"
#include "saa7146_memory.c"

/* transform video4linux-cliplist to plain arrays -- we assume that the arrays
   are big enough -- if not: your fault! */	
int
saa7146_v4lclip2plain (struct video_clip *clips, u16 clipcount, int x[], int y[], int width[], int height[])
{
	int	i = 0;
	struct	video_clip* vc = NULL;

fprintk (KERN_INFO "saa7146_v4l: ==> saa7146_v4lclip2plain, cc:%d\n", clipcount);

	/* anything to do here? */	
	if( 0 == clipcount )
		return 0;

	/* copy to kernel-space */
	vc = vmalloc(sizeof(struct video_clip)*(clipcount));
	if( NULL == vc	) {
		printk (KERN_ERR "saa7146_v4l: saa7146_v4lclip2plain: no memory #2!\n");
		return -ENOMEM;
	}
	if (copy_from_user (vc, clips, sizeof (struct video_clip) *clipcount)) {
		printk (KERN_ERR "saa7146_v4l: saa7146_v4lclip2plain: could not copy from user-space!\n");
		return -EFAULT;
	}

	/* copy the clip-list to the arrays
	   note: the video_clip-struct may contain negative values to indicate
	   that a window doesn't lay completly over the video window. Thus, we
	   correct the values right here */
	for(i = 0; i < clipcount; i++) {

		if( vc[i].width < 0) {
			vc[i].x += vc[i].width; vc[i].width = -vc[i].width;
		}
		if( vc[i].height < 0) {
			vc[i].y += vc[i].height; vc[i].height = -vc[i].height;
		}			

		if( vc[i].x < 0) {
			vc[i].width += vc[i].x; vc[i].x = 0;
		}
		if( vc[i].y < 0) {
			vc[i].height += vc[i].y; vc[i].y = 0;
		}		

		if(vc[i].width <= 0 || vc[i].height <= 0) {
			vfree(vc);
			return -EINVAL;
		}
		
		x[i]		= vc[i].x;
		y[i]		= vc[i].y;
		width[i]	= vc[i].width;
		height[i]	= vc[i].height;
	}		

	/* free memory used for temporary clips */
	vfree(vc);

	return 0;	
}
	
struct saa7146_v4l_s {
	struct video_buffer	fbuf;
	struct video_mbuf	mbuf;
	struct video_window	window;
	struct video_picture	picture;
}; 

/* ------------------------------------------------------------------------ */

static int saa7146_v4l_command (struct saa7146 *saa, void *p, unsigned int cmd, void *arg)
{
	struct saa7146_v4l_s *data = (struct saa7146_v4l_s *) p;
	int ret = 0;

#if 0
fprintk (KERN_INFO "saa7146_v4l.o: ==> saa7146_v4l_command\n");
#endif

	if (NULL == saa)
		return -EINVAL;

	switch(cmd) {
		case SAA7146_V4L_GFBUF:
		{
			struct video_buffer *vb = arg;

			memcpy(vb, &data->fbuf, sizeof (struct video_buffer));

gprintk (KERN_INFO "saa7146_v4l: ==> ioctl SAA7146_V4L_GFBUF (base=0x%p; w=%d; h=%d; d=%d; bpl=%d)\n", vb->base, vb->width, vb->height, vb->depth, vb->bytesperline);

			break;
		}

		case SAA7146_V4L_SFBUF:
		{
			struct video_buffer *vb = arg;
		
gprintk (KERN_INFO "saa7146_v4l: ==> ioctl SAA7146_V4L_SFBUF (base=0x%p; w=%d; h=%d; d=%d; bpl=%d)\n", vb->base, vb->width, vb->height, vb->depth, vb->bytesperline);			

			memcpy(&data->fbuf, vb, sizeof(struct video_buffer));

			break;
		}

		case SAA7146_V4L_SWIN:
		{
			struct video_window *vw = arg;
			int	*x = NULL, *y = NULL, *w = NULL, *h = NULL;

gprintk (KERN_INFO "saa7146_v4l: ==> ioctl SAA7146_V4L_SWIN (x=%d; y=%d; w=%d; h=%d; cc=%d)\n", vw->x, vw->y, vw->width, vw->height, vw->clipcount);

#ifdef DVB
                        set_overlay_mode (saa, 0);
                        saa7146_write(saa->mem, MC1, MASK_21);
#endif
			if (0 != (ret = set_overlay_windowsize (saa, vw->width, vw->height, 0, 0, 0)))
				return ret;

			/* yeah, it�s not wrong: we really must pass the    */
			/* framebuffer�s width here, not the window�s width */
			if (0 != (ret = set_overlay_windowposition (saa, vw->x, vw->y, vw->height, 
				data->fbuf.width, data->fbuf.depth,
				data->fbuf.bytesperline, (u32) data->fbuf.base, 0)))
				return ret;

			/* this is tricky, but helps us saving kmalloc/kfree-
			   calls and boring if/else-constructs ... */
			x = (int *) kmalloc (sizeof (int) * vw->clipcount*4, GFP_KERNEL);
			if (NULL == x) {

hprintk (KERN_ERR "saa7146_v4l: SAA7146_V4L_SWIN: out of kernel-memory\n");

				return -ENOMEM;
			}
			y = x+(1*vw->clipcount);
			w = x+(2*vw->clipcount);
			h = x+(3*vw->clipcount);

			/* transform clipping-windows */
			if (0 != saa7146_v4lclip2plain (vw->clips, vw->clipcount,x,y,w,h))
				break;
			clip_windows (saa, SAA7146_CLIPPING_RECT, vw->width, vw->height, NULL, vw->clipcount, x, y, w, h);
			kfree (x);
						
			memcpy (&data->window, arg, sizeof (struct video_window));

#ifdef DVB
                        set_overlay_mode (saa, 1);
#endif
			break;
		}

		case SAA7146_V4L_GPICT:
		{
			struct video_picture *vp = arg;

			memcpy (vp, &data->picture, sizeof (struct video_picture));

gprintk (KERN_INFO "saa7146_v4l: ==> ioctl SAA7146_V4L_GPICT (bri=%d; con=%d; sat=%d; hue=%d; wn=%d; d=%d; p=%d)\n", vp->brightness, vp->contrast, vp->colour, vp->hue, vp->whiteness, vp->depth, vp->palette);

			break;
		}

		case SAA7146_V4L_SPICT:
		{
			struct video_picture *vp = arg;
			u32 bri, con, sat;
			u16 oformat = 0;

gprintk (KERN_INFO "saa7146_v4l: ==> ioctl SAA7146_V4L_SPICT (bri=%d; con=%d; sat=%d; hue=%d; wn=%d; d=%d; p=%d)\n", vp->brightness, vp->contrast, vp->colour, vp->hue, vp->whiteness, vp->depth, vp->palette);

			memcpy (&data->picture, vp, sizeof (struct video_picture));

			switch (data->picture.palette) {
			case VIDEO_PALETTE_RGB32:
				oformat = RGB32_COMPOSED;
				break;

			case VIDEO_PALETTE_RGB24:
				oformat = RGB24_COMPOSED;
				break;

			case VIDEO_PALETTE_RGB565:
				oformat = RGB16_COMPOSED;
				break;

			case VIDEO_PALETTE_RGB555:
				oformat = RGB15_COMPOSED;
				break;
#if 0
			case VIDEO_PALETTE_HI240:
				oformat = RGB8_COMPOSED;
				break;
#endif
			case VIDEO_PALETTE_YUV422:
			case VIDEO_PALETTE_YUYV:
				oformat = YUV422_COMPOSED + SAA7146_2BYTESWAP;
				break;

			case VIDEO_PALETTE_UYVY:
				oformat = YUV422_COMPOSED;
				break;

			case VIDEO_PALETTE_YUV411:
				oformat = YUV411_COMPOSED;
				break;

			case VIDEO_PALETTE_GREY:
				oformat = Y8_DECOMPOSED;
				break;

			default:
				return -EINVAL;
			}
			set_picture_prop (saa, (u32)(data->picture.brightness >> 8),
				(u32)(data->picture.contrast >> 9),
				(u32)(data->picture.colour >> 9));

			/* save those values in data struct which are really taken over */
			get_picture_prop (saa, &bri, &con, &sat);
			data->picture.brightness = (u16) (bri << 8);
			data->picture.contrast = (u16) (con << 9);
			data->picture.colour = (u16) (sat << 9);

			set_overlay_output_format (saa, oformat);

			break;
		}

		case SAA7146_V4L_CAPTURE:
		{
			int *i = arg;

gprintk (KERN_INFO "saa7146_v4l: ==> ioctl SAA7146_V4L_CAPTURE (mode=%d)\n", *i);

			if ((data->fbuf.base == NULL) || (data->window.width == 0) || (data->window.height == 0))
				return -EINVAL;

   			set_overlay_mode (saa, *i);
						
			break;
		}

		case SAA7146_V4L_GMBUF:
		{
                        struct video_mbuf *m = arg;
			int i = 0;
			
			m->size = SAA7146_MAX_BUF * GRABBING_MEM_SIZE;
			m->frames = SAA7146_MAX_BUF;

			for (i = 0; i < SAA7146_MAX_BUF; i++) {
				m->offsets[i] = i * GRABBING_MEM_SIZE;
			}

gprintk (KERN_INFO "saa7146_v4l: ==> ioctl SAA7146_V4L_GMBUF (size=%d; frames=%d)\n", m->size, m->frames);

			break;
		}

		case SAA7146_V4L_MCAPTURE:
		{
                        struct video_mmap *vm = arg;

gprintk (KERN_INFO "saa7146_v4l: ==> ioctl SAA7146_V4L_MCAPTURE (fr=%d; fmt=%d; w=%d; h=%d)\n", vm->frame, vm->format, vm->width, vm->height);

			/* check status for wanted frame */
			if (GBUFFER_UNUSED != saa->grab_stat[vm->frame]) {

hprintk (KERN_WARNING "saa7146_v4l: SAA7146_V4L_MCAPTURE: frame #%d buffer not free\n",vm->frame);

				return -EBUSY;
			}

			/* do necessary transformations from the videodev-structure to our own format. */		

			/* sanity checks */
			if (vm->width <= 0 || vm->height <= 0) {

hprintk (KERN_ERR "saa7146_v4l: SAA7146_V4L_MCAPTURE: invalid dimension for requested frame %d\n", vm->frame);

				return -EINVAL;
			}

			switch (vm->format) {
                        /* (Packed) RGB formats */
			case VIDEO_PALETTE_RGB32:
				saa->grab_format[vm->frame] = RGB32_COMPOSED;
				break;

			case VIDEO_PALETTE_RGB24:
				saa->grab_format[vm->frame] = RGB24_COMPOSED;
				break;

			case VIDEO_PALETTE_RGB565:
                           	saa->grab_format[vm->frame] = RGB16_COMPOSED;
				break;

			case VIDEO_PALETTE_RGB555:
                           	saa->grab_format[vm->frame] = RGB15_COMPOSED;
				break;
#if 0
			case VIDEO_PALETTE_HI240:
				saa->grab_format[vm->frame] = RGB8_COMPOSED;
				break;
#endif
                        /* Packed YUV formats */
			case VIDEO_PALETTE_YUV422:
			case VIDEO_PALETTE_YUYV:	/* YUY2 */
				saa->grab_format[vm->frame] = YUV422_COMPOSED + SAA7146_2BYTESWAP;
				break;

			case VIDEO_PALETTE_UYVY:
				saa->grab_format[vm->frame] = YUV422_COMPOSED;
				break;

			case VIDEO_PALETTE_YUV411:	/* Y41P, BtYUV */
				saa->grab_format[vm->frame] = YUV411_COMPOSED;
				break;

                        /* Planar YUV formats */
                        case VIDEO_PALETTE_YUV422P:
                           	/* if (vbi_running) return -EINVAL; */
                           	saa->grab_format[vm->frame] = YUV422_DECOMPOSED;
                                break;

                        case VIDEO_PALETTE_YUV420P:	/* YV12 */
                           	/* if (vbi_running) return -EINVAL; */
                           	saa->grab_format[vm->frame] = YUV420_DECOMPOSED;
                                break;

                        case VIDEO_PALETTE_YUV410P:	/* YVU9 */
                           	/* if (vbi_running) return -EINVAL; */
                           	saa->grab_format[vm->frame] = YUV9_DECOMPOSED;
                                break;

			case VIDEO_PALETTE_GREY:
				saa->grab_format[vm->frame] = Y8_DECOMPOSED;
				break;

			default:

hprintk (KERN_ERR "saa7146_v4l: SAA7146_V4L_MCAPTURE: invalid palette for requested frame %d\n", vm->frame);

				return -EINVAL;
                        }

	                /* copy grabbing information for the buffer */
	                saa->grab_height[vm->frame] = vm->height;
	                saa->grab_width[vm->frame]  = vm->width;
	                /* fixme: setting of grabbing port ?!*/
	                saa->grab_port[vm->frame]   = 0;

                        if (0 != (ret = set_up_grabbing (saa, vm->frame)))
                           	return ret;
			
			break;
		}

		case SAA7146_V4L_SYNC:
		{
			int frame = *((int*) arg);
			int count = 0, k = 0;
			unsigned char *grabbfr;
			unsigned char y, uv;
                        DECLARE_WAITQUEUE(wait, current);

gprintk (KERN_INFO "saa7146_v4l: ==> ioctl SAA7146_V4L_SYNC enter (fr=%d)\n", frame);

			/* sanity checks */
                        if (frame >= SAA7146_MAX_BUF || frame < 0) {

hprintk (KERN_ERR "saa7146_v4l: SAA7146_V4L_SYNC: frame number out of range (fr=%d)\n", frame);

				return -EINVAL;
			}

			/* get the state */
			switch (saa->grab_stat[frame]) {
				case GBUFFER_UNUSED:
					/* there was no grab to this buffer */

hprintk (KERN_ERR "saa7146_v4l: SAA7146_V4L_SYNC: no grab requested for this frame (fr=%d)\n", frame);

					return -EINVAL;

				case GBUFFER_QUEUED:
				case GBUFFER_GRABBING:
                                   	add_wait_queue (&saa->rps0_wq, &wait);
                                        current->state = TASK_INTERRUPTIBLE;
                                        while (saa->grab_stat[frame] == GBUFFER_GRABBING) {

hprintk (KERN_INFO "saa7146_v4l: SAA7146_V4L_SYNC: send sleeping (fr=%d)\n", frame);

                                           	schedule ();
                                                if (signal_pending (current)) {
                                                   	remove_wait_queue (&saa->rps0_wq, &wait);
                                                        current->state = TASK_RUNNING;
                                                        return -EINTR;
                                                }
                                        }
                                        remove_wait_queue (&saa->rps0_wq, &wait);
                                        current->state = TASK_RUNNING;
                                        /* fall thru (no "break;"!) */
				case GBUFFER_DONE:

hprintk (KERN_INFO "saa7146_v4l: SAA7146_V4L_SYNC: frame ready (fr=%d)\n", frame);

                                        /* set corresponding buffer to �unused� */
                                        saa->grab_stat[frame] = GBUFFER_UNUSED;
			}

			/* all saa7146�s below chip-revision 3 are not capable
			   of doing byte-swaps with video-dma1. for rgb-grabbing
			   this does not matter, but yuv422-grabbing has the
			   wrong byte-order, so we have to swap in software */
			if ((0 == saa->revision) && (saa->grab_format[frame] == YUV422_COMPOSED)) {
			
				/* swap UYVY to YUYV */
				count = saa->grab_height[frame]*saa->grab_width[frame]*2;
				grabbfr = ((unsigned char*)(saa->grab_buf))+frame*GRABBING_MEM_SIZE;
				for (k=0; k<count; k=k+2) {
					y = grabbfr[k+1];
					uv = grabbfr[k];
					grabbfr[k] = y;
					grabbfr[k+1] = uv;
				}
			}
						

			break;
		}

		case SAA7146_V4L_GNORM:
		{
			__u16 *inorm = arg;

			*inorm = (__u16) saa->norm;

gprintk (KERN_INFO "saa7146_v4l: ==> ioctl SAA7146_V4L_GNORM (norm=%d)\n", *inorm);

			break;
		}

		case SAA7146_V4L_SNORM:
		{
			__u16 *inorm = arg;

gprintk (KERN_INFO "saa7146_v4l: ==> ioctl SAA7146_V4L_NORM (norm=%d)\n", *inorm);

			if ((*inorm != VIDEO_MODE_PAL) && (*inorm != VIDEO_MODE_NTSC) && (*inorm != VIDEO_MODE_SECAM))
				return -EINVAL;

			saa->norm = (int) *inorm;
			/* overlay_set_windowposition (...) */
			/* overlay_set_windowsize (...) */

			break;
		}

		default:

			return -ENOIOCTLCMD;
	}
	
	return 0;
}

int
saa7146_v4l_attach (struct saa7146 *adap, void **p)
{
	struct saa7146_v4l_s *data = NULL;

fprintk ("saa7146_v4l: ==> saa7146_v4l_inc_use_attach\n");
					
	data = (struct saa7146_v4l_s *) kmalloc (sizeof (struct saa7146_v4l_s), GFP_KERNEL);
	if (0 == data) {
	    	printk (KERN_ERR "saa7146_v4l: not enough kernel-memory #2.\n");
		return -ENOMEM;
	}
	*(struct saa7146_v4l_s **) p = data;

	/* clear out structs */
	memset (&data->fbuf,	0x0, sizeof (struct video_buffer));
	memset (&data->mbuf,	0x0, sizeof (struct video_mbuf));
	memset (&data->window,	0x0, sizeof (struct video_window));
	memset (&data->picture,	0x0, sizeof (struct video_picture));

	data->picture.brightness = 32768;
	data->picture.contrast = 32768;
	data->picture.colour = 32768;	/* saturation */
	data->picture.depth = 16;
	data->picture.palette = VIDEO_PALETTE_RGB565;

	return 0;
}

void
saa7146_v4l_inc_use (struct saa7146 *adap)
{
#ifdef MODULE
	MOD_INC_USE_COUNT;
#endif
}

int
saa7146_v4l_detach (struct saa7146 *adap, void **p)
{
	struct saa7146_v4l_s **data = (struct saa7146_v4l_s **) p;

fprintk ("saa7146_v4l: ==> saa7146_v4l_dec_use_detach\n");

	/* release api-dependent initialisations */	
	kfree (*data);
	*data = NULL;

	return 0;
}

void
saa7146_v4l_dec_use (struct saa7146 *adap)
{
#ifdef MODULE
	MOD_DEC_USE_COUNT;
#endif
}

/* ------------------------------------------------------------------------ */

MODULE_AUTHOR("Michael Hunold <michael@mihu.de>, Rolf Siebrecht <rolf.siebrecht@t-online.de>");
MODULE_DESCRIPTION("V4L extension for Philips SAA7146 core driver");
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,10)
MODULE_LICENSE("GPL");
#endif

static struct saa7146_extension saa7146_v4l_extension = {
	"v4l extension\0",
        MASK_27,			/* handles rps0 irqs */
        saa7146_rps0_irq_callback,
	saa7146_v4l_command,
	saa7146_v4l_attach,
	saa7146_v4l_detach,
	saa7146_v4l_inc_use,
	saa7146_v4l_dec_use
};	

int __devinit
saa7146_v4l_init (void) 
{
	int res = 0;

fprintk (KERN_INFO "saa7146_v4l: ==> saa7146_v4l_init\n");

	if (0 != (res = saa7146_add_extension (&saa7146_v4l_extension))) {
		printk ("saa7146_v4l: extension registration failed, module not inserted.\n");
		return res;
	}
	
	return 0;
}

void __devexit
saa7146_v4l_cleanup (void) 
{
	int res = 0;

fprintk (KERN_INFO "saa7146_v4l: ==> saa7146_v4l_cleanup\n");

	if (0 != (res = saa7146_del_extension (&saa7146_v4l_extension))) {
		printk ("saa7146_v4l: extension deregistration failed, module not removed.\n");
	}
	
}

module_init(saa7146_v4l_init);
module_exit(saa7146_v4l_cleanup);

