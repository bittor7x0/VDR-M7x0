/* 
    mfII - Video4Linux Kernel driver for TechniSat MediaFocus II.

    Copyright (C) 2000,2001 Rolf Siebrecht <rolf.siebrecht@t-online.de>
   
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

*/    

/*
 *  Derived from
 *
 *  mxb - frame grabber driver for the 'Multimedia eXtension Board'
 *        by Siemens - Nixdorf.
 *
 *  Copyright (C) 1998,1999 Michael Hunold <michael@mihu.de>
 */

#ifndef __MFII_H__
#define __MFII_H__

#ifdef __KERNEL__

/* delay for muting the sound while changing to a new frequency */
#define TUNER_NOISE_DELAY 35
/* delay for muting the sound while changing audio settings */
#define AUDIO_NOISE_DELAY 200

/* VBI buffer */
#define VBI_MAXLINES	16
#define VBIBUF_SIZE	(2*VBI_MAXLINES*2048)
#define MP2BUF_SIZE	240000

/* place to store all the necessary device informations */
struct  mfII_struct {

	struct video_device	video;
	struct video_device	radio;
	struct video_device	vbi;

	struct saa7146 *spci;

	struct i2c_adapter	*saa7146;
	struct i2c_client	*saa7113h;
	struct i2c_client	*sp5055;
        struct i2c_client	*stv0056af;
	struct i2c_client	*msp3400c;
	struct i2c_client	*drp3510a;
	struct i2c_client	*eeprom;

	int	in_use;
	int	has_eeprom;

	u16	current_channel;	/* channel (= video source) number */
	u16	current_video_norm;	/* PAL/SECAM/NTSC */
	struct	video_window	current_overlay_win;
	struct	video_picture	current_overlay_pict;
	u16	current_overlay_state;	/* != 0: overlay capturing is running */
	u16	current_tuner;		/* tuner number */
	u32	current_freq;		/* transponder frequency */
	u16	current_22khz_state;	/* != 0: 22 kHz signal is on */
        u16	current_orbit_position; /* bit mask according to our private V4L extension */
	u16	current_audio_channel;	/* audio channel number */
	u16	current_audio_mode;	/* mono/stereo/.. */
	u16	current_audio_state;	/* mute/unmute */
        u16	current_volume;
        u16	current_bass;
        u16	current_treble;
        u16	current_balance;
	u16	current_left_carrier;
	u16	current_right_carrier;
};

/* these are the available video sources */
struct video_channel mfII_channels[] = {	/* chan, name[32], tuners, flags, type, norm */
   	{ 0, "SatTuner",1,
           VIDEO_VC_TUNER | VIDEO_VC_AUDIO,
           VIDEO_TYPE_TV,
           VIDEO_MODE_PAL	},
        { 1, "SatTuner+Decoder",1,
           VIDEO_VC_TUNER | VIDEO_VC_AUDIO,
           VIDEO_TYPE_TV,
	   VIDEO_MODE_PAL	},
	{ 2, "Composite-Video",0,
           VIDEO_VC_AUDIO,
           VIDEO_TYPE_CAMERA,
           VIDEO_MODE_PAL	},
	{ 3, "SVHS-Video",0,
           VIDEO_VC_AUDIO,
           VIDEO_TYPE_CAMERA,
	   VIDEO_MODE_PAL	}
};

enum { VCHAN_TUNER, VCHAN_TUNER_DECODER, VCHAN_C_VIDEO, VCHAN_S_VIDEO };

#define MFII_CHANNELS	(sizeof (mfII_channels) / sizeof (mfII_channels[0]))

#define MFII_MAXWIDTH	768
#define	MFII_MAXHEIGHT	576
#define	MFII_MINWIDTH	48
#define	MFII_MINHEIGHT	36

/* these are the available audio sources */
struct video_audio mfII_audios[] = {	/* chan, vol, bass, treble, flags, name, mode, balance, step */
   	{ 0,
	0, 0, 0,
        VIDEO_AUDIO_MUTABLE
	| VIDEO_AUDIO_VOLUME
	| VIDEO_AUDIO_BASS
	| VIDEO_AUDIO_TREBLE,
/*	| VIDEO_AUDIO_BALANCE, */
	"SatTuner-FM",
	VIDEO_SOUND_MONO
	| VIDEO_SOUND_STEREO
	| VIDEO_SOUND_LANG1
	| VIDEO_SOUND_LANG2,
        0, 0
	},

        { 1,
	0, 0, 0,
	VIDEO_AUDIO_MUTABLE
	| VIDEO_AUDIO_VOLUME
	| VIDEO_AUDIO_BASS
	| VIDEO_AUDIO_TREBLE,
/*	| VIDEO_AUDIO_BALANCE, */
	"SatTuner-AM",
	VIDEO_SOUND_MONO
	| VIDEO_SOUND_STEREO
	| VIDEO_SOUND_LANG1
	| VIDEO_SOUND_LANG2,
	0, 0
	},

        { 2,
	0, 0, 0,
	VIDEO_AUDIO_MUTABLE
	| VIDEO_AUDIO_VOLUME
	| VIDEO_AUDIO_BASS
	| VIDEO_AUDIO_TREBLE,
/*	| VIDEO_AUDIO_BALANCE, */
	"Mini-DIN",
	VIDEO_SOUND_MONO
	| VIDEO_SOUND_STEREO,
	0, 0
	},

        { 3,
	0, 0, 0,
	VIDEO_AUDIO_MUTABLE
	| VIDEO_AUDIO_VOLUME
	| VIDEO_AUDIO_BASS
	| VIDEO_AUDIO_TREBLE,
/*	| VIDEO_AUDIO_BALANCE, */
	"Internal-Audio",
        VIDEO_SOUND_MONO
	| VIDEO_SOUND_STEREO,
	0, 0
	}
};

enum { ACHAN_FM_AUDIO, ACHAN_AM_AUDIO, ACHAN_MINI_DIN, ACHAN_INTERNAL };

#define MFII_AUDIOS	(sizeof (mfII_audios) / sizeof (mfII_audios[0]))
		
/* this array holds the information of the audio source (mfII_audios),	      */
/* which has to be switched corresponding to the video source (mfII_channels) */
/* (not used yet)							      */
int video_audio_connect[MFII_CHANNELS] = {
	0,	/* VCHAN_TUNER:		ACHAN_FM_AUDIO */
	0,	/* VCHAN_TUNER_DECODER:	ACHAN_FM_AUDIO */
	2,	/* VCHAN_C_VIDEO:	ACHAN_MINI_DIN */
	2	/* VCHAN_S_VIDEO:	ACHAN_MINI_DIN */
};

/* these are the available tuners */
struct video_tuner mfII_tuners[] = {
   	{ 0, "Satellite",	/* video_tuner.tuner, video_tuner.name */
           15200,		/* video_tuner.rangelow -> 950 MHz */
           34400,		/* video_tuner.rangehigh -> 2150 MHz */
           VIDEO_TUNER_PAL	/* video_tuner.flags */
           | VIDEO_TUNER_NTSC
           | VIDEO_TUNER_SECAM
           | VIDEO_TUNER_NORM,
           0,			/* video_tuner.mode -> is filled in during query */
           0xffff	}	/* video_tuner.signal */
};

#define MFII_TUNERS	(sizeof (mfII_tuners) / sizeof (mfII_tuners[0]))

#endif
#endif

