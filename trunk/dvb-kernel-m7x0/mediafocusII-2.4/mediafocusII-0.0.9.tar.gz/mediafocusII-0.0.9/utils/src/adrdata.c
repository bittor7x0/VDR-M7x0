/* ---------------- ADR Data Definitions ----------------- */
unsigned char adr_databuf[512];	/* buffer for ADR data	*/
int adr_wridx;	/* write pointer/index; this is the place in adr_buf from */
		/* where on the next 4/8/15-byte data packet will be stored	*/
unsigned char adr_pckidx;	/* packet index from the "index" byte	*/
int adr_hdrfnd;	/* flag: stream header found */
int adr_oldhdridx;
unsigned char adr_chunkhdr[5] = {
	0xff, 0xfe, 0xfc, 0x00, 0x00	/* byte 3 may change */
};
unsigned char adr_chunklen;

char
*byt2bin (unsigned char byt)
{
	int i;
	static char s[8];

	memset (s, ' ', sizeof (s));
	for (i = 0; i < 8; i++) {
		if (byt & (0x80 >> i))
			s[i] = '1';
		else
			s[i] = '0';
	}
	return s;
}

void
clr_adrdata ()
{
	memset (adr_databuf, 0, sizeof (adr_databuf));
	adr_wridx = 0;
	adr_pckidx = 0;
	adr_hdrfnd = 0;
	adr_oldhdridx = 0;
}

/* get an ADR data packet from mediafocus card; store it in buffer if	*/
/* it has a new index and a valid signature */
void
get_adrdata ()
{
	unsigned char adrdata[20];
	unsigned char id_p;
	int cycl_len;		/* number of useful data bytes in packet */

	if (-1 == ioctl (fd, VIDIOCGADRDATA, adrdata)) {
		perror ("VIDIOCGADRDATA");
	}
	id_p = adrdata[1] >> 1;		/* get actual packet index */
	if (id_p == adr_pckidx)
		return;			/* exit if still old index */

	if (adr_wridx > sizeof (adr_databuf) - 16) {	/* buffer overflow */
		clr_adrdata ();
	}
	adr_pckidx = id_p;		/* save packet index */
	if (
		(adrdata[6] == 0xff) && (adrdata[7] == 0xff) &&
		(adrdata[8] == 0xff) && (adrdata[9] == 0xff) &&
		(adrdata[10] == 0xff) && (adrdata[11] == 0xff) &&
		(adrdata[12] == 0xff)
	) {
		cycl_len = 4;		/* accept sig for "4 useful data bytes" */
		adr_chunkhdr[2] = 0xfc;
	}
	else if (
		(adrdata[10] == 0xff) && (adrdata[11] == 0xff) &&
		(adrdata[12] == 0xff)
	) {
		cycl_len = 8;		/* accept sig for "8 useful data bytes" */
		adr_chunkhdr[2] = 0xfc;
	}
	else if (adrdata[16] == 0x00) {
		cycl_len = 15;		/* accept sig for "15 useful data bytes" */
		adr_chunkhdr[2] = 0x00;
	}
	else
		return;			/* ignore everything else */
	memcpy (adr_databuf + adr_wridx, adrdata+2, cycl_len);	/* store in buffer */
	adr_wridx += cycl_len;		/* increment write pointer/index */
}

void
eval_adrdata ()
{
	int hdr_idx;

	if (!adr_hdrfnd) {
		/* look for header in stream, continuing at last search pos */
		for (hdr_idx = adr_oldhdridx; ; hdr_idx++) {
			if (hdr_idx > adr_wridx - 6) {
				adr_oldhdridx = hdr_idx;
				return;
			}
			if (!memcmp (adr_databuf+hdr_idx, adr_chunkhdr, sizeof (adr_chunkhdr)))
				break;
		}
		/* complete header found */
		adr_hdrfnd += 1;
		adr_oldhdridx = 0;	/* ??? o.k.? */
		adr_chunklen = adr_databuf[hdr_idx+5];
		if (adr_chunklen > 0x7f) {
			clr_adrdata ();
			return;
		}
		/* shift buffer */
		memmove (adr_databuf, adr_databuf+hdr_idx, adr_wridx - hdr_idx);
		adr_wridx -= hdr_idx; 
	}
	if (adr_wridx > (6 + adr_chunklen + 2)) {	/* 6 header, 2 CRC sum */		/* chunk complete; show it */
		adr_hdrfnd = 0;		/* force new header search */
	}
}

#ifdef SIMPLE_ADRDATA_DISPLAY
void
show_adrdata ()
{
	int i;
	char buf[3 * 20 + 1];
	char buf1[3 * 20 + 1];
        char buf2[72];

	memset (buf1, ' ', sizeof (buf1));
	buf1[60] = '\0';
	for (i = 0; i < 20; i++) {
		sprintf (buf+(3*i), "%02x ", adrdata[i]);
		if ((i>1) && (i<17)) {
			sprintf (buf1+3*i, "%c  ", ((adrdata[i] >= ' ') && (adrdata[i] <= 'z')) ? (char) adrdata[i] : ' ');
		}
	}
        sprintf (buf2, "I:%d  L:%d  c0:%s  c1:%s  c2:%s   ", (adrdata[1]>>1)&127, adrdata[1]&1, byt2bin(adrdata[17]), "hallo", byt2bin(adrdata[1]));
	mvwaddstr (adrdatawin, 0, 1, buf);
	mvwaddstr (adrdatawin, 1, 1, buf1);
        mvwaddstr (adrdatawin, 2, 1, buf2);
	wrefresh (adrdatawin);
}
#endif
