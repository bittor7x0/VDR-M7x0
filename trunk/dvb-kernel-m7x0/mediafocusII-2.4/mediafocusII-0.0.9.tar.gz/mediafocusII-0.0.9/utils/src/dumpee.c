/*  dumpee.c - display a hexdump of TechniSat MediaFocusII serial eeprom

    Copyright (C) 2000  Rolf Siebrecht

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <getopt.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/videodev.h>

#include "../../linux/videodev_priv.h"

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#ifdef ENABLE_NLS
#include <libintl.h>
#define _(String)		gettext (String)
#define gettext_noop(String)	(String)
#define N_(String)		gettext_noop (String)
#else
#define _(String)		(String)
#define N_(String)		(String)
#endif

#define INTERFACE_NAME	"TechniSat MediaFocusII Video"
#define DEFAULT_DEVICE	"/dev/video"

void
usage ()
{
   	printf (_("usage: dumpee [<options>]\n"));
        printf (_("options:\n"));
        printf (_(" -d, --device=<dev>	select v4l device <dev=/dev/video0 | /dev/video1 | ...>\n"));
        printf (_(" -h, --help		show this help\n"));
        printf (_("\ndefaults:\n"));
        printf (_("  device = %s\n"), DEFAULT_DEVICE);
}

int
get_ee_byte (int fd, unsigned short int addr, unsigned char *data)
{
        struct eeprom_s ee;
        
        memset (&ee, 0, sizeof (ee));
        ee.addr = addr;
	ee.count = 0;
	ee.data = data;
   	if (-1 == ioctl (fd, VIDIOCGEEPROM, &ee)) {
           	perror ("VIDIOCGEEPROM");
                return -1;
        }
   	return 0;
}

int
put_ee_byte (int fd, unsigned short int addr, unsigned char data)
{
	struct eeprom_s ee;

	memset (&ee, 0, sizeof (ee));
	ee.addr = addr;
	ee.count = 0;
	ee.data = &data;
	if (-1 == ioctl (fd, VIDIOCSEEPROM, &ee)) {
		perror ("VIDIOCSEEPROM");
		return -1;
	}
	return 0;
}

void
dump_eeprom (int fd)
{
   	int addr = 0;
        unsigned char byte;

        while (addr < 256) {
           	if (0 == (addr % 16))
                   	printf ("0x%04x:  ", addr);
           	if (get_ee_byte (fd, addr, &byte))
                   	break;
                printf ("%02x ", byte);
                if (15 == (addr % 16))
                   	printf ("\n");
                addr++;
        }
}

int
open_device (char *dev, int *fd)
{
	struct video_capability vc;
        
	if (-1 == (*fd = open (dev, O_RDONLY))) {
		fprintf (stderr, _("open %s: %s\n"), dev, strerror (errno));
		return -1;
	}
	if (-1 == ioctl (*fd, VIDIOCGCAP, &vc)) {
		fprintf (stderr, "VIDIOCGCAP %s: %s\n", dev, strerror (errno));
		if (-1 == close (*fd)) perror (_("close"));
		return -1;
	}
	if (strncmp (vc.name, INTERFACE_NAME, strlen (INTERFACE_NAME))) {
		fprintf (stderr, _("can't run without %s registered at %s\n"), INTERFACE_NAME, dev);
		if (-1 == close (*fd)) perror (_("close"));
		return -1;
	}
        return 0;
}

void
close_device (int fd)
{
	if (-1 == close (fd)) perror (_("close"));
	return;
}

int
main (int argc, char **argv)
{
   	int c, longindex, fd;
        char device[80];
        const struct option longopts[] = {
           	{ "device",	required_argument,0,'d' },
		{ "help",	no_argument,0,'h'	},
                { 0, 0, 0, 0 },
        };
        
#ifdef ENABLE_NLS
	setlocale (LC_ALL, "");
	textdomain (PACKAGE);
	bindtextdomain (PACKAGE, LOCALE_DIR);
#endif

        strcpy (device, DEFAULT_DEVICE);
        while ((c = getopt_long (argc, argv, "d:h?", longopts, &longindex)) != EOF) {
           	switch (c) {
                   	case 'd':
                           	strcpy (device, optarg);
                                break;
                        case 'h':
                        case '?':
                           	usage ();
                                exit (1);
                        default:
                        fprintf (stderr, _("Unknown option.\n"));
                           	usage ();
                                exit (1);
                }
        }
        
        if (open_device (device, &fd)) {
		exit (-1);
	}
#if 0
	put_ee_byte (fd, 0, 0x49);
	put_ee_byte (fd, 1, 0x49);
	put_ee_byte (fd, 2, 0x13);
	put_ee_byte (fd, 3, 0xc2);
	put_ee_byte (fd, 4, 0x26);
	put_ee_byte (fd, 5, 0x0f);
#endif
        dump_eeprom (fd);
        
        close_device (fd);
        exit (0);
}
