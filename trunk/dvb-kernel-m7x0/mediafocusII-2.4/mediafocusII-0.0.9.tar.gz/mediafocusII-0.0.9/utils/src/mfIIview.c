/* 
   	Inspired by WebcamPlus.c, a free-to-use program by Edgard A. Sotter
	<esotter@etse.urv.es> published at the Video4Linux Mailing list
	in March 2001.
*/

#undef	DEBUG

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#include <linux/videodev.h>
#include <gtk/gtk.h>

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#ifdef ENABLE_NLS
#include <libintl.h>
#define _(String)		gettext (String)
#define gettext_noop(String)	(String)
#define N_(String)		gettext_noop (String)
#else
#define _(String)		(String)
#define N_(String)		(String)
#endif

#define	PROGNAME		"mfIIview"

#define V4L_DEVICE		"/dev/video"	/* default V4L device */
#define V4L_CHANNEL		0	/* the video channel we want to use for this application */
#define	V4L_COLOUR_PALETTE	VIDEO_PALETTE_RGB32
#define	V4L_COLOUR_DEPTH	32	/* you may select either 24 or 32 here */

int viddev;
struct video_picture vidpic;
struct video_window vidwin;
struct video_mbuf vidmbuf;

guchar *bigbuf;
guchar *buf = NULL;
GtkWidget *window, *darea;

struct buffer_s {
   	int nr;
        int maxnr;
        int verbose;
        struct timeval old_tv;
} buffer;

/* callback functions */
static gint on_darea_expose (GtkWidget *widget, GdkEventExpose *event);
static gint show_frames (gpointer data);

void usage (void)
{
   	printf (_("usage: %s <options>\n"), PROGNAME);
        printf (_("options:\n"));
        printf (_(" -d, --device=<v4ldev>	use V4L device <v4ldev>, e.g. /dev/video0\n"));
        printf (_(" -v, --verbose		show Video4Linux settings and achieved frame rate\n"));
        printf (_(" -h, --help		show help\n"));
}

/* ------------------------------------------------------------------ */
		/* Open V4L device and prepare it for working */
/* ------------------------------------------------------------------ */
void prepare_v4l (char *dev, int verbose)
{
   	struct video_capability vidcapab;
	struct video_channel vidchan;
	int j;

#ifdef	DEBUG
	fprintf (stderr, "%s: prepare_v4l begun.\n", PROGNAME);
#endif

/* --------------------  OPEN VIDEO DEVICE  ------------------------- */

	viddev = open (dev, O_RDWR);

	if (viddev < 0) {
		g_error (_("%s: open %s: %s\n"), PROGNAME, dev, g_strerror (errno));
	}

/* -------------------	VIDEO CAPABILITIES   ------------------------ */

	if (-1 == ioctl (viddev, VIDIOCGCAP, &vidcapab)) {
           	g_error ("%s: ioctl VIDIOCGCAP: %s", PROGNAME, g_strerror (errno));
	}
        if (verbose) {
           	printf (_("device name:       %s\n"), vidcapab.name);
                printf (_("device attributes: "));
                if (vidcapab.type & VID_TYPE_CAPTURE) printf ("CanCapture ");
                if (vidcapab.type & VID_TYPE_TUNER) printf ("HasTuner ");
                if (vidcapab.type & VID_TYPE_TELETEXT) printf ("CanTeletext ");
                if (vidcapab.type & VID_TYPE_OVERLAY) printf ("CanOverlay ");
                if (vidcapab.type & VID_TYPE_CHROMAKEY) printf ("IsChromakeyed ");
                if (vidcapab.type & VID_TYPE_CLIPPING) printf ("CanClipping ");
                if (vidcapab.type & VID_TYPE_FRAMERAM) printf ("OverwritesFrameBuffer ");
                if (vidcapab.type & VID_TYPE_SCALES) printf ("CanScaling ");
                if (vidcapab.type & VID_TYPE_MONOCHROME) printf ("GreyscaleOnly ");
                if (vidcapab.type & VID_TYPE_SUBCAPTURE) printf ("CanSubcapture ");
                printf ("\n");
                printf (_("number of video channels: %d\n"), vidcapab.channels);
                printf (_("number of audio channels: %d\n"), vidcapab.audios);
                printf (_("maximum capture width:    %d\n"), vidcapab.maxwidth);
                printf (_("maximum capture height:   %d\n"), vidcapab.maxheight);
                printf (_("minimum capture width:    %d\n"), vidcapab.minwidth);
                printf (_("minimum capture height:   %d\n\n"), vidcapab.minheight);
        }
	if ((vidcapab.channels == 0) || (vidcapab.maxwidth == 0) || (vidcapab.maxheight == 0) || (!(vidcapab.type & VID_TYPE_CAPTURE))) {
		g_error (_("%s: %s: Not capable of doing image grabbings.\n"), PROGNAME, vidcapab.name);
	}

/* --------------------------- VIDEO CHANNEL ------------------------ */

	/* get current settings of "our" video channel */
	vidchan.channel = V4L_CHANNEL;
        if (-1 == ioctl (viddev, VIDIOCGCHAN, &vidchan)) {
		g_error ("%s: ioctl VIDIOCGCHAN: %s", PROGNAME, g_strerror (errno));
	}
	if (verbose) {
		printf (_("video channel:		%d\n"), V4L_CHANNEL);
		printf (_("video channel name:	%s\n"), vidchan.name);
		printf (_("number of tuners:	%d\n"), vidchan.tuners);
		printf (_("video channel flags:	"));
		if (vidchan.flags & VIDEO_VC_TUNER) printf ("HasTuner ");
		if (vidchan.flags & VIDEO_VC_AUDIO) printf ("HasAudio ");
		printf ("\n");
		printf (_("video channel type:	"));
		if (vidchan.type & VIDEO_TYPE_TV) printf ("IsTV ");
		if (vidchan.type & VIDEO_TYPE_CAMERA) printf ("IsCamera ");
		printf ("\n");
		printf (_("current norm:		"));
		switch (vidchan.norm) {
		case VIDEO_MODE_PAL:
			printf ("PAL\n");
			break;
		case VIDEO_MODE_NTSC:
			printf ("NTSC\n");
			break;
		case VIDEO_MODE_SECAM:
			printf ("SECAM\n");
			break;
		case VIDEO_MODE_AUTO:
			printf ("Auto\n");
			break;
		default:
			printf (_("(unknown)\n"));
		}
	}
	/* now set "our" video channel */
	vidchan.channel = V4L_CHANNEL;	/* shoudn't be necessary */
	if (-1 == ioctl (viddev, VIDIOCSCHAN, &vidchan)) {
		g_error ("%s: ioctl VIDIOCSCHAN: %s", PROGNAME, g_strerror (errno));
	}

/* --------------------------  CAPTURE WINDOW  ---------------------- */

	if (-1 == ioctl (viddev, VIDIOCGWIN, &vidwin)) {
           	g_error ("%s: ioctl VIDIOCGWIN: %s", PROGNAME, g_strerror (errno));
	}
        if (verbose) {
           	printf (_("window x origin:    %d\n"), vidwin.x);
                printf (_("window y origin:    %d\n"), vidwin.y);
                printf (_("window width:       %d\n"), vidwin.width);
                printf (_("window height:      %d\n"), vidwin.height);
                printf (_("window chromakey:   0x%08x\n"), vidwin.chromakey);
                printf (_("window flags:       0x%08x\n\n"), vidwin.flags);
        }
	if ((vidwin.width < vidcapab.minwidth) || (vidwin.width > vidcapab.maxwidth) || (vidwin.height < vidcapab.minheight) || (vidwin.height > vidcapab.maxheight)) {
		g_error (_("%s: %s: Has no proper window settings (width=%d; height=%d).\n"), PROGNAME, vidcapab.name, vidwin.width, vidwin.height);
	}

/* -------------------------  IMAGE PROPERTIES  --------------------- */

	if (-1 == ioctl (viddev, VIDIOCGPICT, &vidpic)) {
		g_error ("%s: ioctl VIDIOCGPICT: %s", PROGNAME, g_strerror (errno));
	}
        if (verbose){
		printf (_("image brightness:   %.1f %%\n"), (float)vidpic.brightness / 65535.0 * 100.0);
                printf (_("image contrast:     %.1f %%\n"), (float)vidpic.contrast / 65535.0 * 100.0);
                printf (_("image saturation:   %.1f %%\n"), (float)vidpic.colour / 65535.0 * 100.0);
                printf (_("image hue:          %.1f %%\n"), (float)vidpic.hue / 65535.0 * 100.0);
                printf (_("image whiteness:    %.1f %%\n"), (float)vidpic.whiteness / 65535.0 * 100.0);
        }
	vidpic.depth = V4L_COLOUR_DEPTH;
	vidpic.palette = V4L_COLOUR_PALETTE;
	if (-1 == ioctl (viddev, VIDIOCSPICT, &vidpic)) {
		g_error ("%s: ioctl VIDIOCSPICT: %s", PROGNAME, g_strerror (errno));
	}
        if (verbose) {
                printf (_("image colour depth: %d\n"), vidpic.depth);
                printf (_("image palette:      "));
                switch (vidpic.palette) {
                case 1:
                   	printf ("GREY\n");
                        break;
                case 2:
                   	printf ("HI240\n");
                        break;
                case 3:
                   	printf ("RGB565\n");
                        break;
                case 4:
                   	printf ("RGB24\n");
                        break;
                case 5:
                   	printf ("RGB32\n");
                        break;
                case 6:
                   	printf ("RGB555\n");
                        break;
                case 7:
                   	printf ("YUV422\n");
                        break;
                case 8:
                   	printf ("YUYV\n");
                        break;
                case 9:
                   	printf ("UYVY\n");
                        break;
                case 10:
                   	printf ("YUV420\n");
                        break;
                case 11:
                   	printf ("YUV411\n");
                        break;
                case 12:
                   	printf ("RAW\n");
                        break;
                case 13:
                   	printf ("YUV422P\n");
                        break;
                case 14:
                   	printf ("YUV411P\n");
                        break;
                case 15:
                   	printf ("YUV420P\n");
                        break;
                case 16:
                   	printf ("YUV410P\n");
                        break;
                default:
                   	printf ("(?)\n");
                }
                printf ("\n");
        }

/* --------------------------  MAPPING BUFFER  ---------------------- */

	if (-1 == ioctl (viddev, VIDIOCGMBUF, &vidmbuf)) {
           	g_error ("%s: ioctl VIDIOCGMBUF: %s", PROGNAME, g_strerror (errno)); 
	}
        if (verbose) {
           	printf (_("mapping buffer total size: 0x%x\n"), vidmbuf.size);
                printf (_("number of frame buffers:   %d\n"), vidmbuf.frames);
                printf (_("frame buffer offsets:      "));
                for (j = 0; j < vidmbuf.frames; j++) {
                   	printf ("0x%x ", vidmbuf.offsets[j]);
                }
                printf ("\n\n");
        }
	bigbuf = (char *) mmap (0, vidmbuf.size, PROT_READ | PROT_WRITE, MAP_SHARED, viddev, 0);
	if (-1 == *(int *) bigbuf) {
           	g_error (_("%s: mmap failed\n"), PROGNAME);
	}

#ifdef	DEBUG
	fprintf (stderr, "%s: prepare_v4l done.\n", PROGNAME);
#endif
}

/* ------------------------------------------------------------------ */
		/* CREATE DISPLAY WINDOW AND IMAGE AREA */
/* ------------------------------------------------------------------ */
void init_gtk (int *argc, char ***argv)
{
#ifdef	DEBUG
	fprintf (stderr, "%s: init_gtk begun.\n", PROGNAME);
#endif

	gtk_init (argc, argv);
	gdk_init (argc, argv);
	gdk_rgb_init ();

#ifdef	DEBUG
	fprintf (stderr, "%s: init_gtk done.\n", PROGNAME);
#endif
}

/* callback function */
static gint on_darea_expose (GtkWidget *widget, GdkEventExpose *event)
{
#ifdef	DEBUG
   	fprintf (stderr, "%s: on_darea_expose begun (count=%d).\n", PROGNAME, event->count);
#endif
	if (buf == NULL) {
#ifdef	DEBUG
		fprintf (stderr, "%s: on_darea_expose aborted\n", PROGNAME);
#endif
		return TRUE;
        }

#if (V4L_COLOUR_DEPTH == 24)
	gdk_draw_rgb_image (widget->window, widget->style->fg_gc[GTK_STATE_NORMAL],
		0, 0, /* event->area.x, event->area.y */
                event->area.width, event->area.height,
		GDK_RGB_DITHER_MAX, buf, event->area.width * 3);
#endif
#if (V4L_COLOUR_DEPTH == 32)
	gdk_draw_rgb_32_image (widget->window, widget->style->fg_gc[GTK_STATE_NORMAL],
		0, 0, /* event->area.x, event->area.y */
                event->area.width, event->area.height,
		GDK_RGB_DITHER_MAX, buf, event->area.width * 4);
#endif

#if 0
   	gtk_main_quit ();
#endif

#ifdef	DEBUG
        fprintf (stderr, "%s: on_darea_expose done.\n", PROGNAME);
#endif
   	return FALSE;
}

void quit (gpointer data)
{
   	gtk_exit (0);
}

void prepare_gtk (void)
{
#ifdef	DEBUG
	fprintf (stderr, "%s: prepare_gtk begun.\n", PROGNAME);
#endif

	window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	gtk_signal_connect_object (GTK_OBJECT(window), "delete_event", 
		GTK_SIGNAL_FUNC(gtk_widget_destroy), GTK_OBJECT(window));
        gtk_signal_connect (GTK_OBJECT(window), "destroy",
           	GTK_SIGNAL_FUNC(quit), NULL);
	
	darea = gtk_drawing_area_new ();
   	gtk_drawing_area_size (GTK_DRAWING_AREA (darea), vidwin.width, vidwin.height);
	gtk_container_add (GTK_CONTAINER(window), darea);
        gtk_signal_connect (GTK_OBJECT(darea), "expose_event",
    		GTK_SIGNAL_FUNC(on_darea_expose), NULL);
   	gtk_widget_show (darea);

        gtk_idle_add (show_frames, &buffer);
        
	gtk_widget_show (window);
#ifdef	DEBUG
	fprintf (stderr, "%s: prepare_gtk done.\n", PROGNAME);
#endif
}

/* ------------------------------------------------------------------ */
		/* DISPLAY IMAGE */
/* ------------------------------------------------------------------ */
void display (GtkWidget *window, GtkWidget *darea)
{
	GdkRectangle update_rect;

#ifdef	DEBUG
	fprintf (stderr, "%s: display begun.\n", PROGNAME);
#endif	
	update_rect.x = 0;
	update_rect.y = 0;
	update_rect.width = vidwin.width;
	update_rect.height = vidwin.height;
	gtk_widget_draw (darea, &update_rect);
#if 0
   	gtk_main();
#endif
#ifdef	DEBUG
	fprintf (stderr, "%s: display done.\n", PROGNAME);
#endif
}

/* ------------------------------------------------------------------ */
		/* REQUEST A FRAME FROM V4L DEVICE */
/* ------------------------------------------------------------------ */
void request_frame (int bufnr)
{
   	struct video_mmap vidmmap;

#ifdef	DEBUG
	fprintf (stderr, "%s: request_frame begun (buf=%d).\n", PROGNAME, bufnr);
#endif
   	vidmmap.frame = bufnr;
	vidmmap.width = vidwin.width;
	vidmmap.height = vidwin.height;
	vidmmap.format = vidpic.palette;
        if (-1 == ioctl (viddev, VIDIOCMCAPTURE, &vidmmap)) {
           	g_error ("%s: ioctl VIDIOCMCAPTURE: %s", PROGNAME, g_strerror (errno));
        }
#ifdef	DEBUG
	fprintf (stderr, "%s: request_frame done (buf=%d).\n", PROGNAME, bufnr);
#endif
}

/* ------------------------------------------------------------------ */
		/* WAIT FOR A FRAME TO BE READY */
/* ------------------------------------------------------------------ */
void sync_frame (int bufnr)
{
   	int ret;

#ifdef	DEBUG
	fprintf (stderr, "%s: sync_frame begun (buf=%d).\n", PROGNAME, bufnr);
#endif  
        ret = -1;
	while (ret < 0) {
           	ret = ioctl (viddev, VIDIOCSYNC, &bufnr);
		if ((ret < 0) && (errno == EINTR))
			continue;
		if (ret < 0) {
                   	g_error ("%s: ioctl VIDIOCSYNC: %s", PROGNAME, g_strerror (errno));
		}
		break;
	}
#ifdef	DEBUG
	fprintf (stderr, "%s: sync_frame done (buf=%d).\n", PROGNAME, bufnr);
#endif
}

/* ------------------------------------------------------------------ */
		/* MAKE RGB CONVERSION AND DISPLAY FRAME */
/* ------------------------------------------------------------------ */
void process_frame (int bufnr)
{
   	int loop, loop_end;
        guchar pix;
        
#ifdef	DEBUG
	fprintf (stderr, "%s: process_frame begun (buf=%d).\n", PROGNAME, bufnr);
#endif
	buf = bigbuf + vidmbuf.offsets[bufnr];

	/* BGR -> RGB conversion */
#if (V4L_COLOUR_DEPTH) == 24
	loop_end = vidwin.width * vidwin.height * 3;
#endif
#if (V4L_COLOUR_DEPTH) == 32
	loop_end = vidwin.width * vidwin.height * 4;
#endif

#ifdef	DEBUG
	fprintf (stderr, "%s: process_frame: loop_end = %d.\n", PROGNAME, loop_end);
#endif

#if (V4L_COLOUR_DEPTH == 24)
	for (loop = 0; loop < loop_end; loop += 3) {
#endif
#if (V4L_COLOUR_DEPTH == 32)
	for (loop = 0; loop < loop_end; loop += 4) {
#endif
		pix = buf[loop + 2];
		buf[loop + 2] = buf[loop];
		buf[loop] = pix;
	}

	display (window, darea);
#ifdef	DEBUG
	fprintf (stderr, "%s: process_frame done (buf=%d).\n", PROGNAME, bufnr);
#endif
}

static gint show_frames (gpointer data)
{
   	struct buffer_s *buffer = (struct buffer_s *) data;
	struct timeval tv;

#ifdef	DEBUG
	fprintf (stderr, "%s: show_frames begun.\n", PROGNAME);
#endif
        sync_frame (buffer->nr);
        if (buffer->verbose) {
                gettimeofday (&tv, NULL);
                fprintf (stderr, "  rate: %4.1f fps  \r", 1000000.0 / ((tv.tv_sec * 1000000.0 + tv.tv_usec) - (buffer->old_tv.tv_sec * 1000000.0 + buffer->old_tv.tv_usec)));
   		buffer->old_tv = tv;
   	}

        process_frame (buffer->nr);
        request_frame (buffer->nr);
	buffer->nr = (buffer->nr + 1) % buffer->maxnr;
#ifdef	DEBUG
	fprintf (stderr, "%s: show_frames done.\n", PROGNAME);
#endif
	return TRUE;
}

/* ------------------------------------------------------------------ */
		/* MAIN PROGRAM */
/* ------------------------------------------------------------------ */
int main (int argc, char **argv)
{
        int buf;
        int c, longindex;
        char *v4ldev = V4L_DEVICE;
        const struct option longopts[] = {
           	{ "device",	required_argument,0,'d' },
           	{ "help",	no_argument,0,'h' },
           	{ "verbose",	no_argument,0,'v' },
                { 0, 0, 0, 0 },
        };

 	gtk_set_locale ();
#ifdef ENABLE_NLS
	/* setlocale (LC_ALL, ""); */
	textdomain (PACKAGE);
	bindtextdomain (PACKAGE, LOCALE_DIR);
#endif

        init_gtk (&argc, &argv);

        buffer.verbose = 0;
        while ((c = getopt_long (argc, argv, "dhv?", longopts, &longindex)) != EOF) {
           	switch (c) {
                   	case 'd':
                           	v4ldev = optarg;
                           	break;
                   	case 'v':
                           	buffer.verbose = 1;
                                break;
                        case 'h':
                        case '?':
                           	usage ();
                                exit (1);
                        default:
                           	fprintf (stderr, _("%s: Unknown command line option.\n"), PROGNAME);
                                usage ();
                                exit (1);
                }
        }
        
        prepare_v4l (v4ldev, buffer.verbose);
        prepare_gtk ();
        
/* ----------------------  INITIAL CAPTURE  ------------------------- */

   	buffer.maxnr = vidmbuf.frames;
   	for (buf = 0; buf < buffer.maxnr; buf++)
		request_frame (buf);
#ifdef	DEBUG
	fprintf (stderr, "%s: all buffers initially requested.\n", PROGNAME);
#endif
   	if (buffer.verbose) {
		gettimeofday (&buffer.old_tv, NULL);
        }

/* -----------------------  CAPTURE LOOP  --------------------------- */

	buffer.nr = 0;
#ifdef	DEBUG
	fprintf (stderr, "%s: entering gtk main loop.\n", PROGNAME);
#endif        
        gtk_main ();
        
        return 0;
}
