/*  mfIIset.c - V4L video control application (command line tool)
   		for TechniSat MediafocusII driver

    Copyright (C) 2001  Rolf Siebrecht

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#define PROGNAME	"mfIIset"
#define INTERFACE_NAME	"TechniSat MediaFocusII Video"
#define DEFAULT_DEVICE	"/dev/video"

#include "common.c"
#include "frequencies.c"

/* more global variables */
int cmd_brightness = 0;	__u16 arg_brightness;
int cmd_channel = 0;	int arg_channel;
int cmd_palette = 0;	int arg_palette;
int cmd_contrast = 0;	__u16 arg_contrast;
int cmd_norm = 0;	int arg_norm;
int cmd_saturation = 0;	__u16 arg_saturation;
int cmd_hue = 0;	__u16 arg_hue;
int cmd_whiteness = 0;	__u16 arg_whiteness;
int cmd_width = 0;	__u32 arg_width;
int cmd_height = 0;	__u32 arg_height;
int cmd_depth = 0;	__u16 arg_depth;


void
usage ()
{
	printf (_("usage: %s <options>\n"), PROGNAME);
	printf (_("options:\n"));
	printf (_("-a, --audio={%s | %s | %s | %s}\tselect audio decoding mode\n"), OPTSTR_STEREO, OPTSTR_MONO, OPTSTR_LANG1, OPTSTR_LANG2);
	printf (_("-b, --brightness=<%d...%d>\tset image brightness level\n"), LOLIMIT_PICT, HILIMIT_PICT);
	printf (_("-c, --channel={0 | 1 | ...}\tselect video channel (as reported by mfIIinfo)\n"));
	printf (_("-d, --device={/dev/video0 | /dev/video1 | ...}\tselect V4L device\n"));
	printf (_("-e, --palette=<%d...%d>\t\tset image palette (as specified by V4L API)\n"), LOLIMIT_PALETTE, HILIMIT_PALETTE);
	printf (_("-f, --frequency=<%.2f...%.2f>\tset receiving frequency [GHz]\n"), (float) LOLIMIT_FREQ / 1000000.0, (float) HILIMIT_FREQ / 1000000.0);
	printf (_("-h, --help\t\t\tshow this help\n"));
	printf (_("-i, --hiband={%s | %s}\tselect high Ku-band\n"), OPTSTR_OFF, OPTSTR_ON);
	printf (_("-k, --contrast=<%d...%d>\tset image contrast level\n"), LOLIMIT_PICT, HILIMIT_PICT);
	printf (_("-l, --lof=<value>\t\tlocal oscillator frequency of LNB [GHz]\n"));
	printf (_("-m, --mute={%s | %s}\tselect audio mute state\n"), OPTSTR_OFF, OPTSTR_ON);
	printf (_("-n, --norm={%s | %s | %s}\tselect colour norm\n"), OPTSTR_PAL, OPTSTR_SECAM, OPTSTR_NTSC);
	printf (_("-p, --polarization={%s | %s}\tselect LNB polarization\n"), OPTSTR_HOR, OPTSTR_VERT);
	printf (_("-q, --satellite=<%d...%d>\tselect satellite orbit position per DiSEqC\n"), LOLIMIT_SAT, HILIMIT_SAT);
	printf (_("-s, --saturation=<%d...%d>\tset image colour saturation level\n"), LOLIMIT_PICT, HILIMIT_PICT);
	printf (_("-t, --transponder=<Ann>\tselect Astra transponder nn\n"));
	printf (_("-u, --hue=<%d...%d>\t\tset image colour hue level\n"), LOLIMIT_PICT, HILIMIT_PICT);
	printf (_("-v, --volume=<%d...%d>\tset volume level\n"), LOLIMIT_SOUND, HILIMIT_SOUND);
	printf (_("-w, --whiteness=<%d...%d>\tset image whiteness level\n"), LOLIMIT_PICT, HILIMIT_PICT);
	printf (_("-x, --width=<%d...%d>\t\tset image capture width\n"), LOLIMIT_WIDTH, HILIMIT_WIDTH);
	printf (_("-y, --height=<%d...%d>\tset image capture height\n"), LOLIMIT_HEIGHT, HILIMIT_HEIGHT);
	printf (_("-z, --depth={8 | 16 | ...}\tset image capture colour depth (bits/pixel)\n\n"));
	printf (_("defaults (if corresponding option not specified):\n"));
	printf ("  device=%s\n", DEFAULT_DEVICE);
	printf ("  lof=%4.2f [GHz] (lo-band)\n", (float) DEFAULT_LO_LOF / 1000000.0);
	printf ("  lof=%4.2f [GHz] (hi-band)\n", (float) DEFAULT_HI_LOF / 1000000.0);
	printf ("  polarization=%s\n", (DEFAULT_BITMASK_POL == HPOL) ? OPTSTR_HOR : OPTSTR_VERT);
        printf ("  hiband=%s\n", (DEFAULT_BITMASK_BAND == HIBAND) ? OPTSTR_ON : OPTSTR_OFF);
	printf ("  satellite=%c\n", (DEFAULT_BITMASK_SAT == 0) ? '1' : '?');
}

void
check_audio (char *arg)
{
	int cmd = 0;

        if (!strcmp (arg, OPTSTR_STEREO)) {
		cmd += 1;
		arg_audio = VIDEO_SOUND_STEREO;
	}
        if (!strcmp (arg, OPTSTR_MONO)) {
		cmd += 1;
		arg_audio = VIDEO_SOUND_MONO;
	}
        if (!strcmp (arg, OPTSTR_LANG1)) {
		cmd += 1;
		arg_audio = VIDEO_SOUND_LANG1;
	}
        if (!strcmp (arg, OPTSTR_LANG2)) {
		cmd += 1;
		arg_audio = VIDEO_SOUND_LANG2;
	}
        if (!cmd) {
           	fprintf (stderr, _("%s: Unknown \"audio\" argument. \"audio\" command deleted.\n"), PROGNAME);
                return;
        }
	cmd_audio += 1;
}

void
check_brightness (char *arg)
{
	int val;
	char *end;
	size_t const l = strlen (arg);

	val = strtol (arg, &end, 0);
	if (end - arg < l) {
		fprintf (stderr, _("%s: Format error in \"brightness\" argument. \"brightness\" command deleted.\n"), PROGNAME);
		return;
	}
	if ((val < LOLIMIT_PICT) || (val > HILIMIT_PICT)) {
		fprintf (stderr, _("%s: \"brightness\" argument out of range. \"brightness\" command deleted.\n"), PROGNAME);
		return;
	}
	cmd_brightness += 1;
	arg_brightness = val;
}

void
check_channel (char *arg)
{
	int val;
	char *end;
	size_t const l = strlen (arg);

	val = strtol (arg, &end, 0);
	if (end - arg < l) {
		fprintf (stderr, _("%s: Format error in \"channel\" argument. \"channel\" command deleted.\n"), PROGNAME);
		return;
	}
	if (val < LOLIMIT_CHAN) {
		fprintf (stderr, _("%s: \"channel\" argument out of range. \"channel\" command deleted.\n"), PROGNAME);
		return;
	}
	cmd_channel += 1;
	arg_channel = val;
}

void
check_palette (char *arg)
{
	int val;
	char *end;
	size_t const l = strlen (arg);

	val = strtol (arg, &end, 0);
	if (end - arg < l) {
		fprintf (stderr, _("%s: Format error in \"palette\" argument. \"palette\" command deleted.\n"), PROGNAME);
		return;
	}
	if ((val < LOLIMIT_PALETTE) || (val > HILIMIT_PALETTE)) {
		fprintf (stderr, _("%s: \"palette\" argument out of range. \"palette\" command deleted.\n"), PROGNAME);
		return;
	}
	cmd_palette += 1;
	arg_palette = val;
}

void
check_contrast (char *arg)
{
	int val;
	char *end;
	size_t const l = strlen (arg);

	val = strtol (arg, &end, 0);
	if (end - arg < l) {
		fprintf (stderr, _("%s: Format error in \"contrast\" argument. \"contrast\" command deleted.\n"), PROGNAME);
		return;
	}
	if ((val < LOLIMIT_PICT) || (val > HILIMIT_PICT)) {
		fprintf (stderr, _("%s: \"contrast\" argument out of range. \"contrast\" command deleted.\n"), PROGNAME);
		return;
	}
	cmd_contrast += 1;
	arg_contrast = val;
}

void
check_norm (char *arg)
{
	int cmd = 0;

	if (!strcmp (arg, OPTSTR_PAL)) {
		cmd += 1;
		arg_norm = VIDEO_MODE_PAL;
	}
	if (!strcmp (arg, OPTSTR_SECAM)) {
		cmd += 1;
		arg_norm = VIDEO_MODE_SECAM;
	}
	if (!strcmp (arg, OPTSTR_NTSC)) {
		cmd += 1;
		arg_norm = VIDEO_MODE_NTSC;
	}
	if (!cmd) {
		fprintf (stderr, _("%s: Unknown \"norm\" argument. \"norm\" command deleted.\n"), PROGNAME);
		return;
	}
	cmd_norm += 1;
}

void
check_saturation (char *arg)
{
	int val;
	char *end;
	size_t const l = strlen (arg);

	val = strtol (arg, &end, 0);
	if (end - arg < l) {
		fprintf (stderr, _("%s: Format error in \"saturation\" argument. \"saturation\" command deleted.\n"), PROGNAME);
		return;
	}
	if ((val < LOLIMIT_PICT) || (val > HILIMIT_PICT)) {
		fprintf (stderr, _("%s: \"saturation\" argument out of range. \"saturation\" command deleted.\n"), PROGNAME);
		return;
	}
	cmd_saturation += 1;
	arg_saturation = val;
}

void
check_hue (char *arg)
{
	int val;
	char *end;
	size_t const l = strlen (arg);

	val = strtol (arg, &end, 0);
	if (end - arg < l) {
		fprintf (stderr, _("%s: Format error in \"hue\" argument. \"hue\" command deleted.\n"), PROGNAME);
		return;
	}
	if ((val < LOLIMIT_PICT) || (val > HILIMIT_PICT)) {
		fprintf (stderr, _("%s: \"hue\" argument out of range. \"hue\" command deleted.\n"), PROGNAME);
		return;
	}
	cmd_hue += 1;
	arg_hue = val;
}

void
check_whiteness (char *arg)
{
	int val;
	char *end;
	size_t const l = strlen (arg);

	val = strtol (arg, &end, 0);
	if (end - arg < l) {
		fprintf (stderr, _("%s: Format error in \"whiteness\" argument. \"whiteness\" command deleted.\n"), PROGNAME);
		return;
	}
	if ((val < LOLIMIT_PICT) || (val > HILIMIT_PICT)) {
		fprintf (stderr, _("%s: \"whiteness\" argument out of range. \"whiteness\" command deleted.\n"), PROGNAME);
		return;
	}
	cmd_whiteness += 1;
	arg_whiteness = val;
}

void
check_width (char *arg)
{
	int val;
	char *end;
	size_t const l = strlen (arg);

	val = strtol (arg, &end, 0);
	if (end - arg < l) {
		fprintf (stderr, _("%s: Format error in \"width\" argument. \"width\" command deleted.\n"), PROGNAME);
		return;
	}
/* We ought to compare with values returned by VIDIOCGCAP; but device is not */
/* opened yet at this point. */
	if ((val < LOLIMIT_WIDTH) || (val > HILIMIT_WIDTH)) {
		fprintf (stderr, _("%s: \"width\" argument out of range. \"width\" command deleted.\n"), PROGNAME);
		return;
	}
	cmd_width += 1;
	arg_width = val;
}

void
check_height (char *arg)
{
	int val;
	char *end;
	size_t const l = strlen (arg);

	val = strtol (arg, &end, 0);
	if (end - arg < l) {
		fprintf (stderr, _("%s: Format error in \"height\" argument. \"height\" command deleted.\n"), PROGNAME);
		return;
	}
	if ((val < LOLIMIT_HEIGHT) || (val > HILIMIT_HEIGHT)) {
		fprintf (stderr, _("%s: \"height\" argument out of range. \"height\" command deleted.\n"), PROGNAME);
		return;
	}
	cmd_height += 1;
	arg_height = val;
}

void
check_depth (char *arg)
{
	int val;
	char *end;
	size_t const l = strlen (arg);

	val = strtol (arg, &end, 0);
	if (end - arg < l) {
		fprintf (stderr, _("%s: Format error in \"depth\" argument. \"depth\" command deleted.\n"), PROGNAME);
		return;
	}
	if ((val != 8) || (val != 16) || (val != 24) || (val != 32)) {
		fprintf (stderr, _("%s: invalid \"depth\" argument. \"depth\" command deleted.\n"), PROGNAME);
		return;
	}
	cmd_depth += 1;
	arg_depth = val;
}

int
main (int argc, char **argv)
{
   	int c, longindex;
        char device[80];
        const struct option longopts[] = {
           	{ "audio",	required_argument,0,'a' },
                { "brightness",	required_argument,0,'b' },
                { "channel",	required_argument,0,'c' },
                { "device",	required_argument,0,'d' },
		{ "palette",	required_argument,0,'e' },
                { "frequency",	required_argument,0,'f' },
                { "help",	no_argument,0,'h' },
		{ "hiband",	required_argument,0,'i' },
		{ "contrast",	required_argument,0,'k' },
                { "lof",	required_argument,0,'l' },
                { "mute",	required_argument,0,'m' },
		{ "norm",	required_argument,0,'n' },
                { "polarization",	required_argument,0,'p' },
		{ "satellite",	required_argument,0,'q' },
                { "saturation",	required_argument,0,'s' },
                { "transponder",required_argument,0,'t' },
		{ "hue",	required_argument,0,'u' },
                { "volume",	required_argument,0,'v' },
		{ "whiteness",	required_argument,0,'w' },
		{ "width",	required_argument,0,'x' },
                { "height",	required_argument,0,'y' },
		{ "depth",	required_argument,0,'z' },
                { 0, 0, 0, 0 },
        };
        
#ifdef ENABLE_NLS
	setlocale (LC_ALL, "");
	textdomain (PACKAGE);
	bindtextdomain (PACKAGE, LOCALE_DIR);
#endif

        if ((argc == 1) || (argv[1][0] != '-')) {
           	fprintf (stderr, _("%s: No option specified, nothing done.\n"), PROGNAME);
                exit (-1);
        }
        strcpy (device, DEFAULT_DEVICE);
        
        while ((c = getopt_long (argc, argv, "a:b:c:d:e:f:hi:k:l:m:n:p:s:t:u:v:w:x:y:z:?", longopts, &longindex)) != EOF) {
           	switch (c) {
                   	case 'a':
                           	check_audio (optarg);
                           	break;
                        case 'b':
                           	check_brightness (optarg);
                           	break;
                        case 'c':
                           	check_channel (optarg);
                           	break;
                        case 'd':
                           	strcpy (device, optarg);
                           	break;
			case 'e':
				check_palette (optarg);
				break;
                        case 'f':
                           	check_frequency (optarg);
                           	break;
                        case 'i':
                           	check_hiband (optarg);
                           	break;
			case 'k':
				check_contrast (optarg);
				break;
                        case 'l':
                           	check_lof (optarg);
                           	break;
                        case 'm':
                           	check_mute (optarg);
                           	break;
			case 'n':
				check_norm (optarg);
				break;
                        case 'p':
                           	check_polarization (optarg);
                           	break;
			case 'q':
				check_satellite (optarg);
				break;
			case 's':
				check_saturation (optarg);
				break;
                        case 't':
                           	check_transponder (optarg);
                           	break;
			case 'u':
				check_hue (optarg);
				break;
                        case 'v':
                           	check_volume (optarg);
                           	break;
			case 'w':
				check_whiteness (optarg);
				break;
			case 'x':
				check_width (optarg);
				break;
			case 'y':
				check_height (optarg);
				break;
			case 'z':
				check_depth (optarg);
				break;
                   	case 'h':
                        case '?':
                           	usage ();
                                exit (1);
                        default:
                           	fprintf (stderr, _("%s: Unknown command line option.\n"), PROGNAME);
                                usage ();
                                exit (1);
                }
        }

	if (cmd_norm && !cmd_channel) {
		fprintf (stderr, _("%s: \"norm\" but no \"channel\" specified. \"norm\" command deleted.\n"), PROGNAME);
		cmd_norm = 0;
	}
	if (cmd_channel && !cmd_norm) {
		fprintf (stderr, _("%s: \"channel\" but no \"norm\" specified. \"channel\" command deleted.\n"), PROGNAME);
		cmd_channel = 0;
	}
	if (cmd_frequency && cmd_transponder) {
		fprintf (stderr, _("%s: \"frequency\" and \"transponder\" specified together. \"frequency\" command deleted.\n"), PROGNAME);
		cmd_frequency = 0;
	}
	
	if (!cmd_audio && !cmd_brightness && !cmd_channel && !cmd_palette &&
	!cmd_frequency && !cmd_contrast && !cmd_mute && !cmd_norm &&
	!cmd_saturation && !cmd_transponder && !cmd_hue && !cmd_volume &&
	!cmd_whiteness && !cmd_width && !cmd_height && !cmd_depth) {
		fprintf (stderr, _("%s: Nothing done.\n"), PROGNAME);
		exit (1);
	}

	if (cmd_lof && !cmd_frequency)
		fprintf (stderr, _("%s: Warning, \"lof\" option w/o \"frequency\" option has no effect.\n"), PROGNAME);		
	if (cmd_polarization && !cmd_frequency)
		fprintf (stderr, _("%s: Warning, \"polarization\" option w/o \"frequency\" option has no effect.\n"), PROGNAME);
	if (cmd_hiband  && !cmd_frequency)
		fprintf (stderr, _("%s: Warning, \"hiband\" option w/o \"frequency\" option has no effect.\n"), PROGNAME);

        if (open_device (device, &fd))
		exit (-1);

        set_frequency ();
        set_transponder ();

	if (cmd_channel || cmd_norm) {	/* this is actually not an "or"! */
		struct video_channel vc;
		
		if (arg_channel >= capability.channels) {
			fprintf (stderr, _("%s: \"channel\" argument out of range. \"channel\" + \"norm\" commands deleted.\n"), PROGNAME);
			cmd_channel = 0;
			cmd_norm = 0;
		} else {
			vc.channel = arg_channel;
			vc.norm = arg_norm;
			if (-1 == ioctl (fd, VIDIOCSCHAN, &vc)) {
				perror ("VIDIOCSCHAN");
			}
		}
	}
	if (cmd_width || cmd_height) {
		struct video_window vw;
		
		if (cmd_width) {
			if ((arg_width < capability.minwidth) || (arg_width > capability.maxwidth)) {
				fprintf (stderr, _("%s: \"width\" argument out of range. \"width\" command deleted.\n"), PROGNAME);
				cmd_width = 0;
			}
		}
		if (cmd_height) {
			if ((arg_height < capability.minheight) || (arg_height > capability.maxheight)) {
				fprintf (stderr, _("%s: \"height\" argument out of range. \"height\" command deleted.\n"), PROGNAME);
				cmd_height = 0;
			}
		}
		if (-1 == ioctl (fd, VIDIOCGWIN, &vw)) {
			perror ("VIDIOCGWIN");
		} else {
			if (cmd_width)
				vw.width = arg_width;
			if (cmd_height)
				vw.height = arg_height;
			if (-1 == ioctl (fd, VIDIOCSWIN, &vw)) {
				perror ("VIDIOCSWIN");
			}
		}
	}
	if (cmd_brightness || cmd_contrast || cmd_saturation || cmd_hue || cmd_whiteness || cmd_depth || cmd_palette) {
		struct video_picture vp;
		
		if (-1 == ioctl (fd, VIDIOCGPICT, &vp)) {
			perror ("VIDIOCGPICT");
		} else {
			if (cmd_brightness)
				vp.brightness = arg_brightness;
			if (cmd_contrast)
				vp.contrast = arg_contrast;
			if (cmd_saturation)
				vp.colour = arg_saturation;
			if (cmd_hue)
				vp.hue = arg_hue;
			if (cmd_whiteness)
				vp.whiteness = arg_whiteness;
			if (cmd_depth)
				vp.depth = arg_depth;
			if (cmd_palette)
				vp.palette = arg_palette;
			if (-1 == ioctl (fd, VIDIOCSPICT, &vp)) {
				perror ("VIDIOCSPICT");
			}
		}
	}

        if (cmd_audio || cmd_mute || cmd_volume) {
           	struct video_audio va;

	        va.audio = AUDIO_CHANNEL;
                if (-1 == ioctl (fd, VIDIOCGAUDIO, &va)) {
                        perror ("VIDIOCGAUDIO");
                } else {
		        if (cmd_audio)
			        va.mode = arg_audio;
		        if (cmd_mute) {
			        va.flags &= ~VIDEO_AUDIO_MUTE;
			        va.flags |= arg_mute;
		        }
		        if (cmd_volume) {
			        va.volume = arg_volume;
			        va.flags |= VIDEO_AUDIO_VOLUME;	/* really needed? */
		        }
           	        if (-1 == ioctl (fd, VIDIOCSAUDIO, &va)) {
                   	        perror ("VIDIOCSAUDIO");
		        }
	        }
        }

        close_device (fd);

	if (!cmd_audio && !cmd_brightness && !cmd_channel && !cmd_palette &&
	!cmd_frequency && !cmd_contrast && !cmd_mute && !cmd_norm &&
	!cmd_saturation && !cmd_transponder && !cmd_hue && !cmd_volume &&
	!cmd_whiteness && !cmd_width && !cmd_height && !cmd_depth) {
		fprintf (stderr, _("%s: Nothing done.\n"), PROGNAME);
		exit (1);
	}

	exit (0);
}
