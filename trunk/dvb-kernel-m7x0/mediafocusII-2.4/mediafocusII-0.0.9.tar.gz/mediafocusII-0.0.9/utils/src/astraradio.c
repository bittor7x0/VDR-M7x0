/*  astraradio.c - radio application (with "desktop")
   			for TechniSat MediafocusII driver

    Copyright (C) 2000  Rolf Siebrecht

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <ncurses.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <syslog.h>
#include <sys/ioctl.h>

#include <linux/videodev.h>
#include "../../linux/videodev_priv.h"

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#ifdef ENABLE_NLS
#include <libintl.h>
#define _(String)		gettext (String)
#define gettext_noop(String)	(String)
#define N_(String)		gettext_noop (String)
#else
#define _(String)		(String)
#define N_(String)		(String)
#endif

/* #define LOG		1 */
/* #define ADRDATA	1 */

/* ------------------ V4L Definitions -------------------- */
#define DEVICE "/dev/radio"
#define INTERFACE_NAME "TechniSat MediaFocusII Radio"
#define AUDIO_CHANNEL 0

int fd;

/* ----------------- MP2 File Definitions ---------------- */
#define F_PREFIX "ADR"
#define F_SUFFIX ".mp2"

FILE *mp2file;

/* ------------- Screen Attribute Definitions ------------ */
#define CURSOR_INVISIBLE 0

#define WHITE_ON_BLACK 0
#define WHITE_ON_BLUE 1
#define BLACK_ON_WHITE 2
#define BLUE_ON_WHITE 3
#define BLACK_ON_YELLOW 4
#define BLUE_ON_YELLOW 5
#define WHITE_ON_RED 6

#define NORMVIDEO 0
#define HIGHVIDEO 1

int ncurses_has_colors;

/* ------------------ Window Definitions ----------------- */
#define NUM_OF_WINDOWS 10

/* field 0 */
WINDOW *channelwin;
#define CHANNELWIN_COLUMN 10
#define CHANNELWIN_WIDTH 15
#define CHANNELWIN_ROW 3
#define CHANNELWIN_HEIGHT 3

/* field 1 */
WINDOW *carrierwin;
#define CARRIERWIN_COLUMN 10
#define CARRIERWIN_WIDTH 15
#define CARRIERWIN_ROW 8
#define CARRIERWIN_HEIGHT 5

/* field 2 ("Mono-L" in ADR mode; invisible else) */
WINDOW *monowin;
#define MONOWIN_COLUMN 10
#define MONOWIN_WIDTH 15
#define MONOWIN_ROW 13
#define MONOWIN_HEIGHT 1

/* field 3 ("Mono-R" in ADR mode; "Stereo" else) */
WINDOW *stereowin;
#define STEREOWIN_COLUMN 10
#define STEREOWIN_WIDTH 15
#define STEREOWIN_ROW 15
#define STEREOWIN_HEIGHT 1

/* field 4 */
WINDOW *ADRwin;
#define ADRWIN_COLUMN 10
#define ADRWIN_WIDTH 15
#define ADRWIN_ROW 17
#define ADRWIN_HEIGHT 1

/* field 5 */
WINDOW *mp2win;
#define MP2WIN_COLUMN 10
#define MP2WIN_WIDTH 15
#define MP2WIN_ROW 19
#define MP2WIN_HEIGHT 1

/* field 6 */
WINDOW *volumewin;
#define VOLUMEWIN_COLUMN 50
#define VOLUMEWIN_WIDTH 15
#define VOLUMEWIN_ROW 3
#define VOLUMEWIN_HEIGHT 3

/* field 7 */
WINDOW *treblewin;
#define TREBLEWIN_COLUMN 50
#define TREBLEWIN_WIDTH 15
#define TREBLEWIN_ROW 8
#define TREBLEWIN_HEIGHT 3

/* field 8 */
WINDOW *basswin;
#define BASSWIN_COLUMN 50
#define BASSWIN_WIDTH 15
#define BASSWIN_ROW 13
#define BASSWIN_HEIGHT 3

/* field 9 */
WINDOW *mutewin;
#define MUTEWIN_COLUMN 50
#define MUTEWIN_WIDTH 15
#define MUTEWIN_ROW 17
#define MUTEWIN_HEIGHT 1

WINDOW *adrdatawin;
#define ADRDATAWIN_COLUMN 3
#define ADRDATAWIN_WIDTH 74
#define ADRDATAWIN_ROW LINES-4
#define ADRDATAWIN_HEIGHT 3

WINDOW *errorwin;
#define ERRORWIN_COLUMN 5
#define ERRORWIN_WIDTH 70
#define ERRORWIN_ROW 9
#define ERRORWIN_HEIGHT 4

/* ------------------ Tuning Definitions ----------------- */
#undef	HPOL
#undef	VPOL
#undef	HIBAND

#define TF		(1000 * 0x1000)
#define	LOF_LO		9750000		/* low Ku-Band local oscillator frequency in MHz */
#define LOF_HI		10600000	/* high Ku-Band local oscillator frequency in MHz */
#define HIBAND		1 		/* transponder/sat. is in high Ku-Band 	*/
#define VPOL 		2 		/* vertical polarity	*/
#define HPOL		0 		/* horizontal polarity	*/

struct CHANNEL {
   	char *name;
        int freq;
};

const struct CHANNEL channels[] = {
   	{ "RTL 2",	(11214000 - LOF_LO) + ((HPOL)*TF) },	/* Astra-1F  19.2�E, Tr. 01 */
        { "RTL",	(11229000 - LOF_LO) + ((VPOL)*TF) },	/* Astra-1F  19.2�E, Tr. 02 */
        { "RTL Shop",	(11243750 - LOF_LO) + ((HPOL)*TF) },	/* Astra-1A  19.2�E, Tr. 03 */
        { "Eurosport",	(11258500 - LOF_LO) + ((VPOL)*TF) },	/* Astra-1C  19.2�E, Tr. 04 */
        { "Vox",	(11273250 - LOF_LO) + ((HPOL)*TF) },	/* Astra-1F  19.2�E, Tr. 05 */
        { "Sat.1",	(11288000 - LOF_LO) + ((VPOL)*TF) },	/* Astra-1F  19.2�E, Tr. 06 */
        { "VIVA Zwei",	(11302750 - LOF_LO) + ((HPOL)*TF) },	/* Astra-1A  19.2�E, Tr. 07 */
        { "(??)",	(11317500 - LOF_LO) + ((VPOL)*TF) },	/* Astra-1A  19.2�E, Tr. 08 */
        { "Kabel 1",	(11332250 - LOF_LO) + ((HPOL)*TF) },	/* Astra-1F  19.2�E, Tr. 09 */
        { "3 Sat",	(11347000 - LOF_LO) + ((VPOL)*TF) },	/* Astra-1F  19.2�E, Tr. 10 */
        { "Bloomberg DE",(11361750- LOF_LO) + ((HPOL)*TF) },	/* Astra-1A  19.2�E, Tr. 11 */
        { "(??)",	(11376500 - LOF_LO) + ((VPOL)*TF) },	/* Astra-1A  19.2�E, Tr. 12 */
        { "Super RTL",	(11391250 - LOF_LO) + ((HPOL)*TF) },	/* Astra-1F  19.2�E, Tr. 13 */
        { "Pro Sieben",	(11406000 - LOF_LO) + ((VPOL)*TF) },	/* Astra-1F  19.2�E, Tr. 14 */
        { "MTV 2 DE",	(11420750 - LOF_LO) + ((HPOL)*TF) },	/* Astra-1C  19.2�E, Tr. 15 */
        { "Fox News",	(11435500 - LOF_LO) + ((VPOL)*TF) },	/* Astra-1A  19.2�E, Tr. 16 */
        { "Premiere",	(11464250 - LOF_LO) + ((HPOL)*TF) },	/* Astra-1B  19.2�E, Tr. 17 */
        { "(??)",	(11479000 - LOF_LO) + ((VPOL)*TF) },	/* Astra-1B  19.2�E, Tr. 18 */
        { "ARD",	(11493750 - LOF_LO) + ((HPOL)*TF) },	/* Astra-1B  19.2�E, Tr. 19 */
        { "(??)",	(11508500- LOF_LO) + ((VPOL)*TF) },	/* Astra-1B  19.2�E, Tr. 20 */
        { "DSF",	(11523250 - LOF_LO) + ((HPOL)*TF) },	/* Astra-1B  19.2�E, Tr. 21 */
        { "(??)",	(11538000 - LOF_LO) + ((VPOL)*TF) },	/* Astra-1B  19.2�E, Tr. 22 */
        { "(??)",	(11552750 - LOF_LO) + ((HPOL)*TF) },	/* Astra-1B  19.2�E, Tr. 23 */
        { "Bloomberg/B1",(11567500- LOF_LO) + ((VPOL)*TF) },	/* Astra-1B  19.2�E, Tr. 24 */
        { "Nord 3",	(11582250 - LOF_LO) + ((HPOL)*TF) },	/* Astra-1B  19.2�E, Tr. 25 */
        { "(??)",	(11597000 - LOF_LO) + ((VPOL)*TF) },	/* Astra-1E  19.2�E, Tr. 26 */
        { "MTV DE",	(11612000 - LOF_LO) + ((HPOL)*TF) },	/* Astra-1B  19.2�E, Tr. 27 */
        { "CNN",	(11626500 - LOF_LO) + ((VPOL)*TF) },	/* Astra-1B  19.2�E, Tr. 28 */
        { "n-tv",	(11641250 - LOF_LO) + ((HPOL)*TF) },	/* Astra-1B  19.2�E, Tr. 29 */
        { "ORB",	(11656000 - LOF_LO) + ((VPOL)*TF) },	/* Astra-1B  19.2�E, Tr. 30 */
        { "(??)",	(11671000 - LOF_LO) + ((HPOL)*TF) },	/* Astra-1B  19.2�E, Tr. 31 */
        { "BR alpha",	(11686000 - LOF_LO) + ((VPOL)*TF) },	/* Astra-1B  19.2�E, Tr. 32 */
        { "ZDF",	(10964250 - LOF_LO) + ((HPOL)*TF) },	/* Astra-1C  19.2�E, Tr. 33 */
        { "(??)",	(10979000 - LOF_LO) + ((VPOL)*TF) },	/* Astra-1C  19.2�E, Tr. 34 */
        { "(??)",	(10993750 - LOF_LO) + ((HPOL)*TF) },	/* Astra-1C  19.2�E, Tr. 35 */
        { "Phoenix",	(11008500 - LOF_LO) + ((VPOL)*TF) },	/* Astra-1C  19.2�E, Tr. 36 */
        { "B.TV",	(11023250 - LOF_LO) + ((HPOL)*TF) },	/* Astra-1C  19.2�E, Tr. 37 */
        { "(??)",	(11038000 - LOF_LO) + ((VPOL)*TF) },	/* Astra-1C  19.2�E, Tr. 38 */
        { "West 3",	(11052750 - LOF_LO) + ((HPOL)*TF) },	/* Astra-1C  19.2�E, Tr. 39 */
        { "Hessen 3",	(11067500 - LOF_LO) + ((VPOL)*TF) },	/* Astra-1C  19.2�E, Tr. 40 */
        { "(??)",	(11082250 - LOF_LO) + ((HPOL)*TF) },	/* Astra-1C  19.2�E, Tr. 41 */
        { "(??)",	(11097000 - LOF_LO) + ((VPOL)*TF) },	/* Astra-1C  19.2�E, Tr. 42 */
        { "MDR",	(11111750 - LOF_LO) + ((HPOL)*TF) },	/* Astra-1C  19.2�E, Tr. 43 */
        { "Viva",	(11126500 - LOF_LO) + ((VPOL)*TF) },	/* Astra-1C  19.2�E, Tr. 44 */
        { "Bayern 3",	(11141250 - LOF_LO) + ((HPOL)*TF) },	/* Astra-1C  19.2�E, Tr. 45 */
        { "(??)",	(11156000 - LOF_LO) + ((VPOL)*TF) },	/* Astra-1C  19.2�E, Tr. 46 */
        { "(??)",	(11170750 - LOF_LO) + ((HPOL)*TF) },	/* Astra-1C  19.2�E, Tr. 47 */
	{ "S�dwest3 BW",(11185500 - LOF_LO) + ((VPOL)*TF) },	/* Astra-1C  19.2�E, Tr. 48 */
        { "KI.KA/arte",	(10714250 - LOF_LO) + ((HPOL)*TF) },	/* Astra-1E  19.2�E, Tr. 49 */
        { "CNBC",	(10729000 - LOF_LO) + ((VPOL)*TF) },	/* Astra-1E  19.2�E, Tr. 50 */
        { "TV PULS",	(10743750 - LOF_LO) + ((HPOL)*TF) },	/* Astra-1E  19.2�E, Tr. 51 */
        { "QVC DE",	(10758500 - LOF_LO) + ((VPOL)*TF) },	/* Astra-1E  19.2�E, Tr. 52 */
        { "(??)",	(10773000 - LOF_LO) + ((HPOL)*TF) },	/* Astra-1E  19.2�E, Tr. 53 */
        { "(digital)",	(10788000 - LOF_LO) + ((VPOL)*TF) },	/* Astra-1E  19.2�E, Tr. 54 */
        { "N 24",	(10802750 - LOF_LO) + ((HPOL)*TF) },	/* Astra-1E  19.2�E, Tr. 55 */
        { "Travel Shop",(10817500 - LOF_LO) + ((VPOL)*TF) },	/* Astra-1E  19.2�E, Tr. 56 */
        { "(??)",	(10832250 - LOF_LO) + ((HPOL)*TF) },	/* Astra-1E  19.2�E, Tr. 57 */
        { "(??)",	(10847000 - LOF_LO) + ((VPOL)*TF) },	/* Astra-1E  19.2�E, Tr. 58 */
        { "(??)",	(10862000 - LOF_LO) + ((HPOL)*TF) },	/* Astra  19.2�E, Tr. 59 */
        { "(digital)",	(10877000 - LOF_LO) + ((VPOL)*TF) },	/* Astra  19.2�E, Tr. 60 */
        { "S�dwest3 RP",(10891000 - LOF_LO) + ((HPOL)*TF) },	/* Astra-1E  19.2�E, Tr. 61 */
        { "HSE",	(10906000 - LOF_LO) + ((VPOL)*TF) },	/* Astra-1E  19.2�E, Tr. 62 */
        { "Channel 5",	(10920750 - LOF_LO) + ((HPOL)*TF) },	/* Astra-1E  19.2�E, Tr. 63 */
        { "9 Live",	(10935500 - LOF_LO) + ((VPOL)*TF) },	/* Astra-1E  19.2�E, Tr. 64 */
};

#define NR_OF_CHANNELS sizeof (channels) / sizeof (channels[0])

#define LO_CHAN_FREQ(x) ((((x * 16) / 1000) & 0xffff) / 16 + LOF_LO / 1000)

/* ------------------ Global Variables ------------------- */
int channel_nr;
#define INITIAL_CHANNEL_NUMBER	0
int channel_freq;
char *channel_name;
long int v4l_freq;

int mode;
#define INITIAL_MODE	VIDEO_SOUND_STEREO
int l_carrier;
#define	INITIAL_LCARRIER_FREQ	7020
int r_carrier;
#define INITIAL_RCARRIER_FREQ	7200
int volume;
#define INITIAL_VOLUME_LEVEL	80
int treble;
#define INITIAL_TREBLE_LEVEL	0
int bass;
#define INITIAL_BASS_LEVEL	0
int mute;
#define INITIAL_MUTE_STATE	0
int mp2record = 0;

#ifdef ADRDATA
#include "adrdata.c"
#endif 
/* ------------------------------------------------------- */
        
void init_ncurses ()
{
   	initscr ();
        noecho ();
        nonl ();
/*        refresh (); */
        cbreak ();
#ifdef ADRDATA
        nodelay (stdscr, TRUE);
#else
        nodelay (stdscr, FALSE);
#endif
        keypad (stdscr, TRUE);
        curs_set (CURSOR_INVISIBLE);
        
        channelwin = newwin (CHANNELWIN_HEIGHT, CHANNELWIN_WIDTH, CHANNELWIN_ROW, CHANNELWIN_COLUMN);
	carrierwin = newwin (CARRIERWIN_HEIGHT, CARRIERWIN_WIDTH, CARRIERWIN_ROW, CARRIERWIN_COLUMN);
        monowin = newwin (MONOWIN_HEIGHT, MONOWIN_WIDTH, MONOWIN_ROW, MONOWIN_COLUMN);
	stereowin = newwin (STEREOWIN_HEIGHT, STEREOWIN_WIDTH, STEREOWIN_ROW, STEREOWIN_COLUMN);
	ADRwin = newwin (ADRWIN_HEIGHT, ADRWIN_WIDTH, ADRWIN_ROW, ADRWIN_COLUMN);
	mp2win = newwin (MP2WIN_HEIGHT, MP2WIN_WIDTH, MP2WIN_ROW, MP2WIN_COLUMN);
	volumewin = newwin (VOLUMEWIN_HEIGHT, VOLUMEWIN_WIDTH, VOLUMEWIN_ROW, VOLUMEWIN_COLUMN);
	treblewin = newwin (TREBLEWIN_HEIGHT, TREBLEWIN_WIDTH, TREBLEWIN_ROW, TREBLEWIN_COLUMN);
	basswin = newwin (BASSWIN_HEIGHT, BASSWIN_WIDTH, BASSWIN_ROW, BASSWIN_COLUMN);
	mutewin = newwin (MUTEWIN_HEIGHT, MUTEWIN_WIDTH, MUTEWIN_ROW, MUTEWIN_COLUMN);
#ifdef ADRDATA_WORKING
	adrdatawin = newwin (ADRDATAWIN_HEIGHT, ADRDATAWIN_WIDTH, ADRDATAWIN_ROW, ADRDATAWIN_COLUMN);
#endif
        if ((ncurses_has_colors = has_colors ()) == TRUE)
        {
        	start_color ();
		init_pair (WHITE_ON_BLACK, COLOR_WHITE, COLOR_BLACK);
                init_pair (WHITE_ON_BLUE, COLOR_WHITE, COLOR_BLUE);
                init_pair (BLACK_ON_WHITE, COLOR_BLACK, COLOR_WHITE);
		init_pair (BLUE_ON_WHITE, COLOR_BLUE, COLOR_WHITE);
		init_pair (BLACK_ON_YELLOW, COLOR_BLACK, COLOR_YELLOW);
		init_pair (BLUE_ON_YELLOW, COLOR_BLUE, COLOR_YELLOW);
                init_pair (WHITE_ON_RED, COLOR_WHITE, COLOR_RED);
        }
}

void exit_ncurses ()
{
   	clear ();
        if (ncurses_has_colors == TRUE)
        {
        	attron (COLOR_PAIR (WHITE_ON_BLACK));
                attroff (A_BOLD);
        }
        refresh ();
        endwin ();
}

void draw_channelwin (int attr)
{
	int line, col;
	char *s;
	char tp_buf[5] = { "    " };
        char frq_buf[8] = { "       " };

#ifdef LOG
	syslog (LOG_INFO, "==> draw_channelwin ()\n");
#endif
	if (ncurses_has_colors == TRUE) {
           	if (attr)
                   	wattron (channelwin, COLOR_PAIR (BLACK_ON_YELLOW));
                else
                   	wattron (channelwin, COLOR_PAIR (BLACK_ON_WHITE));
	}
	for (line = 0; line < CHANNELWIN_HEIGHT; line++) {
		wmove (channelwin, line, 0);
		for (col = 0; col < CHANNELWIN_WIDTH; col++)
			waddch (channelwin, 32);
	}
	s = _("Transponder");
        wmove (channelwin, 0, CHANNELWIN_WIDTH / 2 - strlen (s) / 2 - 2);
        waddstr (channelwin, s);
        wmove (channelwin, 1, 10);
        waddstr (channelwin, "GHz");
	if (ncurses_has_colors == TRUE) {
           	if (attr) {
                   	wattroff (channelwin, COLOR_PAIR (BLACK_ON_YELLOW));
                        wattron (channelwin, COLOR_PAIR (BLUE_ON_YELLOW));
                } else {
                   	wattroff (channelwin, COLOR_PAIR (BLACK_ON_WHITE));
                        wattron (channelwin, COLOR_PAIR (BLUE_ON_WHITE));
                }
	}
	sprintf (tp_buf, "A%02d", channel_nr+1);
	wmove (channelwin, 0, 12);
	waddstr (channelwin, tp_buf);
        sprintf (frq_buf, "%06.3f", (float) channel_freq / 1000.0);
        wmove (channelwin, 1, 3);
        waddstr (channelwin, frq_buf);
        wmove (channelwin, 2, 7 - (strlen (channel_name) >> 1));
	waddstr (channelwin, channel_name);
        if (ncurses_has_colors == TRUE) {
           	if (attr)
                   	wattroff (channelwin, COLOR_PAIR (BLUE_ON_YELLOW));
                else
                   	wattroff (channelwin, COLOR_PAIR (BLUE_ON_WHITE));
        }
	wrefresh (channelwin);
#ifdef LOG
	syslog (LOG_INFO, "<== draw_channelwin ()\n");
#endif
}

void draw_carrierwin (int attr)
{
	int line, col;
	char *s;
        char buf[6] = { "     " };

        /* clear/fill window with background color */
	if (ncurses_has_colors == TRUE) {
           	if (attr)
                   	wattron (carrierwin, COLOR_PAIR (BLACK_ON_YELLOW));
                else
                   	wattron (carrierwin, COLOR_PAIR (BLACK_ON_WHITE));
	}
	for (line = 0; line < CARRIERWIN_HEIGHT; line++) {
		wmove (carrierwin, line, 0);
		for (col = 0; col < CARRIERWIN_WIDTH; col++)
                   	waddch (carrierwin, 32);
	}
        /* write with plain color */
	s = _("Audio Carrier");
        wmove (carrierwin, 0, CARRIERWIN_WIDTH / 2 - strlen (s) / 2 + 1);
        waddstr (carrierwin, s);
        if (mode == VIDEO_SOUND_STEREO) {
	        wmove (carrierwin, 1, 3);
        	waddstr (carrierwin, "L      MHz");
        	wmove (carrierwin, 3, 3);
        	waddstr (carrierwin, "R      MHz");
	} else {
		wmove (carrierwin, 1, 3);
		waddstr (carrierwin, "       MHz");
	}
        
        /* write with emphasized color */
	if (ncurses_has_colors == TRUE) {
           	if (attr) {
                   	wattroff (carrierwin, COLOR_PAIR (BLACK_ON_YELLOW));
                        wattron (carrierwin, COLOR_PAIR (BLUE_ON_YELLOW));
                } else {
                   	wattroff (carrierwin, COLOR_PAIR (BLACK_ON_WHITE));
                        wattron (carrierwin, COLOR_PAIR (BLUE_ON_WHITE));
                }
	}
        sprintf (buf, "%4.2f", (float) l_carrier / 1000.0);
        wmove (carrierwin, 1, 5);
        waddstr (carrierwin, buf);
        sprintf (buf, "%4.2f", (float) r_carrier / 1000.0);
	if (mode == VIDEO_SOUND_STEREO) {
	        wmove (carrierwin, 3, 5);
        	waddstr (carrierwin, buf);
	}
        if (ncurses_has_colors == TRUE) {
           	if (attr)
                   	wattroff (carrierwin, COLOR_PAIR (BLUE_ON_YELLOW));
                else
                   	wattroff (carrierwin, COLOR_PAIR (BLUE_ON_WHITE));
        }
        /* make part of window invisible if required */
	if (mode != VIDEO_SOUND_STEREO) {
		wattron (carrierwin, COLOR_PAIR (WHITE_ON_BLUE));
		for (line = 3; line < CARRIERWIN_HEIGHT; line++) {
			wmove (carrierwin, line, 0);
			for (col = 0; col < CARRIERWIN_WIDTH; col++)
				waddch (carrierwin, 32);		
		}
		wattroff (carrierwin, COLOR_PAIR (WHITE_ON_BLUE));
	}
	wrefresh (carrierwin);
}

void draw_monowin (int attr)
{
   	int line, col;

        /* make window invisible in Non-ADR modes */
	if ((mode == VIDEO_SOUND_STEREO) || (mode == VIDEO_SOUND_MONO)) {
		wattron (monowin, COLOR_PAIR (WHITE_ON_BLUE));
		for (line = 0; line < MONOWIN_HEIGHT; line++) {
			wmove (monowin, line, 0);
			for (col = 0; col < MONOWIN_WIDTH; col++)
				waddch (monowin, 32);		
		}
		wattroff (monowin, COLOR_PAIR (WHITE_ON_BLUE));
                wrefresh (monowin);
                return;
        }
	if (ncurses_has_colors == TRUE) {
           	if (attr)
                   	wattron (monowin, COLOR_PAIR (BLACK_ON_YELLOW));
                else
                   	wattron (monowin, COLOR_PAIR (BLACK_ON_WHITE));
	}
	for (line = 0; line < MONOWIN_HEIGHT; line++) {
		wmove (monowin, line, 0);
		for (col = 0; col < MONOWIN_WIDTH; col++)
			waddch (monowin, 32);
	}
	wmove (monowin, 0, 1);
	waddstr (monowin, "[ ] Mono-L");
	if (ncurses_has_colors == TRUE) {
           	if (attr) {
                   	wattroff (monowin, COLOR_PAIR (BLACK_ON_YELLOW));
                        wattron (monowin, COLOR_PAIR (BLUE_ON_YELLOW));
                } else {
                   	wattroff (monowin, COLOR_PAIR (BLACK_ON_WHITE));
                        wattron (monowin, COLOR_PAIR (BLUE_ON_WHITE));
                }
	}
        wmove (monowin, 0, 2);
        if (mode == VIDEO_SOUND_ADR_L)
           	waddch (monowin, ACS_BULLET);
        if (ncurses_has_colors == TRUE) {
           	if (attr)
                   	wattroff (monowin, COLOR_PAIR (BLUE_ON_YELLOW));
                else
                   	wattroff (monowin, COLOR_PAIR (BLUE_ON_WHITE));
        }
	wrefresh (monowin);
}
        
void draw_stereowin (int attr)
{
	int line, col;

	if (ncurses_has_colors == TRUE) {
           	if (attr)
                   	wattron (stereowin, COLOR_PAIR (BLACK_ON_YELLOW));
                else
                   	wattron (stereowin, COLOR_PAIR (BLACK_ON_WHITE));
	}
	for (line = 0; line < STEREOWIN_HEIGHT; line++) {
		wmove (stereowin, line, 0);
		for (col = 0; col < STEREOWIN_WIDTH; col++)
			waddch (stereowin, 32);
	}
	wmove (stereowin, 0, 1);
        if ((mode == VIDEO_SOUND_STEREO) || (mode == VIDEO_SOUND_MONO))
           	waddstr (stereowin, "[ ] Stereo");
        else
           	waddstr (stereowin, "[ ] Mono-R");
	if (ncurses_has_colors == TRUE) {
           	if (attr) {
                   	wattroff (stereowin, COLOR_PAIR (BLACK_ON_YELLOW));
                        wattron (stereowin, COLOR_PAIR (BLUE_ON_YELLOW));
                } else {
                   	wattroff (stereowin, COLOR_PAIR (BLACK_ON_WHITE));
                        wattron (stereowin, COLOR_PAIR (BLUE_ON_WHITE));
                }
	}
        wmove (stereowin, 0, 2);
        if ((mode == VIDEO_SOUND_STEREO) || (mode == VIDEO_SOUND_ADR_R))
           	waddch (stereowin, ACS_BULLET);
        if (ncurses_has_colors == TRUE) {
           	if (attr)
                   	wattroff (stereowin, COLOR_PAIR (BLUE_ON_YELLOW));
                else
                   	wattroff (stereowin, COLOR_PAIR (BLUE_ON_WHITE));
        }
	wrefresh (stereowin);
}

void draw_adrwin (int attr)
{
	int line, col;

	if (ncurses_has_colors == TRUE) {
           	if (attr)
                   	wattron (ADRwin, COLOR_PAIR (BLACK_ON_YELLOW));
                else
                   	wattron (ADRwin, COLOR_PAIR (BLACK_ON_WHITE));
	}
	for (line = 0; line < ADRWIN_HEIGHT; line++) {
		wmove (ADRwin, line, 0);
		for (col = 0; col < ADRWIN_WIDTH; col++)
			waddch (ADRwin, 32);
	}
	wmove (ADRwin, 0, 1);
	waddstr (ADRwin, "[ ] ADR");
	if (ncurses_has_colors == TRUE) {
           	if (attr) {
                   	wattroff (ADRwin, COLOR_PAIR (BLACK_ON_YELLOW));
                        wattron (ADRwin, COLOR_PAIR (BLUE_ON_YELLOW));
                } else {
                   	wattroff (ADRwin, COLOR_PAIR (BLACK_ON_WHITE));
                        wattron (ADRwin, COLOR_PAIR(BLUE_ON_WHITE));
                }
	}
        wmove (ADRwin, 0, 2);
        if ((mode == VIDEO_SOUND_ADR) || (mode == VIDEO_SOUND_ADR_L) || (mode == VIDEO_SOUND_ADR_R))
           	waddch (ADRwin, ACS_BULLET);
        if (ncurses_has_colors == TRUE) {
           	if (attr)
                   	wattroff (ADRwin, COLOR_PAIR (BLUE_ON_YELLOW));
                else
                   	wattroff (ADRwin, COLOR_PAIR (BLUE_ON_WHITE));
        }
	wrefresh (ADRwin);
}

void draw_mp2win (int attr)
{
	int line, col;
        
        /* make window invisible in Non-ADR modes */
	if ((mode == VIDEO_SOUND_STEREO) || (mode == VIDEO_SOUND_MONO)) {
		wattron (mp2win, COLOR_PAIR (WHITE_ON_BLUE));
		for (line = 0; line < MP2WIN_HEIGHT; line++) {
			wmove (mp2win, line, 0);
			for (col = 0; col < MP2WIN_WIDTH; col++)
				waddch (mp2win, 32);		
		}
		wattroff (mp2win, COLOR_PAIR (WHITE_ON_BLUE));
                wrefresh (mp2win);
                return;
        }
	if (ncurses_has_colors == TRUE) {
           	if (attr)
                   	wattron (mp2win, COLOR_PAIR (BLACK_ON_YELLOW));
                else
                   	wattron (mp2win, COLOR_PAIR (BLACK_ON_WHITE));
	}
	for (line = 0; line < MP2WIN_HEIGHT; line++) {
		wmove (mp2win, line, 0);
		for (col = 0; col < MP2WIN_WIDTH; col++)
			waddch (mp2win, 32);
	}
	wmove (mp2win, 0, 1);
	waddstr (mp2win, _("[ ] MP2 Rec."));
	if (ncurses_has_colors == TRUE) {
           	if (attr) {
                   	wattroff (mp2win, COLOR_PAIR (BLACK_ON_YELLOW));
                        wattron (mp2win, COLOR_PAIR (BLUE_ON_YELLOW));
                } else {
                   	wattroff (mp2win, COLOR_PAIR (BLACK_ON_WHITE));
                        wattron (mp2win, COLOR_PAIR (BLUE_ON_WHITE));
                }
	}
        wmove (mp2win, 0, 2);
	if (mp2record)
        	waddch (mp2win, ACS_BULLET);
        if (ncurses_has_colors == TRUE) {
           	if (attr)
                   	wattroff (mp2win, COLOR_PAIR (BLUE_ON_YELLOW));
                else
                   	wattroff (mp2win, COLOR_PAIR (BLUE_ON_WHITE));
        }
	wrefresh (mp2win);
}

void draw_volumewin (int vol, int attr)
{
	int line, col;
	char *s;
        char buf[5] = { "    " };

	if (ncurses_has_colors == TRUE) {
           	if (attr)
                   	wattron (volumewin, COLOR_PAIR (BLACK_ON_YELLOW));
                else
                   	wattron (volumewin, COLOR_PAIR (BLACK_ON_WHITE));
	}
	for (line = 0; line < VOLUMEWIN_HEIGHT; line++) {
		wmove (volumewin, line, 0);
		for (col = 0; col < VOLUMEWIN_WIDTH; col++)
			waddch (volumewin, 32);
	}
	s = _("Volume");
	wmove (volumewin, 0, VOLUMEWIN_WIDTH / 2 - strlen (s) / 2 + 1);
	waddstr (volumewin, s);
	wmove (volumewin, 1, 10);
	waddstr (volumewin, "%");
	if (ncurses_has_colors == TRUE) {
           	if (attr) {
                   	wattroff (volumewin, COLOR_PAIR (BLACK_ON_YELLOW));
                        wattron (volumewin, COLOR_PAIR (BLUE_ON_YELLOW));
                } else {
                   	wattroff (volumewin, COLOR_PAIR (BLACK_ON_WHITE));
                        wattron (volumewin, COLOR_PAIR (BLUE_ON_WHITE));
                }
	}
        if (vol < 0) vol = 0;
        if (vol > 100) vol = 100;
        sprintf (buf, "%03d", vol);
        wmove (volumewin, 1, 6);
        waddstr (volumewin, buf);
        if (ncurses_has_colors == TRUE) {
           	if (attr)
                   	wattroff (volumewin, COLOR_PAIR (BLUE_ON_YELLOW));
                else
                   	wattroff (volumewin, COLOR_PAIR (BLUE_ON_WHITE));
        }
	wrefresh (volumewin);
}

void draw_treblewin (int t_level, int attr)
{
	int line, col;
	char *s;
        char buf[5] = { "    " };

	if (ncurses_has_colors == TRUE) {
           	if (attr)
                   	wattron (treblewin, COLOR_PAIR (BLACK_ON_YELLOW));
                else
                   	wattron (treblewin, COLOR_PAIR (BLACK_ON_WHITE));
	}
	for (line = 0; line < TREBLEWIN_HEIGHT; line++) {
		wmove (treblewin, line, 0);
		for (col = 0; col < TREBLEWIN_WIDTH; col++)
			waddch (treblewin, 32);
	}
	s = _("Treble");
	wmove (treblewin, 0, TREBLEWIN_WIDTH / 2 - strlen (s) / 2);
	waddstr (treblewin, s);
	wmove (treblewin, 1, 10);
	waddstr (treblewin, "%");
	if (ncurses_has_colors == TRUE) {
           	if (attr) {
                   	wattroff (treblewin, COLOR_PAIR (BLACK_ON_YELLOW));
                        wattron (treblewin, COLOR_PAIR (BLUE_ON_YELLOW));
                } else {
                   	wattroff (treblewin, COLOR_PAIR (BLACK_ON_WHITE));
                        wattron (treblewin, COLOR_PAIR (BLUE_ON_WHITE));
                }
	}
        if (t_level < -100) t_level = -100;
        if (t_level > 100) t_level = 100;
        sprintf (buf, "%+04d", t_level);
        wmove (treblewin, 1, 5);
        waddstr (treblewin, buf);
        if (ncurses_has_colors == TRUE) {
           	if (attr)
                   	wattroff (treblewin, COLOR_PAIR (BLUE_ON_YELLOW));
                else
                   	wattroff (treblewin, COLOR_PAIR (BLUE_ON_WHITE));
        }
	wrefresh (treblewin);
}

void draw_basswin (int b_level, int attr)
{
	int line, col;
	char *s;
        char buf[5] = { "    " };

	if (ncurses_has_colors == TRUE) {
           	if (attr)
                   	wattron (basswin, COLOR_PAIR (BLACK_ON_YELLOW));
                else
                   	wattron (basswin, COLOR_PAIR (BLACK_ON_WHITE));
	}
	for (line = 0; line < BASSWIN_HEIGHT; line++) {
		wmove (basswin, line, 0);
		for (col = 0; col < BASSWIN_WIDTH; col++)
			waddch (basswin, 32);
	}
	s = _("Bass");
	wmove (basswin, 0, BASSWIN_WIDTH / 2 - strlen (s) / 2);
	waddstr (basswin, s);
	wmove (basswin, 1, 10);
	waddstr (basswin, "%");
	if (ncurses_has_colors == TRUE) {
           	if (attr) {
                   	wattroff (basswin, COLOR_PAIR (BLACK_ON_YELLOW));
                        wattron (basswin, COLOR_PAIR (BLUE_ON_YELLOW));
                } else {
                   	wattroff (basswin, COLOR_PAIR (BLACK_ON_WHITE));
                        wattron (basswin, COLOR_PAIR (BLUE_ON_WHITE));
                }
	}
        if (b_level < -100) b_level = -100;
        if (b_level > 100) b_level = 100;
        sprintf (buf, "%+04d", b_level);
        wmove (basswin, 1, 5);
        waddstr (basswin, buf);
        if (ncurses_has_colors == TRUE) {
           	if (attr)
                   	wattroff (basswin, COLOR_PAIR (BLUE_ON_YELLOW));
                else
                   	wattroff (basswin, COLOR_PAIR (BLUE_ON_WHITE));
        }
	wrefresh (basswin);
}

void draw_mutewin (int attr)
{
	int line, col;

#ifdef LOG
	syslog (LOG_INFO, "==> draw_mutewin ()\n");
#endif
	if (ncurses_has_colors == TRUE) {
           	if (attr)
                   	wattron (mutewin, COLOR_PAIR (BLACK_ON_YELLOW));
                else
                   	wattron (mutewin, COLOR_PAIR (BLACK_ON_WHITE));
	}
	for (line = 0; line < MUTEWIN_HEIGHT; line++) {
		wmove (mutewin, line, 0);
		for (col = 0; col < MUTEWIN_WIDTH; col++)
			waddch (mutewin, 32);
	}
	wmove (mutewin, 0, 1);
        waddstr (mutewin, _("[ ] Mute"));
	if (ncurses_has_colors == TRUE) {
           	if (attr) {
                   	wattroff (mutewin, COLOR_PAIR (BLACK_ON_YELLOW));
                        wattron (mutewin, COLOR_PAIR (BLUE_ON_YELLOW));
                } else {
                   	wattroff (mutewin, COLOR_PAIR (BLACK_ON_WHITE));
                        wattron (mutewin, COLOR_PAIR (BLUE_ON_WHITE));
                }
	}
        wmove (mutewin, 0, 2);
        if (mute == VIDEO_AUDIO_MUTE)
           	waddch (mutewin, ACS_BULLET);
        if (ncurses_has_colors == TRUE) {
           	if (attr)
                   	wattroff (mutewin, COLOR_PAIR (BLUE_ON_YELLOW));
                else
                   	wattroff (mutewin, COLOR_PAIR (BLUE_ON_WHITE));
        }
	wrefresh (mutewin);
#ifdef LOG
	syslog (LOG_INFO, "<== draw_mutewin ()\n");
#endif
}

void draw_adrdatawin ()
{
	int line, col;

	if (ncurses_has_colors == TRUE) {
		switch (mode) {
			case VIDEO_SOUND_ADR:
			case VIDEO_SOUND_ADR_L:
			case VIDEO_SOUND_ADR_R:
				wattron (adrdatawin, COLOR_PAIR (WHITE_ON_BLACK));
				break;
			default:
				wattron (adrdatawin, COLOR_PAIR (WHITE_ON_BLUE));
		}
	}
	for (line = 0; line < ADRDATAWIN_HEIGHT; line++) {
		wmove (adrdatawin, line, 0);
		for (col = 0; col < ADRDATAWIN_WIDTH; col++) {
			waddch (adrdatawin, 32);
		}
	}
	if (ncurses_has_colors == TRUE) {
		switch (mode) {
			case VIDEO_SOUND_ADR:
			case VIDEO_SOUND_ADR_L:
			case VIDEO_SOUND_ADR_R:
				wattroff (adrdatawin, COLOR_PAIR (WHITE_ON_BLACK));
				break;
			default:
				wattroff (adrdatawin, COLOR_PAIR (WHITE_ON_BLUE));
		}
	}
	wrefresh (adrdatawin);
}

void draw_errorwin (char *errstr)
{
   	int line, col;
        
        errorwin = newwin (ERRORWIN_HEIGHT, ERRORWIN_WIDTH, ERRORWIN_ROW, ERRORWIN_COLUMN);
        if (ncurses_has_colors == TRUE ) {
           	wattron (errorwin, COLOR_PAIR (WHITE_ON_RED));
        }
      	mvwaddch (errorwin, 0, 0, ACS_ULCORNER);
        for (col = 1; col < ERRORWIN_WIDTH-2; col++) waddch (errorwin, ACS_HLINE);
        waddch (errorwin, ACS_URCORNER);
      	for (line = 1; line < ERRORWIN_HEIGHT-2; line++) {
           	mvwaddch (errorwin, line, 0, ACS_VLINE);
                for (col = 1; col < ERRORWIN_WIDTH-2; col++) waddch(errorwin, 32);
                waddch (errorwin, ACS_VLINE);
        }
      	mvwaddch (errorwin, ERRORWIN_HEIGHT-1, 0, ACS_LLCORNER);
        for (col = 1; col < ERRORWIN_WIDTH-2; col++) waddch (errorwin, ACS_HLINE);
        waddch (errorwin, ACS_LRCORNER);
      	mvwaddstr (errorwin, 0, 2, _(" Error "));
      	mvwaddstr (errorwin, ERRORWIN_HEIGHT-1, 2, _(" Press any key to continue "));
        mvwaddstr (errorwin, 1, 1, errstr);
        mvwaddstr (errorwin, 1, 1 + strlen (errstr), ":");
        mvwaddstr (errorwin, 2, 1, strerror (errno));
        if (ncurses_has_colors == TRUE ) {
           	wattroff (errorwin, COLOR_PAIR (WHITE_ON_RED));
        }
        
        getch ();
   	delwin (errorwin);
} /* draw_errorwin () */

void init_screen (void)
{
   	int col, line;

#ifdef LOG
	syslog (LOG_INFO, "==> init_screen ()\n");
#endif
   	if (ncurses_has_colors == TRUE) {
           	attroff (A_BOLD);
         	attron (COLOR_PAIR (WHITE_ON_BLUE));
        }
      	move (0, 0); addch (ACS_ULCORNER);
        for (col = 1; col < COLS-1; col++) addch (ACS_HLINE);
        addch (ACS_URCORNER);
      	for (line = 1; line < LINES-1; line++) {
           	move (line, 0); addch (ACS_VLINE);
                for (col = 1; col < COLS-1; col++) addch(32);
                addch (ACS_VLINE);
        }
      	move (LINES-1, 0); addch (ACS_LLCORNER);
        for (col=1; col<COLS-1; col++) addch (ACS_HLINE);
        addch (ACS_LRCORNER);
      	mvaddstr (1, 32, "Astra Radio");
      	mvaddstr (LINES-1, 7, _("     - move between fields         - change values   <q> - quit "));
        move (LINES-1, 8); addch (ACS_UARROW);
        move (LINES-1, 10); addch (ACS_DARROW);
        move (LINES-1, 36); addch (ACS_LARROW);
	move (LINES-1, 37); addch (ACS_HLINE);
	move (LINES-1, 39); addch (ACS_HLINE);
        move (LINES-1, 40); addch (ACS_RARROW);
      	if (ncurses_has_colors == TRUE) {
         	attroff (COLOR_PAIR (WHITE_ON_BLUE));
        }
	refresh ();
	draw_channelwin (NORMVIDEO);
	draw_carrierwin (NORMVIDEO);
        draw_monowin (NORMVIDEO);
	draw_stereowin (NORMVIDEO);
	draw_adrwin (NORMVIDEO);
	draw_mp2win (NORMVIDEO);
	draw_volumewin (volume, NORMVIDEO);
	draw_treblewin (treble, NORMVIDEO);
	draw_basswin (bass, NORMVIDEO);
	draw_mutewin (NORMVIDEO);
#ifdef LOG
	syslog (LOG_INFO, "<== init_screen ()\n");
#endif
} /* init_screen () */

void draw_onewin (int field, int attr)
{
#ifdef LOG
	syslog (LOG_INFO, "==> draw_onewin ()\n");
#endif
	switch (field) {
		case 0:
			draw_channelwin (attr);
			break;
		case 1:
			draw_carrierwin (attr);
			break;
                case 2:
                   	draw_monowin (attr);
                        break;
		case 3:
			draw_stereowin (attr);
			break;
		case 4:
			draw_adrwin (attr);
			break;
		case 5:
			draw_mp2win (attr);
			break;
		case 6:
			draw_volumewin (volume, attr);
			break;
		case 7:
			draw_treblewin (treble, attr);
			break;
		case 8:
			draw_basswin (bass, attr);
			break;
		case 9:
			draw_mutewin (attr);
		default:
	}
#ifdef LOG
	syslog (LOG_INFO, "<== draw_onewin ()\n");
#endif
} /* draw_onewin () */

int start_mp2record (void)
{
	time_t t;
        struct tm tm_s;
        char timestamp[20];
        char filename[40];
        
        time (&t);
        memcpy (&tm_s, localtime (&t), sizeof (tm_s));
        
        memset (filename, '\0', sizeof (filename));
        strftime (timestamp, sizeof (timestamp), "%Y%m%d_%H%M%S", &tm_s);
        
        strcpy (filename, F_PREFIX);
        strcpy (filename + strlen (F_PREFIX), timestamp);
        strcpy (filename + strlen (F_PREFIX) + strlen (timestamp), F_SUFFIX);
        
        mp2file = fopen (filename, "w");
        if (mp2file == NULL) {
           	perror (_("open MP2 file for writing"));
                return -1;
        }
        
        /* call ioctl for starting of MP2 record here */
        
        return 0;
} /* start_mp2record () */

void finish_mp2record (void)
{
   	int rc;
        
   	/* call ioctl for stopping of MP2 record here */
        
	rc = fclose (mp2file);
        if (rc != 0)
           	perror (_("close MP2 file"));
} /* finish_mp2record () */

void change_value (int field, int change)
{
	struct video_audio_sat vas;

        /* audio defaults */
	memset (&vas, 0, sizeof (vas));
	vas.audio = AUDIO_CHANNEL;
	vas.mode = VIDEO_SOUND_STEREO;

   	switch (field) {
        case 0:
           	if (change == +1)
                   	channel_nr += 1;
                if (change == -1)
                   	channel_nr -= 1;
                if (channel_nr < 0) channel_nr = NR_OF_CHANNELS - 1;
                if (channel_nr > NR_OF_CHANNELS - 1) channel_nr = 0;
                channel_freq = LO_CHAN_FREQ(channels[channel_nr].freq);
                channel_name = channels[channel_nr].name;
                draw_onewin (field, HIGHVIDEO);
		v4l_freq = (long int) (channels[channel_nr].freq * 16) / 1000;
		if (-1 == ioctl (fd, VIDIOCSFREQ, &v4l_freq)) {
			draw_errorwin (_("VIDIOCSFREQ, set transponder frequency"));
		}
#ifdef ADRDATA
		clr_adrdata ();
#endif
		break;
        case 1: /* change audio carriers */
           	if (change == +1) {
                   	l_carrier += 180;
                        if (mode == VIDEO_SOUND_STEREO) l_carrier += 180;
                }
                if (change == -1) {
                   	l_carrier -= 180;
                        if (mode == VIDEO_SOUND_STEREO) l_carrier -= 180;
                }
                if ((mode == VIDEO_SOUND_STEREO) || (mode == VIDEO_SOUND_MONO)) {
                	if (l_carrier < 7020) l_carrier = 7020;
	                if (mode == VIDEO_SOUND_STEREO) {
        	           	if (l_carrier > 7740) l_carrier = 7740;
                	} else {
                   		if (l_carrier > 7920) l_carrier = 7920;
                	}
                } else {
			if (l_carrier < 6120) l_carrier = 6120;
			if (l_carrier > 8460) l_carrier = 8460;
		}
                if (mode == VIDEO_SOUND_STEREO)
                   	r_carrier = l_carrier + 180;
                else
                   	r_carrier = l_carrier;
                draw_onewin (field, HIGHVIDEO);
                vas.flags = VIDEO_AUDIO_CARRIER;
		vas.l_carrier = l_carrier;
		vas.r_carrier = r_carrier;
		if (-1 == ioctl (fd, VIDIOCSAUDIO_SAT, &vas)) {
			draw_errorwin (_("VIDIOCSAUDIO_SAT, set carriers"));
		}
#ifdef ADRDATA
		clr_adrdata ();
#endif
                break;
        case 2: /* turn on/off Mono-L in ADR modes */
		switch (mode) {
           		case VIDEO_SOUND_ADR:
			case VIDEO_SOUND_ADR_R:
                   		mode = vas.mode = VIDEO_SOUND_ADR_L;
				break;
                	case VIDEO_SOUND_ADR_L:
                   		mode = vas.mode = VIDEO_SOUND_ADR;
				break;
			default:
		}
                draw_onewin (field, HIGHVIDEO);
	        draw_onewin (3, NORMVIDEO);
                vas.flags = VIDEO_AUDIO_MODE | VIDEO_AUDIO_CARRIER;
                vas.l_carrier = l_carrier;
                vas.r_carrier = r_carrier;
                if (-1 == ioctl (fd, VIDIOCSAUDIO_SAT, &vas)) {
		        draw_errorwin (_("VIDIOCSAUDIO_SAT, set mode + carriers"));
	        }
                break;        
	case 3: /* turn on/off Mono-R in ADR modes; else switch between mono<->stereo */
		switch (mode) {
			case VIDEO_SOUND_ADR:
			case VIDEO_SOUND_ADR_L:
                   		mode = vas.mode = VIDEO_SOUND_ADR_R;
				break;
                	case VIDEO_SOUND_ADR_R:
                   		mode = vas.mode = VIDEO_SOUND_ADR;
				break;
			case VIDEO_SOUND_MONO:
				mode = vas.mode = VIDEO_SOUND_STEREO;
				if (l_carrier < 7020) l_carrier = 7020;
				if (l_carrier == 7200) l_carrier = 7020;
				if (l_carrier == 7560) l_carrier = 7380;
				if (l_carrier >= 7920) l_carrier = 7740;
				r_carrier = l_carrier + 180;
				break;
			case VIDEO_SOUND_STEREO:
				mode = vas.mode = VIDEO_SOUND_MONO;
				r_carrier = l_carrier;
				break;
			default:
		}
		draw_onewin (field, HIGHVIDEO);
		draw_onewin (1, NORMVIDEO);
                draw_onewin (2, NORMVIDEO);
                vas.flags = VIDEO_AUDIO_MODE | VIDEO_AUDIO_CARRIER;
                vas.l_carrier = l_carrier;
                vas.r_carrier = r_carrier;
                if (-1 == ioctl (fd, VIDIOCSAUDIO_SAT, &vas)) {
		        draw_errorwin (_("VIDIOCSAUDIO_SAT, set mode + carriers"));
	        }
		break;
	case 4:	/* switch between normal<->ADR */
		switch (mode) {
			case VIDEO_SOUND_ADR:
			case VIDEO_SOUND_ADR_L:
			case VIDEO_SOUND_ADR_R:
				/* switch off ADR */
				mode = vas.mode = VIDEO_SOUND_STEREO;
				/* if mp2 recording is running stop it */
				if (mp2record) {
					finish_mp2record ();
					mp2record = 0;
					draw_onewin (5, NORMVIDEO);
				}
				if (l_carrier < 7020) l_carrier = 7020;
                        	if (l_carrier > 7740) l_carrier = 7740;
                        	if (l_carrier == 7560) l_carrier = 7380;
                        	if (l_carrier == 7200) l_carrier = 7020;
				r_carrier = l_carrier + 180;
				break;
			case VIDEO_SOUND_STEREO:
                           	r_carrier = l_carrier;
			case VIDEO_SOUND_MONO:
				/* switch on ADR */
				mode = vas.mode = VIDEO_SOUND_ADR;
				break;
			default:
		}
		draw_onewin (field, HIGHVIDEO);
		draw_onewin (1, NORMVIDEO);	/* show carrier freqs */
                draw_onewin (2, NORMVIDEO);	/* show/hide Mono-L field */
                draw_onewin (3, NORMVIDEO);	/* show/hide Stereo/Mono-R field */
                draw_onewin (5, NORMVIDEO);	/* show/hide MP2 field */
#ifdef ADRDATA
		draw_adrdatawin ();
#endif
                vas.flags = VIDEO_AUDIO_MODE | VIDEO_AUDIO_CARRIER;
                vas.l_carrier = l_carrier;
                vas.r_carrier = r_carrier;
                if (-1 == ioctl (fd, VIDIOCSAUDIO_SAT, &vas)) {
		        draw_errorwin (_("VIDIOCSAUDIO_SAT, set mode + carriers"));
	        }
		break;
        case 5:	/* start/stop mp2 recording */
		if (mp2record) {
			/* stop recording */
			finish_mp2record ();
			mp2record = 0;
		} else {
			/* start recording, but only if in ADR mode */
			if ((mode == VIDEO_SOUND_ADR) || (mode == VIDEO_SOUND_ADR_L) || (mode == VIDEO_SOUND_ADR_R)) {
				if (0 == start_mp2record ()) {
                                   	mp2record = 1;
                                }
			}
		}
                draw_onewin (field, HIGHVIDEO);
                break;
        case 6:	/* change volume level */
           	if (change == +1)
                   	volume += 5;
                if (change == -1)
                   	volume -= 5;
                if (volume < 0) volume = 0;
                if (volume > 100) volume = 100;
                draw_onewin (field, HIGHVIDEO);
		vas.volume = 655 * volume;
		vas.flags = VIDEO_AUDIO_VOLUME;
		if (-1 == ioctl (fd, VIDIOCSAUDIO_SAT, &vas)) {
			draw_errorwin (_("VIDIOCSAUDIO_SAT, set volume level"));
		}
                break;
        case 7:	/* change treble level */
           	if (change == +1)
                   	treble += 5;
                if (change == -1)
                   	treble -= 5;
                if (treble < -100) treble = -100;
                if (treble > 100) treble = 100;
                draw_onewin (field, HIGHVIDEO);
		vas.treble = (treble + 100) * 327;
		vas.flags = VIDEO_AUDIO_TREBLE;
		if (-1 == ioctl (fd, VIDIOCSAUDIO_SAT, &vas)) {
			draw_errorwin (_("VIDIOCSAUDIO_SAT, set treble level"));
		}
                break;
        case 8:	/* change bass level */
           	if (change == +1)
                   	bass += 5;
                if (change == -1)
                   	bass -= 5;
                if (bass < -100) bass = -100;
                if (bass > 100) bass = 100;
                draw_onewin (field, HIGHVIDEO);
		vas.bass = (bass + 100) * 327;
		vas.flags = VIDEO_AUDIO_BASS;
		if (-1 == ioctl (fd, VIDIOCSAUDIO_SAT, &vas)) {
			draw_errorwin (_("VIDIOCSAUDIO_SAT, set bass level"));
		}
                break;
	case 9:
		if (mute == VIDEO_AUDIO_MUTE) {
			mute = 0;
			vas.flags = VIDEO_AUDIO_UNMUTE;
		} else {
			mute = VIDEO_AUDIO_MUTE;
			vas.flags = VIDEO_AUDIO_MUTE;
		}
		draw_onewin (field, HIGHVIDEO);
		if (-1 == ioctl (fd, VIDIOCSAUDIO_SAT, &vas)) {
			draw_errorwin (_("VIDIOCSAUDIO_SAT, set mute state"));
		}
		break;
        default:
        }
} /* change_value () */

/* during start-up, check if a known channel is tuned in */
int is_known_channel (void)
{
	int i;
	struct video_audio_sat vas;

	/* several conditions must be fulfilled until a channel is */
	/* recognized as a "known channel". */
	/* 1. current frequency must be contained in channels[] array */
	if (-1 == ioctl (fd, VIDIOCGFREQ, &v4l_freq)) {
		perror (_("VIDIOCGFREQ: get current freq on start-up"));
		exit (-1);
	}
#ifdef LOG
	syslog (LOG_INFO, "startup v4l chan freq=%ld\n", v4l_freq);
#endif
	for (i = 0; i < NR_OF_CHANNELS; i++) {
		if (((channels[i].freq * 16) / 1000) == (int) v4l_freq)
			break;
	}
	if (i == NR_OF_CHANNELS)
		return 0;	/* "unknown" channel */
	else {
		channel_nr = i;
		channel_name = channels[i].name;
		channel_freq = LO_CHAN_FREQ(channels[i].freq);
	}
	/* 2. subcarrier freqs must match audio mode */
	vas.audio = AUDIO_CHANNEL;
	if (-1 == ioctl (fd, VIDIOCGAUDIO_SAT, &vas)) {
		perror (_("VIDIOCGAUDIO_SAT: get current audio settings on start-up"));
		exit (-1);
	}
#ifdef LOG
	syslog (LOG_INFO, "startup audio mode=0x%x\n", vas.mode);
	syslog (LOG_INFO, "startup volume level=%d\n", vas.volume);
	syslog (LOG_INFO, "startup bass level=%d\n", vas.bass);
	syslog (LOG_INFO, "startup treble level=%d\n", vas.treble);
	syslog (LOG_INFO, "startup left carrier=%d\n", vas.l_carrier);
	syslog (LOG_INFO, "startup right carrier=%d\n", vas.r_carrier);
#endif
        /* make V4L audio values our own values */
	mode = vas.mode;
	l_carrier = vas.l_carrier;
	r_carrier = vas.r_carrier;
	volume = vas.volume * 100 / 65500;	/* re-scale: 0..65535 -> 0..100 */
	treble = vas.treble * 100 / 65400;
	bass = vas.bass * 100 / 65400;
	switch (mode) {
	case VIDEO_SOUND_STEREO:
		if ((l_carrier != 7020) && (l_carrier != 7380) && (l_carrier != 7740))
			return 0;	/* "unknown" channel */
		if ((r_carrier != 7200) && (r_carrier != 7560) && (r_carrier != 7920))
			return 0;	/* "unknown" channel */
		break;
	case VIDEO_SOUND_MONO:
		if ((l_carrier != 6500) && (l_carrier != 7020) && (l_carrier != 7200) && (l_carrier != 7380) && (l_carrier != 7560) && (l_carrier != 7740) && (l_carrier != 7920))
			return 0;	/* "unknown" channel */
		break;
	case VIDEO_SOUND_LANG1:
		if ((l_carrier != 7020) && (l_carrier != 7200) && (l_carrier != 7380) && (l_carrier != 7560) && (l_carrier != 7740) && (l_carrier != 7920))
			return 0;	/* "unknown" channel */
		break;
	case VIDEO_SOUND_LANG2:
		if ((r_carrier != 7020) && (r_carrier != 7200) && (r_carrier != 7380) && (r_carrier != 7560) && (r_carrier != 7740) && (r_carrier != 7920))
			return 0;	/* "unknown" channel */
		break;
	case VIDEO_SOUND_ADR:
	case VIDEO_SOUND_ADR_L:
	case VIDEO_SOUND_ADR_R:
		if ((l_carrier != 6120) && (l_carrier != 6300) && (l_carrier != 6480) && (l_carrier != 6660) && (l_carrier != 6840) && (l_carrier != 7380) && (l_carrier != 7560) && (l_carrier != 7740) && (l_carrier != 7920) && (l_carrier != 8100) && (l_carrier != 8280) && (l_carrier != 8460))
			return 0;	/* "unknown" channel */
		break;
	default:
		return 0;	/* "unknown" channel */
	}
	return 1;		/* "known" channel */
} /* is_known_channel () */


int main (void)
{
   	int quit;
        int field;
	int ch;
        struct video_audio_sat vas;
	struct video_capability vcap;

#ifdef ENABLE_NLS
	setlocale (LC_ALL, "");
	textdomain (PACKAGE);
	bindtextdomain (PACKAGE, LOCALE_DIR);
#endif

#if LOG
	openlog ("astraradio", LOG_PID, LOG_USER);
#endif

	fd = open (DEVICE, O_RDONLY);
	if (fd == -1) {
		perror (_("open " DEVICE));
		return -1;
	}
	if (-1 == ioctl (fd, VIDIOCGCAP, &vcap)) {
		perror (_("VIDIOCGCAP, get video capability"));
                if (-1 == close (fd)) perror (_("close " DEVICE));
                return -1;
	}
	if (strncmp (vcap.name, INTERFACE_NAME, strlen (INTERFACE_NAME))) {
		fprintf (stderr, _("Cannot run without " INTERFACE_NAME " driver registered at " DEVICE "\n"));
                if (-1 == close (fd)) perror (_("close " DEVICE));
                return -1;
	}
	
	/* un-mute audio in any case */
	mute = INITIAL_MUTE_STATE;	/* should always be 0 (= UNMUTE) */
	memset (&vas, 0, sizeof (vas));
	vas.audio = AUDIO_CHANNEL;
	vas.flags = VIDEO_AUDIO_UNMUTE;
	if (-1 == ioctl (fd, VIDIOCSAUDIO_SAT, &vas)) {
		perror (_("VIDIOCSAUDIO_SAT, set initial mute state"));
            	if (-1 == close (fd)) perror (_("close " DEVICE));
                return -1;
	}
	/* set initial values if an unknown channel is tuned in */
	if (!is_known_channel ()) {
		channel_nr = INITIAL_CHANNEL_NUMBER;
		channel_name = channels[channel_nr].name;
		channel_freq = LO_CHAN_FREQ(channels[channel_nr].freq);
		v4l_freq = (long int) (channels[channel_nr].freq * 16) / 1000;
		if (-1 == ioctl (fd, VIDIOCSFREQ, &v4l_freq)) {
			perror (_("VIDIOCSFREQ, set initial TV chan freq"));
	                if (-1 == close (fd)) perror (_("close " DEVICE));
        	        return -1;
		}
		
		mode = INITIAL_MODE;
		l_carrier = INITIAL_LCARRIER_FREQ;
		r_carrier = INITIAL_RCARRIER_FREQ;
		volume = INITIAL_VOLUME_LEVEL;
		bass = INITIAL_BASS_LEVEL;
		treble = INITIAL_TREBLE_LEVEL;
		
		memset (&vas, 0, sizeof (vas));
		vas.audio = AUDIO_CHANNEL;
		vas.flags = VIDEO_AUDIO_MODE | VIDEO_AUDIO_VOLUME | VIDEO_AUDIO_BASS | VIDEO_AUDIO_TREBLE;
		vas.mode = mode;
		vas.volume = volume * 655;
		vas.bass = (bass+100) * 327;
		vas.treble = (treble+100) * 327;
		if (-1 == ioctl (fd, VIDIOCSAUDIO_SAT, &vas)) {
			perror (_("VIDIOCSAUDIO_SAT, set initial audio values"));
                	if (-1 == close (fd)) perror (_("close " DEVICE));
	                return -1;
		}
	}
        init_ncurses ();
        init_screen ();
#ifdef LOG
	syslog (LOG_INFO, "--> field = 0\n");
#endif
	field = 0;
#ifdef LOG
	syslog (LOG_INFO, "<-- field = 0\n");
#endif
	draw_onewin (field, HIGHVIDEO);
	quit = FALSE;
        while (!quit) {
#ifdef ADRDATA
		if (mode == VIDEO_SOUND_ADR) {
			unsigned char idx, old_idx;
			int count, to, i;
			unsigned char abuf[80], abuf1[80];

			old_idx = 0;
			count = 0;
			start_mp2record ();
			memset (abuf, 0, sizeof (abuf));
			memset (abuf1, 0x20, sizeof (abuf1));
			while (count < 256) {
				to = 100;
				do {
					ioctl (fd, VIDIOCGADRDATA, adrdata);
					idx = adrdata[1] >> 1;
					to--;
				} while ((idx == old_idx) && (to > 0));
				if (to == 0) break;
				old_idx = idx;

				sprintf (abuf, "%02x: ", idx);
				for (i = 0; i < 18; i++) {
					sprintf (abuf+(3*i)+4, "%02x ", adrdata[i+2]);
					if (i<15) {
						sprintf (abuf1+3*i+5, "%c  ", ((adrdata[i+2] >= ' ') && (adrdata[i+2] <= 'z')) ? (char) adrdata[i+2] : ' ');
					}
				}
				sprintf (abuf+58, "\n");
				sprintf (abuf1+50, "\n");
				fputs (abuf, mp2file);
				fputs (abuf1, mp2file);
				count++;
			}
			finish_mp2record ();
                        
			if (-1 == ioctl (fd, VIDIOCGADRDATA, adrdata)) {
				perror ("VIDIOCGADRDATA");
			}
			show_adrdata ();
			get_adrdata ();
			eval_adrdata ();
		}	/* mode == VIDEO_SOUND_ADR */
#endif
		switch (getch ()) {
			case 'Q':
			case 'q':
				quit = TRUE;
				break;
			case KEY_DOWN:
				draw_onewin (field, NORMVIDEO);
	                        field += 1;
                                /* skip mono/mp2 fields in Non-ADR modes */
                                if ((mode == VIDEO_SOUND_STEREO) || (mode == VIDEO_SOUND_MONO)) {
                                   	if (field == 2) field = 3;
                                        if (field == 5) field = 6;
                                }
				/* roll over */
	                        if (field > NUM_OF_WINDOWS-1)
		                        field = 0;
				draw_onewin (field, HIGHVIDEO);
				break;
			case KEY_UP:
				draw_onewin (field, NORMVIDEO);
				field -= 1;
				/* skip mono/mp2 fields in Non-ADR modes */
				if ((mode == VIDEO_SOUND_STEREO) || (mode == VIDEO_SOUND_MONO)) {
					if (field == 2) field = 1;
                                        if (field == 5) field = 4;
                                }
				/* roll over */
				if (field < 0)
					field = NUM_OF_WINDOWS-1;
				draw_onewin (field, HIGHVIDEO);
				break;
                        case KEY_RIGHT:
                           	change_value (field, +1);
                                break;
                        case KEY_LEFT:
                           	change_value (field, -1);
                                break;
                        default:
		} /* switch (getch ()) */
                
                if (mp2record) {
                        while (!0) {
                                ch = getch ();
                                if ((ch == KEY_LEFT) || (ch == KEY_RIGHT)) {
                                   	break;
                                }
                        }
                } /* if (mp2record) */
        } /* while (!quit) */
        
	if (mp2record) {
		finish_mp2record ();
		mp2record = 0;
	}

        exit_ncurses ();
#if 0	/* don't mute on exit any more */
	memset (&vas, 0, sizeof (vas));
	vas.audio = AUDIO_CHANNEL;
	vas.flags = VIDEO_AUDIO_MUTE;
	if (-1 == ioctl (fd, VIDIOCSAUDIO_SAT, &vas)) perror (_("VIDIOCSAUDIO_SAT, mute audio on exit"));
#endif
	closelog ();
        if (-1 == close (fd)) perror (_("close " DEVICE));
        return 0;
}
