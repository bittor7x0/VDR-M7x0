
#ifndef _FREQUENCIES_H
#define _FREQUENCIES_H

struct CHANLIST {
	char *name;
	unsigned long int freq;
        unsigned long int flags;
};

#define CHANCOUNT(x)	(sizeof (x) / sizeof (struct CHANLIST))

unsigned long int get_transponder_freq (char *transponder, unsigned long int *flags);

#endif

