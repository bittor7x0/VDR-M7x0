/*  common.c - defines, variables and functions commonly used
   	       by utility programs mfIIset, mfIIradio

    Copyright (C) 2001  Rolf Siebrecht

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <getopt.h>
#include <stdlib.h>
#include <ctype.h>
#include <sys/ioctl.h>

#include <linux/videodev.h>
#include "../../linux/videodev_priv.h"
#include "frequencies.h"

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#ifdef ENABLE_NLS
#include <libintl.h>
#define _(String)		gettext (String)
#define gettext_noop(String)	(String)
#define N_(String)		gettext_noop (String)
#else
#define _(String)		(String)
#define N_(String)		(String)
#endif

#define TUNER_NUMBER	0		/* number of tuner @ V4L i/f */
#define AUDIO_CHANNEL	0		/* number of audio channel @ V4L i/f */

#define LOLIMIT_SAT	1		/* satellite orbit position 1 */
#define HILIMIT_SAT	4		/* satellite orbit position 4 */
#define LOLIMIT_FREQ	10700000	/* Tuner frequency limits only for "help" */
					/* output. Actual frequency value is */
					/* compared against limits returned by V4L. */
#define HILIMIT_FREQ	12750000
#define LOLIMIT_CHAN	0		/* high channel limit is returned by V4L */
#define LOLIMIT_SOUND	0
#define HILIMIT_SOUND	65535
#define LOLIMIT_WIDTH	48
#define HILIMIT_WIDTH	768
#define LOLIMIT_HEIGHT	36
#define HILIMIT_HEIGHT	576
#define LOLIMIT_PICT	0
#define HILIMIT_PICT	65535
#define LOLIMIT_DEPTH	1
#define HILIMIT_DEPTH	4
#define LOLIMIT_PALETTE	1
#define HILIMIT_PALETTE	16
#define LOLIMIT_CARRIER	6100
#define HILIMIT_CARRIER	8400

#define OPTSTR_PAL	"pal"
#define OPTSTR_SECAM	"secam"
#define OPTSTR_NTSC	"ntsc"
#define OPTSTR_STEREO	"stereo"
#define OPTSTR_MONO	"mono"
#define OPTSTR_LANG1	"lang1"
#define OPTSTR_LANG2	"lang2"
#define OPTSTR_ON	"on"
#define OPTSTR_OFF	"off"
#define OPTSTR_HOR	"hor"
#define OPTSTR_VERT	"vert"
#define OPTSTR_ADR	"adr"
#define OPTSTR_ADRL	"adr-l"
#define OPTSTR_ADRR	"adr-r"

/* defaults */
#define DEFAULT_LO_LOF		9750000
#define DEFAULT_HI_LOF		10600000
#define DEFAULT_BITMASK_POL	HPOL
#define DEFAULT_BITMASK_BAND	0		/* = low Ku band */
#define DEFAULT_BITMASK_SAT	0		/* = satellite 1 */

/* global variables */
int cmd_audio = 0;	int arg_audio;
int cmd_frequency = 0;	unsigned long int arg_frequency;
int cmd_hiband = 0;	unsigned long int arg_hiband;
int cmd_lof = 0;	unsigned long int arg_lof;
int cmd_mute = 0;	int arg_mute;
int cmd_polarization = 0;	unsigned int arg_polarization;
int cmd_transponder = 0;unsigned long int arg_transponder;
int cmd_volume = 0;	__u16 arg_volume;
int cmd_satellite = 0;	unsigned long int arg_satellite;

int fd;
struct video_capability capability;

unsigned long int bitmasks_sat[HILIMIT_SAT] = {
	0, POS2ND, POS3RD, POS4TH
};


void
check_frequency (char *arg)
{
	char *end;
	size_t const l = strlen (arg);

   	arg_frequency = (int) (1000000.0 * strtod (arg, &end));	/* frequency in kHz */
	if (end - arg < l) {
		fprintf (stderr, _("%s: Format error in \"frequency\" argument. \"frequency\" command deleted.\n"), PROGNAME);
		return;
	}
	cmd_frequency += 1;
}

void
check_hiband (char *arg)
{
   	int cmd = 0;
        
        if (!strcmp (arg, OPTSTR_ON)) {
		cmd += 1;
		arg_hiband = HIBAND;
	}
        if (!strcmp (arg, OPTSTR_OFF)) {
		cmd += 1;
		arg_hiband = 0;
	}
        if (!cmd) {
           	fprintf (stderr, _("%s: Unknown \"hiband\" argument. \"hiband\" command deleted.\n"), PROGNAME);
                return;
        }
	cmd_hiband += 1;
}

void
check_lof (char *arg)
{
	char *end;
	size_t const l = strlen (arg);

   	arg_lof = (int) (1000000.0 * strtod (arg, &end));	/* local oscillator freq in kHz */
	if (end - arg < l) {
		fprintf (stderr, _("%s: Format error in \"lof\" argument. \"lof\" command deleted.\n"), PROGNAME);
		return;
	}
	cmd_lof += 1;
}

void
check_mute (char *arg)
{
   	int cmd = 0;
        
        if (!strcmp (arg, OPTSTR_ON)) {
		cmd += 1;
		arg_mute = VIDEO_AUDIO_MUTE;
	}
        if (!strcmp (arg, OPTSTR_OFF)) {
		cmd += 1;
		arg_mute = 0;
	}
        if (!cmd) {
           	fprintf (stderr, _("%s: Unknown \"mute\" argument. \"mute\" command deleted.\n"), PROGNAME);
                return;
        }
	cmd_mute += 1;
}

void
check_polarization (char *arg)
{
   	int cmd = 0;
        
        if (!strcmp (arg, OPTSTR_VERT)) {
		cmd += 1;
		arg_polarization = VPOL;
	}
        if (!strcmp (arg, OPTSTR_HOR)) {
		cmd += 1;
		arg_polarization = HPOL;
	}
        if (!cmd) {
           	fprintf (stderr, _("%s: Unknown \"polarization\" argument. \"polarization\" command deleted.\n"), PROGNAME);
                return;
        }
	cmd_polarization += 1;
}

void
check_satellite (char *arg)
{
	int val;
	char *end;
	size_t const l = strlen (arg);

	val = strtol (arg, &end, 0);
	if (end - arg < l) {
		fprintf (stderr, _("%s: Format error in \"satellite\" argument. \"satellite\" command deleted.\n"), PROGNAME);
		return;
	}
	if ((val < LOLIMIT_SAT) || (val > HILIMIT_SAT)) {
		fprintf (stderr, _("%s: \"satellite\" argument out of range. \"satellite\" command deleted.\n"), PROGNAME);
		return;
	}
	cmd_satellite += 1;
	arg_satellite = bitmasks_sat[val-1];
}

void
check_transponder (char *arg)
{
	static char new_arg[4];
        unsigned long int transponder_flags;

	if ((2 == strlen (arg)) && (isdigit (arg[1]))) {
		new_arg[0] = arg[0];
		new_arg[1] = '0';
		new_arg[2] = arg[1];
		new_arg[3] = '\0';
		arg = new_arg;
	}
	arg_transponder = get_transponder_freq (arg, &transponder_flags);
	if (arg_transponder == 0) {
		fprintf (stderr, _("%s: Invalid \"transponder\" name. \"transponder\" command deleted.\n"), PROGNAME);
		return;
	}
	cmd_transponder += 1;
        arg_transponder = (arg_transponder * 16 / 1000) | transponder_flags;
}

void
check_volume (char *arg)
{
   	int val;
	char *end;
	size_t const l = strlen (arg);
 
        val = strtol (arg, &end, 0);
	if (end - arg < l) {
		fprintf (stderr, _("%s: Format error in \"volume\" argument. \"volume\" command deleted.\n"), PROGNAME);
		return;
	}
        if ((val < LOLIMIT_SOUND) || (val > HILIMIT_SOUND)) {
           	fprintf (stderr, _("%s: \"volume\" argument out of range. \"volume\" command deleted.\n"), PROGNAME);
                return;
        }
	cmd_volume += 1;
	arg_volume = val;
}

int
open_device (char *dev, int *fd)
{
	if (-1 == (*fd = open (dev, O_RDONLY))) {
		fprintf (stderr, _("%s: open %s: %s\n"), PROGNAME, dev, strerror (errno));
		return -1;
	}
	if (-1 == ioctl (*fd, VIDIOCGCAP, &capability)) {
		fprintf (stderr, "%s: VIDIOCGCAP %s: %s\n", PROGNAME, dev, strerror (errno));
		if (-1 == close (*fd)) perror (_("close"));
		return -1;
	}
	if (strncmp (capability.name, INTERFACE_NAME, strlen (INTERFACE_NAME))) {
		fprintf (stderr, _("%s: can't run without %s registered at %s\n"), PROGNAME, INTERFACE_NAME, dev);
		if (-1 == close (*fd)) perror (_("close"));
		return -1;
	}
        return 0;
}

void
close_device (int fd)
{
	if (-1 == close (fd)) perror (_("close"));
	return;
}

void set_frequency (void)
{
        struct video_tuner vt;
	unsigned long int freq;
        
        if (!cmd_frequency)
           	return;

        vt.tuner = TUNER_NUMBER;
        if (-1 == ioctl (fd, VIDIOCGTUNER, &vt)) {
                perror ("VIDIOCGTUNER");
        }

	freq = arg_frequency;		/* [kHz] */
	if (cmd_lof)
            	freq -= arg_lof;
	else {
		if (cmd_hiband && arg_hiband)
			freq -= DEFAULT_HI_LOF;
		else
			freq -= DEFAULT_LO_LOF;
	}
        freq = (freq * 16) / 1000;	/* [1/16] MHz */

	if ((freq < vt.rangelow) || (freq > vt.rangehigh)) {
		fprintf (stderr, _("%s: \"frequency\" argument out of range. \"frequency\" command deleted.\n"), PROGNAME);
		cmd_frequency = 0;
	}
	else {
		if (cmd_hiband)
			freq |= arg_hiband;
		else
			freq |= DEFAULT_BITMASK_BAND;

		if (cmd_polarization)
			freq |= arg_polarization;
		else
			freq |= DEFAULT_BITMASK_POL;

		if (cmd_satellite)
			freq |= arg_satellite;
		else
			freq |= DEFAULT_BITMASK_SAT;

           	if (-1 == ioctl (fd, VIDIOCSFREQ, &freq)) {
                   	perror ("VIDIOCSFREQ");
                }
	}
}

void set_transponder ()
{
	unsigned long int freq = (unsigned long int) arg_transponder;

	if (!cmd_transponder)
           	return;

	if (-1 == ioctl (fd, VIDIOCSFREQ, &freq)) {
		perror ("VIDIOCSFREQ");
	}
}

