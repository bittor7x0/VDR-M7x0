#include "../../linux/videodev_priv.h"
#include "frequencies.h"

/* sat-europe */
#define	LOF_LO	9750000		/* low Ku-Band local oscillator frequency in kHz	*/
#define LOF_HI	10600000	/* high Ku-Band local oscillator frequency in kHz	*/

static struct CHANLIST sat_astra[] = {
   	{ "A01", 11214000 - LOF_LO, HPOL },   /* Astra  19.2�E, Tr. 01   */
        { "A02", 11229000 - LOF_LO, VPOL },   /* Astra  19.2�E, Tr. 02   */
        { "A03", 11243750 - LOF_LO, HPOL },   /* Astra  19.2�E, Tr. 03   */
        { "A04", 11258500 - LOF_LO, VPOL },   /* Astra  19.2�E, Tr. 04   */
        { "A05", 11273250 - LOF_LO, HPOL },   /* Astra  19.2�E, Tr. 05   */
        { "A06", 11288000 - LOF_LO, VPOL },   /* Astra  19.2�E, Tr. 06   */
        { "A07", 11302750 - LOF_LO, HPOL },   /* Astra  19.2�E, Tr. 07   */
        { "A08", 11317500 - LOF_LO, VPOL },   /* Astra  19.2�E, Tr. 08   */
        { "A09", 11332250 - LOF_LO, HPOL },   /* Astra  19.2�E, Tr. 09   */
        { "A10", 11347000 - LOF_LO, VPOL },   /* Astra  19.2�E, Tr. 10   */
        { "A11", 11361750 - LOF_LO, HPOL },   /* Astra  19.2�E, Tr. 11   */
        { "A12", 11376500 - LOF_LO, VPOL },   /* Astra  19.2�E, Tr. 12   */
        { "A13", 11391250 - LOF_LO, HPOL },   /* Astra  19.2�E, Tr. 13   */
        { "A14", 11406000 - LOF_LO, VPOL },   /* Astra  19.2�E, Tr. 14   */
        { "A15", 11420750 - LOF_LO, HPOL },   /* Astra  19.2�E, Tr. 15   */
        { "A16", 11435500 - LOF_LO, VPOL },   /* Astra  19.2�E, Tr. 16   */
        { "A17", 11464250 - LOF_LO, HPOL },   /* Astra  19.2�E, Tr. 17   */
        { "A18", 11479000 - LOF_LO, VPOL },   /* Astra  19.2�E, Tr. 18   */
        { "A19", 11493750 - LOF_LO, HPOL },   /* Astra  19.2�E, Tr. 19   */
        { "A20", 11508500 - LOF_LO, VPOL },   /* Astra  19.2�E, Tr. 20   */
        { "A21", 11523250 - LOF_LO, HPOL },   /* Astra  19.2�E, Tr. 21   */
        { "A22", 11538000 - LOF_LO, VPOL },   /* Astra  19.2�E, Tr. 22   */
        { "A23", 11552750 - LOF_LO, HPOL },   /* Astra  19.2�E, Tr. 23   */
        { "A24", 11567500 - LOF_LO, VPOL },   /* Astra  19.2�E, Tr. 24   */
        { "A25", 11582250 - LOF_LO, HPOL },   /* Astra  19.2�E, Tr. 25   */
        { "A26", 11597000 - LOF_LO, VPOL },   /* Astra  19.2�E, Tr. 26   */
        { "A27", 11612000 - LOF_LO, HPOL },   /* Astra  19.2�E, Tr. 27   */
        { "A28", 11626500 - LOF_LO, VPOL },   /* Astra  19.2�E, Tr. 28   */
        { "A29", 11641250 - LOF_LO, HPOL },   /* Astra  19.2�E, Tr. 29   */
        { "A30", 11656000 - LOF_LO, VPOL },   /* Astra  19.2�E, Tr. 30   */
        { "A31", 11671000 - LOF_LO, HPOL },   /* Astra  19.2�E, Tr. 31   */
        { "A32", 11686000 - LOF_LO, VPOL },   /* Astra  19.2�E, Tr. 32   */
        { "A33", 10964250 - LOF_LO, HPOL },   /* Astra  19.2�E, Tr. 33   */
        { "A34", 10979000 - LOF_LO, VPOL },   /* Astra  19.2�E, Tr. 34   */
        { "A35", 10993750 - LOF_LO, HPOL },   /* Astra  19.2�E, Tr. 35   */
        { "A36", 11008500 - LOF_LO, VPOL },   /* Astra  19.2�E, Tr. 36   */
        { "A37", 11023250 - LOF_LO, HPOL },   /* Astra  19.2�E, Tr. 37   */
        { "A38", 11038000 - LOF_LO, VPOL },   /* Astra  19.2�E, Tr. 38   */
        { "A39", 11052750 - LOF_LO, HPOL },   /* Astra  19.2�E, Tr. 39   */
        { "A40", 11067500 - LOF_LO, VPOL },   /* Astra  19.2�E, Tr. 40   */
        { "A41", 11082250 - LOF_LO, HPOL },   /* Astra  19.2�E, Tr. 41   */
        { "A42", 11097000 - LOF_LO, VPOL },   /* Astra  19.2�E, Tr. 42   */
        { "A43", 11111750 - LOF_LO, HPOL },   /* Astra  19.2�E, Tr. 43   */
        { "A44", 11126500 - LOF_LO, VPOL },   /* Astra  19.2�E, Tr. 44   */
        { "A45", 11141250 - LOF_LO, HPOL },   /* Astra  19.2�E, Tr. 45   */
        { "A46", 11156000 - LOF_LO, VPOL },   /* Astra  19.2�E, Tr. 46   */
        { "A47", 11170750 - LOF_LO, HPOL },   /* Astra  19.2�E, Tr. 47   */
        { "A48", 11185500 - LOF_LO, VPOL },   /* Astra  19.2�E, Tr. 48   */
        { "A49", 10714250 - LOF_LO, HPOL },   /* Astra  19.2�E, Tr. 49   */
        { "A50", 10729000 - LOF_LO, VPOL },   /* Astra  19.2�E, Tr. 50   */
        { "A51", 10743750 - LOF_LO, HPOL },   /* Astra  19.2�E, Tr. 51   */
        { "A52", 10758500 - LOF_LO, VPOL },   /* Astra  19.2�E, Tr. 52   */
        { "A53", 10773000 - LOF_LO, HPOL },   /* Astra  19.2�E, Tr. 53   */
        { "A54", 10788000 - LOF_LO, VPOL },   /* Astra  19.2�E, Tr. 54   */
        { "A55", 10802750 - LOF_LO, HPOL },   /* Astra  19.2�E, Tr. 55   */
        { "A56", 10817500 - LOF_LO, VPOL },   /* Astra  19.2�E, Tr. 56   */
        { "A57", 10832250 - LOF_LO, HPOL },   /* Astra  19.2�E, Tr. 57   */
        { "A58", 10847000 - LOF_LO, VPOL },   /* Astra  19.2�E, Tr. 58   */
        { "A59", 10862000 - LOF_LO, HPOL },   /* Astra  19.2�E, Tr. 59   */
        { "A60", 10877000 - LOF_LO, VPOL },   /* Astra  19.2�E, Tr. 60   */
        { "A61", 10891000 - LOF_LO, HPOL },   /* Astra  19.2�E, Tr. 61   */
        { "A62", 10906000 - LOF_LO, VPOL },   /* Astra  19.2�E, Tr. 62   */
        { "A63", 10920750 - LOF_LO, HPOL },   /* Astra  19.2�E, Tr. 63   */
        { "A64", 10935500 - LOF_LO, VPOL },   /* Astra  19.2�E, Tr. 64   */
};

int chancount = CHANCOUNT(sat_astra);

unsigned long int get_transponder_freq (char *transponder, unsigned long int *flags)
{
	int tr = 0;
	unsigned long int frq = 0;

	do {
		if (!strcmp (transponder, sat_astra[tr].name)) {
			frq = sat_astra[tr].freq;
                        *flags = sat_astra[tr].flags;
			break;
		}
	} while (++tr < chancount);

	return frq;
}

