/*  mfIIinfo.c - show video4linux infos about TechniSat MediafocusII driver

    Copyright (C) 2000  Rolf Siebrecht

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/videodev.h>

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#ifdef ENABLE_NLS
#include <libintl.h>
#define _(String)		gettext (String)
#define gettext_noop(String)	(String)
#define N_(String)		gettext_noop (String)
#else
#define _(String)		(String)
#define N_(String)		(String)
#endif

#define VID_DEVICE	"/dev/video"
#define	RADIO_DEVICE	"/dev/radio"
#define VTX_DEVICE	"/dev/vtx"
#define VBI_DEVICE	"/dev/vbi"
#define NUM_OF_MINORS	4

int fd;		/* device/file descriptor */

int
show_tuners (int num_of_tuners)
{
	int i;
	struct video_tuner vt;
	unsigned long int freq;

	for (i = 0; i < num_of_tuners; i++) {
		vt.tuner = i;
		if (-1 == ioctl (fd, VIDIOCGTUNER, &vt)) {
			perror ("mfIIinfo: VIDIOCGTUNER");
			return -1;
		}
		printf (_("			-- tuner %d --\n"), i);
		printf (_("			name:		%s\n"), vt.name);
		printf (_("			rangelow:	%ld "), vt.rangelow / 16);
		if (vt.flags & VIDEO_TUNER_LOW)
			printf ("kHz\n");
		else
			printf ("MHz\n");
		printf (_("			rangehigh:	%ld "), vt.rangehigh / 16);
		if (vt.flags & VIDEO_TUNER_LOW)
			printf ("kHz\n");
		else
			printf ("MHz\n");
		printf (_("			flags:		"));
		if (vt.flags & VIDEO_TUNER_PAL) printf ("has_PAL ");
		if (vt.flags & VIDEO_TUNER_NTSC) printf ("has_NTSC ");
		if (vt.flags & VIDEO_TUNER_SECAM) printf ("has_SECAM ");
		if (vt.flags & VIDEO_TUNER_LOW) printf ("has_Low_range ");
		if (vt.flags & VIDEO_TUNER_NORM) printf ("has_Norm ");
		if (vt.flags & VIDEO_TUNER_STEREO_ON) printf ("stereo_on ");
		if (vt.flags & VIDEO_TUNER_RDS_ON) printf ("rds_on ");
		if (vt.flags & VIDEO_TUNER_MBS_ON) printf ("mbs_on ");
		printf ("\n");
		printf (_("			current mode:	"));
		switch (vt.mode) {
			case VIDEO_MODE_PAL:
				printf ("PAL");
				break;
			case VIDEO_MODE_NTSC:
				printf ("NTSC");
				break;
			case VIDEO_MODE_SECAM:
				printf ("SECAM");
				break;
#if 0
			case VIDEO_MODE_VBI:
				printf ("VBI");
				break;
#endif
			default:
				printf (_("(unknown)"));
		}
		printf ("\n");
		printf (_("			current signal:	%.1f %%\n"), (float) vt.signal / 655.35);
		if (0 > ioctl (fd, VIDIOCGFREQ, &freq)) {
			perror ("mfIIinfo: VIDIOCGFREQ");
			return -1;
		}
		freq &= 0xffff;		/* delete control flags in bits 16 and above */
		printf (_("			current freq:	%.1f "), (float) freq / 16.0);
		if (vt.flags & VIDEO_TUNER_LOW)
			printf ("kHz\n");
		else
			printf ("MHz\n");
	}
	return 0;
}

int
show_channels (int num_of_channels)
{
	int i;
	struct video_channel vc;

	for (i = 0; i < num_of_channels; i++) {
		vc.channel = i;
		if (-1 == ioctl (fd, VIDIOCGCHAN, &vc)) {
			perror ("mfIIinfo: VIDIOCGCHAN");
			return -1;
		}
		printf (_("	-- video channel %d --\n"), i);
		printf (_("	name:		%s\n"), vc.name);
		printf (_("	flags:		"));
		if (vc.flags & VIDEO_VC_TUNER) printf ("has_Tuners ");
		if (vc.flags & VIDEO_VC_AUDIO) printf ("has_Audio ");
		printf ("\n");
		printf (_("	num of tuners:	%d\n"), vc.tuners);
		if (vc.tuners > 0) show_tuners (vc.tuners);
		printf (_("	type:		"));
		if (vc.type & VIDEO_TYPE_TV) printf ("TV ");
		if (vc.type & VIDEO_TYPE_CAMERA) printf ("Camera ");
		printf ("\n");
		printf (_("	current norm:	"));
		switch (vc.norm) {
			case VIDEO_MODE_PAL:
				printf ("PAL");
				break;
			case VIDEO_MODE_NTSC:
				printf ("NTSC");
				break;
			case VIDEO_MODE_SECAM:
				printf ("SECAM");
				break;
			case VIDEO_MODE_AUTO:
				printf ("Auto");
				break;
#if 0
			case VIDEO_MODE_VBI:
				printf ("VBI");
				break;
#endif
			default:
				printf (_("(unknown)")); 
		}
		printf ("\n");
	}
	return 0;
}

int
show_audios (int num_of_audios)
{
	int i;
	struct video_audio va;

	for (i = 0; i < num_of_audios; i++) {
		va.audio = i;
		if (-1 == ioctl (fd, VIDIOCGAUDIO, &va)) {
			perror ("mfIIinfo: VIDIOCGAUDIO");
			return -1;
		}
		printf (_("	-- audio channel %d --\n"), i);
		printf (_("	name:		%s\n"), va.name);
		printf (_("	mutable:	%s\n"), (va.flags & VIDEO_AUDIO_MUTABLE) ? _("yes") : _("no"));
		printf (_("	current mute:	%s\n"), (va.flags & VIDEO_AUDIO_MUTE) ? _("on") : _("off"));
		printf (_("	current volume:	%.1f %%\n"), (float) va.volume / 655.35);
		printf (_("	current bass:	%.1f %%\n"), (float) va.bass / 655.35);
		printf (_("	current treble:	%.1f %%\n"), (float) va.treble / 655.35);
		printf (_("	current mode:	"));
		if (va.mode & VIDEO_SOUND_MONO) printf ("mono ");
		if (va.mode & VIDEO_SOUND_STEREO) printf ("stereo ");
		if (va.mode & VIDEO_SOUND_LANG1) printf (_("language1 "));
		if (va.mode & VIDEO_SOUND_LANG2) printf (_("language2 "));
		printf ("\n");
	}
	return 0;
}

int
show_capability ()
{
	struct video_capability vc;
	struct video_buffer vb;
	struct video_window vw;
	struct video_picture vp;
	struct video_mbuf mb;

	if (0 > ioctl (fd, VIDIOCGCAP, &vc)) {
		perror ("mfIIinfo: VIDIOCGCAP");
		return -1;
	}
	printf (_("Name:				%s\n"), vc.name);
	printf (_("Type flags:			"));
	if (vc.type & VID_TYPE_CAPTURE) printf ("has_Capture ");
	if (vc.type & VID_TYPE_TUNER) printf ("has_Tuner ");
	if (vc.type & VID_TYPE_TELETEXT) printf ("has_Teletext ");
	if (vc.type & VID_TYPE_OVERLAY) printf ("has_Overlay ");
	if (vc.type & VID_TYPE_CHROMAKEY) printf ("has_Chromakey ");
	if (vc.type & VID_TYPE_CLIPPING) printf ("has_Clipping ");
	if (vc.type & VID_TYPE_FRAMERAM) printf ("has_FrameRAM ");
	if (vc.type & VID_TYPE_SCALES) printf ("has_Scaling ");
	if (vc.type & VID_TYPE_MONOCHROME) printf ("has_Monochrome ");
	if (vc.type & VID_TYPE_SUBCAPTURE) printf ("has_Subcapture ");
	printf ("\n");
	printf (_("Maximum capture width:		%d pixels\n"), vc.maxwidth);
	printf (_("Maximum capture height: 	%d pixels\n"), vc.maxheight);
	printf (_("Minimum capture width:		%d pixels\n"), vc.minwidth);
	printf (_("Minimum capture height: 	%d pixels\n"), vc.minheight);
	/* show channel (video source) infos */
	printf (_("Number of video channels:	%d\n"), vc.channels);
	if (vc.channels > 0) show_channels (vc.channels);
	/* show capture/grabbing infos */
	if (vc.type & VID_TYPE_CAPTURE) {
		if (0 > ioctl (fd, VIDIOCGMBUF, &mb)) {
			perror ("mfIIinfo: VIDIOCGMBUF");
			return -1;
		}
		printf (_("Grab buffer count:		%d\n"), mb.frames);
		printf (_("Grab buffer total size:		%d bytes\n"), mb.size);
		if (mb.frames > 1) {
			int k;

			printf (_("Grab buffer offsets:		"));
			for (k = 0; k < mb.frames; k++)
				printf ("0x%x ", mb.offsets[k]);
			printf ("\n");
		}
	}
	/* show overlay infos */
	if (vc.type & VID_TYPE_OVERLAY) {
		if (0 > ioctl (fd, VIDIOCGFBUF, &vb)) {
			perror ("mfIIinfo: VIDIOCGFBUF");
			return -1;
		}
		printf (_("Frame buffer base address:	0x%08x\n"), (unsigned int) vb.base);
		printf (_("Frame buffer width:		%d pixels\n"), vb.width);
		printf (_("Frame buffer height:		%d pixels\n"), vb.height);
		printf (_("Frame buffer colour depth:	%d bits per pixel\n"), vb.depth);
		printf (_("Frame buffer bytes per line:	%d\n"), vb.bytesperline);
		if (0 > ioctl (fd, VIDIOCGWIN, &vw)) {
			perror ("mfIIinfo: VIDIOCGWIN");
			return -1;
		}
		printf (_("Overlay window X origin:	@ pixel %d\n"), vw.x);
		printf (_("Overlay window Y origin:	@ pixel %d\n"), vw.y);
		printf (_("Overlay window width:		%d pixels\n"), vw.width);
		printf (_("Overlay window height:		%d pixels\n"), vw.height);
		printf (_("Overlay window chromakey:	0x%08x\n"), vw.chromakey);
		if (0 > ioctl (fd, VIDIOCGPICT, &vp)) {
			perror ("mfIIinfo: VIDIOCGPICT");
			return -1;
		}
		printf (_("Image brightness:		%.1f %%\n"), (float) vp.brightness / 655.35);
		printf (_("Image contrast:			%.1f %%\n"), (float) vp.contrast / 655.35);
		printf (_("Image colour saturation:	%.1f %%\n"), (float) vp.colour / 655.35);
		printf (_("Image colour hue:		%+.1f %%\n"), ((float) vp.hue - 32768.0) / 327.68);
		printf (_("Image whiteness:		%.1f %%\n"), (float) vp.whiteness / 655.35);
		printf (_("Image colour depth:		%d bits per pixel\n"), vp.depth);
		printf (_("Image palette:			"));
		switch (vp.palette) {
		case VIDEO_PALETTE_GREY:
			printf ("GREY\n");
			break;
		case VIDEO_PALETTE_HI240:
			printf ("HI240\n");
			break;
		case VIDEO_PALETTE_RGB565:
			printf ("RGB 5-6-5\n");
			break;
		case VIDEO_PALETTE_RGB555:
			printf ("RGB 5-5-5\n");
			break;
		case VIDEO_PALETTE_RGB24:
			printf ("RGB 24\n");
			break;
		case VIDEO_PALETTE_RGB32:
			printf ("RGB 32\n");
			break;
		case VIDEO_PALETTE_YUV422:
			printf ("YUV 4-2-2\n");
			break;
		case VIDEO_PALETTE_YUYV:
			printf ("YUYV\n");
			break;
		case VIDEO_PALETTE_UYVY:
			printf ("UYVY\n");
			break;
		case VIDEO_PALETTE_YUV420:
			printf ("YUV 4-2-0\n");
			break;
		case VIDEO_PALETTE_YUV411:
			printf ("YUV 4-1-1\n");
			break;
		case VIDEO_PALETTE_RAW:
			printf ("RAW\n");
			break;
		case VIDEO_PALETTE_YUV422P:
			printf ("YUV 4-2-2 planar\n");
			break;
		case VIDEO_PALETTE_YUV411P:
			printf ("YUV 4-1-1 planar\n");
			break;
		case VIDEO_PALETTE_YUV420P:
			printf ("YUV 4-2-0 planar\n");
			break;
		case VIDEO_PALETTE_YUV410P:
			printf ("YUV 4-1-0 planar\n");
			break;
		default:
			printf ("(unknown)\n");
		}
	}
	/* show audio infos */
	printf (_("Number of audio channels:	%d\n"), vc.audios);
	if (vc.audios > 0) show_audios (vc.audios);
	printf ("\n");
	return 0;
}

int
main ()
{
	char *devices[] = {
		VID_DEVICE, RADIO_DEVICE, VBI_DEVICE, VTX_DEVICE
	};
	int dev, num_of_devices = sizeof (devices) / sizeof (devices[0]);
	int minor;
	char dev_s[20];

#ifdef ENABLE_NLS
	setlocale (LC_ALL, "");
	textdomain (PACKAGE);
	bindtextdomain (PACKAGE, LOCALE_DIR);
#endif

	for (dev = 0; dev < num_of_devices; dev++) {
		for (minor=0; minor < NUM_OF_MINORS; minor++) {
			sprintf (dev_s, "%s%1d\0", devices[dev], minor);
			if (-1 == (fd = open (dev_s, O_RDONLY))) {
				/* ENODEV is the expected error if a device file is not covered */
				/* by any driver. So show error only if it is not ENODEV.  */
				if (errno != ENODEV)
					fprintf (stderr, _("open %s: %s\n"), dev_s, strerror (errno));
				close (fd);
				continue;
			}
			printf (_("-- V4L info, device %s --\n"), dev_s);
			show_capability ();
			if (-1 == close (fd)) fprintf (stderr, _("close %s: %s\n"), dev_s, strerror (errno));
		}
	}
	return 0;
}

