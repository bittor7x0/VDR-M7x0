/*  mfIIradio.c - V4L radio control application (command line tool)
   		  for TechniSat MediafocusII driver

    Copyright (C) 2000,2001  Rolf Siebrecht

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/* #define	MPEG_WORKING	1	*/

#define	PROGNAME	"mfIIradio"
#define INTERFACE_NAME	"TechniSat MediaFocusII Radio"
#define DEFAULT_DEVICE	"/dev/radio"

#include "common.c"
#include "frequencies.c"

/* defaults */
#define DEFAULT_MPEG	0

/* more global variables */
int cmd_bass = 0;	__u16 arg_bass;
int cmd_carrier = 0;	int arg_lcarrier, arg_rcarrier;
int cmd_mp2 = 0;	int arg_mp2;
int cmd_treble = 0;	__u16 arg_treble;


void
usage ()
{
	printf (_("usage: %s <options>\n"), PROGNAME);
	printf (_("options:\n"));
#ifdef MPEG_WORKING
	printf (_("-2, --mp2={%s | %s}\tselect MP2 recording state\n"), OPTSTR_OFF, OPTSTR_ON);
#endif
	printf (_("-a, --audio={%s | %s | %s | %s | %s}\tselect audio mode\n"), OPTSTR_STEREO, OPTSTR_MONO, OPTSTR_ADR, OPTSTR_ADRL, OPTSTR_ADRR);
	printf (_("-b, --bass=<%d..%d>\tset bass level\n"), LOLIMIT_SOUND, HILIMIT_SOUND);
	printf (_("-c, --carrier=<%3.1f...%3.1f>\ttune audio carrier [MHz]\n"), LOLIMIT_CARRIER / 1000.0, HILIMIT_CARRIER / 1000.0);
	printf (_("\t\t\t->In stereo mode set left channel carrier frequency\n"));
	printf (_("\t\t\t->only; right channel carrier frequency is implicitly\n"));
	printf (_("\t\t\t->adjusted at +180 kHz.\n"));
	printf (_("-d, --device={/dev/radio0 | /dev/radio1 | ...}\tselect v4l device\n"));
	printf (_("-f, --frequency=<%.2f...%.2f>\ttune transponder frequency [GHz]\n"), (float) LOLIMIT_FREQ / 1000000.0, (float) HILIMIT_FREQ / 1000000.0);
	printf (_("-h, --help\t\t\tshow this help\n"));
	printf (_("-i, --hiband={%s | %s}\tselect high Ku-band\n"), OPTSTR_OFF, OPTSTR_ON);
	printf (_("-l, --lof=<value>\t\tlocal oscillator frequency of LNB [GHz]\n"));
	printf (_("-m, --mute={%s | %s}\t\tselect audio mute state\n"), OPTSTR_OFF, OPTSTR_ON);
	printf (_("-p, --polarization={%s | %s}\tselect LNB polarization\n"), OPTSTR_VERT, OPTSTR_HOR);
        printf (_("-q, --satellite=<%d...%d>\tselect satellite orbit position per DiSEqC\n"), LOLIMIT_SAT, HILIMIT_SAT);
	printf (_("-r, --treble=<%d...%d>\tset treble level\n"), LOLIMIT_SOUND, HILIMIT_SOUND);
	printf (_("-t, --transponder=<Ann>\tselect Astra transponder nn\n"));
	printf (_("-v, --volume=<%d...%d>\tset volume level\n\n"), LOLIMIT_SOUND, HILIMIT_SOUND);
	printf (_("defaults (if corresponding option not specified):\n"));
	printf ("  device=%s\t\tpolarization=%s\n", DEFAULT_DEVICE, (DEFAULT_BITMASK_POL == HPOL) ? OPTSTR_HOR : OPTSTR_VERT);
	printf ("  lof=%4.2f [GHz] (lo-band)\thiband=%s\n", (float) DEFAULT_LO_LOF / 1000000.0, (DEFAULT_BITMASK_BAND == HIBAND) ? OPTSTR_ON : OPTSTR_OFF);
        printf ("  lof=%4.2f [GHz] (hi-band)\tsatellite=%c\n", (float) DEFAULT_HI_LOF / 1000000.0, (DEFAULT_BITMASK_SAT == 0) ? '1' : '?');
#ifdef MPEG_WORKING
        printf ("  mpeg=%s\n", (DEFAULT_MPEG) ? OPTSTR_ON : OPTSTR_OFF);
#endif
}

void
check_audio (char *arg)
{
   	int cmd = 0;
        
        if (!strcmp (arg, OPTSTR_STEREO)) {
           	cmd += 1;
           	arg_audio = VIDEO_SOUND_STEREO;
        }
        if (!strcmp (arg, OPTSTR_MONO)) {
           	cmd += 1;
                arg_audio = VIDEO_SOUND_MONO;
        }
        if (!strcmp (arg, OPTSTR_ADR)) {
           	cmd += 1;
                arg_audio = VIDEO_SOUND_ADR;
        }
        if (!strcmp (arg, OPTSTR_ADRL)) {
           	cmd += 1;
                arg_audio = VIDEO_SOUND_ADR_L;
        }
        if (!strcmp (arg, OPTSTR_ADRR)) {
           	cmd += 1;
                arg_audio = VIDEO_SOUND_ADR_R;
        }
        if (!cmd) {
           	fprintf (stderr, _("%s: Unknown \"audio\" argument. \"audio\" command deleted.\n"), PROGNAME);
                return;
        }
        cmd_audio += 1;
}

void
check_bass (char *arg)
{
   	int val;
	char *end;
	size_t const l = strlen (arg);
        
        val = strtol (arg, &end, 0);
	if (end - arg < l) {
		fprintf (stderr, _("%s: Format error in \"bass\" argument. \"bass\" command deleted.\n"), PROGNAME);
		return;
	}
        if ((val < LOLIMIT_SOUND) || (val > HILIMIT_SOUND)) {
           	fprintf (stderr, _("%s: \"bass\" argument out of range. \"bass\" command deleted.\n"), PROGNAME);
                return;
        }
        cmd_bass += 1;
        arg_bass = val;
}

void
check_treble (char *arg)
{
   	int val;
	char *end;
	size_t const l = strlen (arg);
        
        val = strtol (arg, &end, 0);
	if (end - arg < l) {
		fprintf (stderr, _("%s: Format error in \"treble\" argument. \"treble\" command deleted.\n"), PROGNAME);
		return;
	}
        if ((val < LOLIMIT_SOUND) || (val > HILIMIT_SOUND)) {
           	fprintf (stderr, _("%s: \"treble\" argument out of range. \"treble\" command deleted.\n"));
                return;
        }
        cmd_treble += 1;
        arg_treble = val;
}

void
check_carrier (char *arg)
{
   	int val;
	char *end;
	size_t const l = strlen (arg);
        
        val = (int)(100.0 * strtod (arg, &end) + 0.5) * 10;	/* carrier freq in kHz */
	if (end - arg < l) {
		fprintf (stderr, _("%s: Format error in \"carrier\" argument. \"carrier\" command deleted.\n"), PROGNAME);
		return;
	}
        if ((val < LOLIMIT_CARRIER) || (val > HILIMIT_CARRIER)) {
           	fprintf (stderr, _("%s: \"carrier\" argument out of range. \"carrier\" command deleted.\n"), PROGNAME);
                return;
        }
        cmd_carrier += 1;
        arg_lcarrier = val;
        arg_rcarrier = val + 180;
}

void
check_mp2 (char *arg)
{
   	int cmd = 0;
        
        if (!strcmp (arg, OPTSTR_ON)) {
           	cmd += 1;
                arg_mp2 = 1;
        }
        if (!strcmp (arg, OPTSTR_OFF)) {
           	cmd += 1;
                arg_mp2 = 0;
        }
        if (!cmd) {
           	fprintf (stderr, _("%s: Unknown \"mp2\" argument. \"mp2\" command deleted.\n"), PROGNAME);
                return;
        }
        cmd_mp2 += 1;
}

int
main (int argc, char **argv)
{
   	int c, longindex;
        char device[80];
        const struct option longopts[] = {
                { "mp2",	required_argument,0,'2' },
           	{ "audio",	required_argument,0,'a' },
                { "bass",	required_argument,0,'b' },
                { "carrier",	required_argument,0,'c' },
                { "device",	required_argument,0,'d' },
                { "frequency",	required_argument,0,'f' },
                { "help",	no_argument,0,'h' },
                { "hiband",	required_argument,0,'i' },
                { "lof",	required_argument,0,'l' },
                { "mute",	required_argument,0,'m' },
                { "polarization",	required_argument,0,'p' },
                { "satellite",	required_argument,0,'q' },
                { "treble",	required_argument,0,'r' },
		{ "transponder",required_argument,0,'t' },
                { "volume",	required_argument,0,'v' },
                { 0, 0, 0, 0 },
        };
        
#ifdef ENABLE_NLS
	setlocale (LC_ALL, "");
	textdomain (PACKAGE);
	bindtextdomain (PACKAGE, LOCALE_DIR);
#endif

        if ((argc == 1) || (argv[1][0] != '-')) {
           	fprintf (stderr, _("%s: No option specified, nothing done.\n"), PROGNAME);
                exit (-1);
        }
        strcpy (device, DEFAULT_DEVICE);
        
        while ((c = getopt_long (argc, argv, "2:a:b:c:d:f:hi:l:m:p:r:t:v:?", longopts, &longindex)) != EOF) {
           	switch (c) {
                        case '2':
                           	check_mp2 (optarg);
                           	break;
                   	case 'a':
                           	check_audio (optarg);
                           	break;
                        case 'b':
                           	check_bass (optarg);
                           	break;
                        case 'c':
                           	check_carrier (optarg);
                           	break;
                        case 'd':
                           	strcpy (device, optarg);
                           	break;
                        case 'f':
                           	check_frequency (optarg);
                           	break;
                        case 'i':
                           	check_hiband (optarg);
                           	break;
                        case 'l':
                           	check_lof (optarg);
                           	break;
                        case 'm':
                           	check_mute (optarg);
                           	break;
                        case 'p':
                           	check_polarization (optarg);
                           	break;
                        case 'q':
                           	check_satellite (optarg);
                                break;
                        case 'r':
                           	check_treble (optarg);
                           	break;
			case 't':
				check_transponder (optarg);
				break;
                        case 'v':
                           	check_volume (optarg);
                           	break;
                   	case 'h':
                        case '?':
                           	usage ();
                                exit (1);
                        default:
                           	fprintf (stderr, _("%s: Unknown command line option.\n"), PROGNAME);
                                usage ();
                                exit (1);
                }
        }

	if (cmd_frequency && cmd_transponder) {
		fprintf (stderr, _("%s: \"frequency\" and \"transponder\" specified together. \"frequency\" command deleted.\n"), PROGNAME);
		cmd_frequency = 0;
	}

	if (!cmd_audio && !cmd_bass && !cmd_carrier && !cmd_frequency &&
        !cmd_mp2 && !cmd_mute && !cmd_transponder && !cmd_treble && !cmd_volume) {
		fprintf (stderr, _("%s: Nothing done.\n"), PROGNAME);
		exit (1);
	}

	if (cmd_lof && !cmd_frequency)
		fprintf (stderr, _("%s: Warning, \"lof\" option w/o \"frequency\" option has no effect.\n"), PROGNAME);		
	if (cmd_polarization && !cmd_frequency)
		fprintf (stderr, _("%s: Warning, \"polarization\" option w/o \"frequency\" option has no effect.\n"), PROGNAME);
	if (cmd_hiband  && !cmd_frequency)
		fprintf (stderr, _("%s: Warning, \"hiband\" option w/o \"frequency\" option has no effect.\n"), PROGNAME);

        if (open_device (device, &fd))
		exit (-1);

        set_frequency ();
        set_transponder ();
        
        if (cmd_audio || cmd_bass || cmd_carrier || cmd_mute || cmd_treble || cmd_volume) {
		struct video_audio_sat vas;

           	vas.audio = AUDIO_CHANNEL;
                
		/* adjust right channel carrier frequency for ADR mode */
		if (cmd_carrier) {	/* "set carrier" demanded */
			if (cmd_audio) {	/* "set mode" demanded */
				switch (arg_audio) {
					case VIDEO_SOUND_ADR:
					case VIDEO_SOUND_ADR_L:
					case VIDEO_SOUND_ADR_R:
						arg_rcarrier = arg_lcarrier;
					default:
				}
			}
			else {	/* no "set mode" demanded -> inquire mode from driver */
				if (-1 == ioctl (fd, VIDIOCGAUDIO_SAT, &vas)) {
					perror ("VIDIOCGAUDIO_SAT (#1)");
				} else {
					switch (vas.mode) {
						case VIDEO_SOUND_ADR:
						case VIDEO_SOUND_ADR_L:
						case VIDEO_SOUND_ADR_R:
							arg_rcarrier = arg_lcarrier;
					}
				}
			}
		}
                
           	if (-1 == ioctl (fd, VIDIOCGAUDIO_SAT, &vas)) {
                   	perror ("VIDIOCGAUDIO_SAT (#2)");
                } else {
			vas.flags = 0;
                   	if (cmd_audio) {
                           	vas.mode = arg_audio;
				vas.flags |= VIDEO_AUDIO_MODE;
			}
                        if (cmd_bass) {
                           	vas.bass = arg_bass;
                           	vas.flags |= VIDEO_AUDIO_BASS;
                        }
                        if (cmd_carrier) {
                           	vas.l_carrier = arg_lcarrier;
                                vas.r_carrier = arg_rcarrier;
                                vas.flags |= VIDEO_AUDIO_CARRIER;
                        }
                        if (cmd_mute) {
				if (arg_mute)
					vas.flags |= VIDEO_AUDIO_MUTE;
				else
					vas.flags |= VIDEO_AUDIO_UNMUTE;
                        }
                        if (cmd_treble) {
                           	vas.treble = arg_treble;
                                vas.flags |= VIDEO_AUDIO_TREBLE;
                        }
                        if (cmd_volume) {
                           	vas.volume = arg_volume;
                                vas.flags |= VIDEO_AUDIO_VOLUME;
                        }
                        if (-1 == ioctl (fd, VIDIOCSAUDIO_SAT, &vas)) {
                           	perror ("VIDIOCSAUDIO_SAT");
                        }
                }
        }
        
        close_device (fd);

	if (!cmd_audio && !cmd_bass && !cmd_carrier && !cmd_frequency &&
        !cmd_mp2 && !cmd_mute && !cmd_transponder && !cmd_treble && !cmd_volume) {
		fprintf (stderr, _("%s: Nothing done.\n"), PROGNAME);
		exit (1);
	}

	exit (0);
}

